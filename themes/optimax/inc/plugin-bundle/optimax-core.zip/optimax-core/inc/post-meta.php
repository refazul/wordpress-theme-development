<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
use \RT_Postmeta;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Postmeta' ) ) {
  return;
}

$Postmeta = RT_Postmeta::getInstance();

$prefix = Constants::$theme_prefix;

/*-------------------------------------
#. Layout Settings
# Note: It should compliances with redux config
---------------------------------------*/
$nav_menus = wp_get_nav_menus( ['fields' => 'id=>name']);
$nav_menus = ['default' => __( 'Default', 'optimax-core' )] + $nav_menus;
$sidebars  = ['default' => __( 'Default', 'optimax-core' )] + Helper::custom_sidebar_fields();

$Postmeta->add_meta_box(
  "{$prefix}_page_settings", __( 'Layout Settings', 'optimax-core' ),
  ['page', 'post', $prefix . '_team', $prefix . '_case', $prefix . '_service'],
  '',
  '',
  'high',
  [
  'fields' => [
    "{$prefix}_layout_settings" => [
      'label'   => __( 'Layouts', 'optimax-core' ),
      'type'    => 'group',
      'value'  => [
        'layout' => [
          'label'   => __( 'Layout', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default'       => __( 'Default', 'optimax-core' ),
            'full-width'    => __( 'Full Width', 'optimax-core' ),
            'left-sidebar'  => __( 'Left Sidebar', 'optimax-core' ),
            'right-sidebar' => __( 'Right Sidebar', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'sidebar' => [
          'label'    => __( 'Custom Sidebar', 'optimax-core' ),
          'type'     => 'select',
          'options'  => $sidebars,
          'default'  => 'default',
        ],
        "page_menu" => [
          'label'    => __( 'Main Menu Selection', 'optimax-core' ),
          'type'     => 'select',
          'options'  => $nav_menus,
          'default'  => 'default',
        ],
        "page_offcanvas_menu" => [ 
          'label'    => __( 'Offcanvas Menu selection', 'optimax-core' ),
          'type'     => 'select',
          'options'  => $nav_menus,
          'default'  => 'default',
        ],
        "page_merge_menu" => [ 
          'label'    => __( 'Merge Menu / Mobile Menu(Mainmenu + Offcanvas Menu) selection', 'optimax-core' ),
          'type'     => 'select',
          'options'  => $nav_menus,
          'default'  => 'default',
        ],

        'icon_area_width' => [
          'label'   => __( 'Menu Icon Area Width', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            '1' => esc_html__( '1 Column', 'optimax-core' ),
            '2' => esc_html__( '2 Column', 'optimax-core' ),
            '3' => esc_html__( '3 Column', 'optimax-core' ),
            '4' => esc_html__( '4 Column', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],


        'search_icon' => [
          'label'   => __( 'Search Icon', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],

        'menu_button' => [
          'label'   => __( 'Menu Button', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'search_icon' => [
          'label'   => __( 'Search Icon', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'cart_icon' => [
          'label'   => __( 'Cart Icon', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'offcanvas_menu' => [
          'label'   => __( 'Offcanvas Menu', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'header_type' => [ 
          'label'   => __( 'Header Type (apply .container / .contain  class)', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default',  'optimax-core' ),
            'fluid_header'       => __( 'Fluid Header', 'optimax-core' ),
            'box_header'       => __( 'Box Header', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'menu_theme' => [ 
          'label'   => __( 'Menu Theme', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default',  'optimax-core' ),
            'light_theme'       => __( 'Light Theme', 'optimax-core' ),
            'dark_theme'       => __( 'Dark Theme', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'logo_type' => [ 
          'label'   => __( 'Logo Type', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default',  'optimax-core' ),
            'light_background_logo'       => __( 'Light background Logo', 'optimax-core' ),
            'dark_background_logo'       => __( 'Dark background Logo', 'optimax-core' ),
          ],
          'default'  => 'default',
          'desc'  => __( 'In case of default, Logo will be accordance dark and light theme', 'optimax-core' ),
        ],
        'hamburger_image' => [
          'label' => __( 'Hamburger Image', 'optimax-core' ),
          'type'  => 'image',
          'desc'  => __( 'If not selected, default will be used', 'optimax-core' ),
        ],


        'top_bar' => [
          'label'   => __( 'Top Bar', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'topbar_color' => [
          'label' => __( 'Topbar Color', 'optimax-core' ),
          'type'  => 'color_picker',
          'desc'  => __( 'If not selected, default will be used', 'optimax-core' ),
        ],
        'topbar_accent_color' => [
          'label' => __( 'Topbar Accent Color', 'optimax-core' ),
          'type'  => 'color_picker',
          'desc'  => __( 'If not selected, default will be used', 'optimax-core' ),
        ],
        'topbar_background_color' => [
          'label' => __( 'Topbar Background Color', 'optimax-core' ),
          'type'  => 'color_picker',
          'desc'  => __( 'If not selected, default will be used', 'optimax-core' ),
        ],
        'header_style' => [
          'label'   => __( 'Header Layout', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default',  'optimax-core' ),
            '1'       => __( 'Layout 1', 'optimax-core' ),
            '2'       => __( 'Layout 2', 'optimax-core' ),
            '3'       => __( 'Layout 3', 'optimax-core' ),
            '4'       => __( 'Layout 4', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'transparent_top_bar' => [
          'label'   => __( 'Transparent Top Bar', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],

        'transparent_header' => [
          'label'   => __( 'Transparent Header', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'top_bar_style' => [
          'label'   => __( 'Top Bar Layout', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default',  'optimax-core' ),
            '1'       => __( 'Layout 1', 'optimax-core' ),
            '2'       => __( 'Layout 2', 'optimax-core' ),
            '3'       => __( 'Layout 3', 'optimax-core' ),
            '4'       => __( 'Layout 4', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],

        "content_top_padding" => [
          'label'   => esc_html__( 'Content Padding Top', 'optimax-core' ),
          'type'    => 'text',
          'default'  => 'default',
        ],
        "content_bottom_padding" => [
          'label'   => esc_html__( 'Content Padding Bottom', 'optimax-core' ),
          'type'    => 'text',
          'default'  => 'default',
        ],
        
        'banner' => [
          'label'   => __( 'Banner', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'    => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'breadcrumb' => [
          'label'   => __( 'Breadcrumb', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'      => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],
        'bgtype' => [
          'label'   => __( 'Banner Background Type', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'bgimg'   => __( 'Background Image', 'optimax-core' ),
            'bgcolor' => __( 'Background Color', 'optimax-core' ),
          ],
          'default' => 'default',
        ],
        'bgimg' => [
          'label' => __( 'Banner Background Image', 'optimax-core' ),
          'type'  => 'image',
          'desc'  => __( 'If not selected, default will be used', 'optimax-core' ),
        ],
        'bgcolor' => [
          'label' => __( 'Banner Background Color', 'optimax-core' ),
          'type'  => 'color_picker',
          'desc'  => __( 'If not selected, default will be used', 'optimax-core' ),
        ],

        'footer_cta' => [
          'label'   => __( 'Footer Call To Action', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            'on'      => __( 'Enable', 'optimax-core' ),
            'off'   => __( 'Disable', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],

        'footer_cta_style' => [
          'label'   => __( 'Footer Call To Action Style', 'optimax-core' ),
          'type'    => 'select',
          'options' => [
            'default' => __( 'Default',  'optimax-core' ),
            '1'       => __( 'Style 1', 'optimax-core' ),
            '2'       => __( 'Style 2', 'optimax-core' ),
          ],
          'default'  => 'default',
        ],


      ]
    ]
  ]
  ]);

/*-------------------------------------
#. Team
---------------------------------------*/
$Postmeta->add_meta_box( "{$prefix}_team_settings", __( 'Team Member Settings', 'optimax-core' ), ["{$prefix}_team"], '', '', 'high', [
  'fields' => [
    "{$prefix}_team_designation" => [
      'label' => __( 'Designation', 'optimax-core' ),
      'type'  => 'text',
    ],
    "{$prefix}_team_socials_header" => [
      'label' => __( 'Socials', 'optimax-core' ),
      'type'  => 'header',
      'desc'  => __( 'Enter your social links here', 'optimax-core' ),
    ],
    "{$prefix}_team_socials" => [
      'type'  => 'group',
      'value'  => Helper::team_socials_post_meta()
    ],
  ]
]);

$Postmeta->add_meta_box( "{$prefix}_team_skills", __( 'Team Member Skills', 'optimax-core' ), array( "{$prefix}_team" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_team_skill" => array(
			'type'  => 'repeater',
			'button' => __( 'Add New Skill', 'optimax-core' ),
			'value'  => array(
				'skill_name' => array(
					'label' => __( 'Skill Name', 'optimax-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. Marketing', 'optimax-core' ),
				),
				'skill_value' => array(
					'label' => __( 'Skill Percentage (%)', 'optimax-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. 75', 'optimax-core' ),
				),
				'skill_color' => array(
					'label' => __( 'Skill Color', 'optimax-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, primary color will be used', 'optimax-core' ),
				),
			)
		),
	)
) );


/*-------------------------------------
#. Case Study
---------------------------------------*/
// Case gallery
$Postmeta->add_meta_box("{$prefix}_case_gallery_settings", __( 'case Info', 'optimax-core' ), ["{$prefix}_case"], '', '', 'high', [
  'fields' => [
    "{$prefix}_case_header_2" => [
      'label' => 'Case Study Gallery',
      'type'  => 'header',
      'desc'  => __( "for creating image gallery", 'optimax-core' ),
    ],
    "{$prefix}_case_gallery" => [
      'label'=> 'Gallery Images',
        'desc'  => 'This is the gallery images on the single Case Study page.',
        'type'  => 'gallery'
    ],
	
	"{$prefix}_case_layout" => [
      'label'=> 'Case Layout',
        'desc'  => 'This is the single Case Study layout.',
        'type'  => 'select',
		'options' => [
            'default' => __( 'Default', 'optimax-core' ),
            '1'       => __( 'Style 1', 'optimax-core' ),
            '2'       => __( 'Style 2', 'optimax-core' ),
            '3'       => __( 'Style 3', 'optimax-core' ),
        ],
		'default'  => 'default',
    ],
  ]
]);
$Postmeta->add_meta_box( "{$prefix}_case_settings", __( 'Other Case Info', 'optimax-core' ), ["{$prefix}_case"], '', '', 'high', [
  'fields' => [
    "{$prefix}_case_client" => [
      'label' => __( 'Client Name', 'optimax-core' ),
      'type'  => 'text',
    ],
    "{$prefix}_case_date" => [
      'label' => __( 'Case Date', 'optimax-core' ),
      'type'  => 'date_picker',
    ],
    "{$prefix}_case_client_website" => [
      'label' => __( 'Client Website', 'optimax-core' ),
      'type'  => 'text',
    ],
  ]
]);




/*-------------------------------------
#. Testimonial
---------------------------------------*/
$Postmeta->add_meta_box( "{$prefix}_testimonial_info", __( 'Testimonial Info', 'optimax-core' ), ["{$prefix}_testimony"], '', '', 'high', [
  'fields' => [
    "{$prefix}_tes_designation" => [
      'label' => __( 'Designation', 'optimax-core' ),
      'type'  => 'text',
    ],
    "{$prefix}_rating" => [
      'label'   => __( 'No Of Star', 'optimax-core' ),
      'type'    => 'select',
      'options' => [
        '1' => __( '1 Star', 'optimax-core' ),
        '2' => __( '2 Stars', 'optimax-core' ),
        '3' => __( '3 Stars', 'optimax-core' ),
        '4' => __( '4 Stars', 'optimax-core' ),
        '5' => __( '5 Stars', 'optimax-core' ),
      ],
      'default'  => '5',
    ],
  ]
]);



/*-------------------------------------
#. Services
#. It should be first appeared before
#. general.
---------------------------------------*/
$Postmeta->add_meta_box(
  "{$prefix}_service_icon",
  __( 'Service Icon image', 'optimax-core' ),
  array( "{$prefix}_service" ),
  '',
  'side',
  'default', array(
  'fields' => array(
    "{$prefix}_service_icon" => array(
      'label' => __( 'Service Icon', 'optimax-core' ),
      'type'  => 'icon_select',
      'desc'  => __( "Choose a Icon for your service", 'optimax-core' ),
      'options' => Helper::get_icons(),
    ),
    "{$prefix}_service_image" => array(
      'label' => __( 'Service Image', 'optimax-core' ),
      'type'  => 'image',
      'desc'  => __( "Upload service image in case of icon not selected", 'optimax-core' ),
    ),
    "{$prefix}_service_color" => [
      'label' => __( 'Gradient 1st Color', 'optimax-core' ),
      'type'  => 'color_picker',
      'desc'  => __( 'Used as Icon Background In Addon', 'optimax-core' ),
    ],
    "{$prefix}_service_color_2" => [
      'label' => __( 'Gradient 2nd Color ', 'optimax-core' ),
      'type'  => 'color_picker',
      'desc'  => __( 'Used as Icon Background In Addon', 'optimax-core' ),
    ],

  )
) );

