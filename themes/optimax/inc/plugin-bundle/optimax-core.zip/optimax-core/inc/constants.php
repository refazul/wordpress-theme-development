<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

class Constants {

  public static $theme_prefix;
  public static $widget_prefix;
  public static $plugin_namespace;

  public static $plugin_base_dir;
  public static $plugin_inc_dir;
  public static $plugin_templates_dir;
  public static $theme_version;



  public function __construct() {
    self::$theme_prefix      = 'optimax';
    self::$widget_prefix     = 'optimax';
    self::$plugin_namespace  = __NAMESPACE__ . '\\';

    self::$plugin_base_dir    = plugin_dir_path(dirname(__FILE__));
    self::$plugin_inc_dir    = self::$plugin_base_dir . 'inc/';
    self::$plugin_templates_dir    = self::$plugin_base_dir . 'optimax-templates/';

    $theme_data = wp_get_theme( get_template() );
    self::$theme_version     = ( WP_DEBUG ) ? time() : $theme_data->get( 'Version' );

  }
}

new Constants;
