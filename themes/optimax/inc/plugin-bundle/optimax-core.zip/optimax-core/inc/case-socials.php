<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\RDTheme;

class Case_Social {
  public static $sharers = [];
  public static $defaults = [];
  /**
   * generate all social share options
   * @return [type] [description]
   */
  public static function generate_defults() {
    $url   = urlencode( get_permalink() );
    $title = urlencode( get_the_title() );
    $defaults = [
      'facebook' => [
        'url'  => "http://www.facebook.com/sharer.php?u=$url",
        'icon' => 'fa-facebook',
      ],
      'twitter'  => [
        'url'  => "https://twitter.com/intent/tweet?source=$url&text=$title:$url",
        'icon' => 'fa-twitter'
      ],
      'gplus'    => [
        'url'  => "https://plus.google.com/share?url=$url",
        'icon' => 'fa-google-plus'
      ],
      'linkedin' => [
        'url'  => "http://www.linkedin.com/shareArticle?mini=true&url=$url&title=$title",
        'icon' => 'fa-linkedin'
      ],
      'pinterest'=> [
        'url'  => "http://pinterest.com/pin/create/button/?url=$url&description=$title",
        'icon' => 'fa-pinterest'
      ],
      'tumblr'   => [
        'url'  => "http://www.tumblr.com/share?v=3&u=$url &quote=$title",
        'icon' => 'fa-tumblr'
      ],
      'reddit'   => [
        'url'  => "http://www.reddit.com/submit?url=$url&title=$title",
        'icon' => 'fa-reddit'
      ],
      'vk'       => [
        'url'  => "http://vkontakte.ru/share.php?url=$url",
        'icon' => 'fa-vk'
      ],
    ];
    self::$defaults = $defaults;
  }
  public static function filter_defaults()
  {
    foreach ( RDTheme::$options['case_share'] as $key => $value ) {
      if ( !$value ) {
        unset( self::$defaults[$key] );
      }
    }
    self::$sharers = apply_filters( 'rdtheme_social_sharing_icons', self::$defaults );
  }
  public static function render()
  {
    self::generate_defults();
    self::filter_defaults();
   ?> 
    <ul class="item-social">
      <?php foreach ( self::$sharers as $key => $sharer ): ?>
        <li>
          <a href="<?php echo esc_attr( $sharer['url'] ); ?>">
            <i class="<?php echo esc_attr( $sharer['icon'] ); ?>"></i>
          </a>
      </li>
      <?php endforeach ?>
    </ul>
   <?php
  }
}




