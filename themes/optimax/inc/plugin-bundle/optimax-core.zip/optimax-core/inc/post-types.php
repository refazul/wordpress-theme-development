<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\RDTheme;
use \RT_Posts;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Posts' ) ) {
  return;
}

$prefix = Constants::$theme_prefix;

$post_types = [
  "{$prefix}_team"      => [
    'title'           => __( 'Team Member', 'optimax-core' ),
    'plural_title'    => __( 'Team Members', 'optimax-core' ),
    'menu_icon'       => 'dashicons-businessman',
    'labels_override' => [
      'menu_name'   => __( 'Team', 'optimax-core' ),
    ],
    'rewrite'         => RDTheme::$options['team_slug'],
    'supports'        => ['title', 'thumbnail', 'editor','excerpt', 'page-attributes']
  ],
  "{$prefix}_case"   => [
    'title'           => __( 'Case Study', 'optimax-core' ),
    'plural_title'    => __( 'Case Study', 'optimax-core' ),
    'menu_icon'       => 'dashicons-portfolio',
    'rewrite'         => RDTheme::$options['case_slug'],
    'supports'        => ['title', 'thumbnail', 'editor','excerpt', 'comments', 'page-attributes']
  ],
  "{$prefix}_testimony" => [
    'title'           => __( 'Testimonial', 'optimax-core' ),
    'plural_title'    => __( 'Testimonials', 'optimax-core' ),
    'menu_icon'       => 'dashicons-awards',
    'rewrite'         => false,
    'supports'        => ['title', 'thumbnail', 'editor', 'page-attributes']
  ],

   "{$prefix}_service" => [
    'title'           => __( 'Service', 'optimax-core' ),
    'plural_title'    => __( 'Services', 'optimax-core' ),
    'menu_icon'       => 'dashicons-sos',
    'rewrite'         => RDTheme::$options['service_slug'],
    'supports'        => ['title', 'thumbnail', 'editor', 'excerpt', 'page-attributes']
   ],
];

$taxonomies = [
  "{$prefix}_testimony_category" => [
    'title'        => __( 'Testimonial Category', 'optimax-core' ),
    'plural_title' => __( 'Testimonial Categories', 'optimax-core' ),
    'post_types'   => "{$prefix}_testimony",
    'rewrite'      => 'testimonials',
  ],
  "{$prefix}_team_category" => [
    'title'        => __( 'Team Category', 'optimax-core' ),
    'plural_title' => __( 'Team Categories', 'optimax-core' ),
    'post_types'   => "{$prefix}_team",
    'rewrite'      => ['slug' => RDTheme::$options['team_cat_slug']],
  ],
  "{$prefix}_case_category" => [
    'title'        => __( 'Case Study Category', 'optimax-core' ),
    'plural_title' => __( 'Case Study Categories', 'optimax-core' ),
    'post_types'   => "{$prefix}_case",
    'rewrite'      => ['slug' => RDTheme::$options['case_cat_slug']],
  ],
  "{$prefix}_case_tag" => [
    'title'        => __( 'Case Study Tag', 'optimax-core' ),
    'plural_title' => __( 'Case Study Tags', 'optimax-core' ),
    'post_types'   => "{$prefix}_case",
    'rewrite'      => ['slug' => RDTheme::$options['case_tag_slug']],
    'hierarchical' => false,  // for make it tag functionality 
  ],
  "{$prefix}_service_category" => [
    'title'        => __( 'Service Category', 'optimax-core' ),
    'plural_title' => __( 'Service Categories', 'optimax-core' ),
    'post_types'   => "{$prefix}_service",
    'rewrite'      => ['slug' => RDTheme::$options['service_cat_slug']],

  ],
];

$Posts = RT_Posts::getInstance();
$Posts->add_post_types( $post_types );
$Posts->add_taxonomies( $taxonomies );
