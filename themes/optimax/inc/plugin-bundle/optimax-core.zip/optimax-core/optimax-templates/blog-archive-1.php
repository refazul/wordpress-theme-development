<?php
/**
 * Template Name: Blog Archive 1
 *
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;

// generate_custom_archive_page ('post_type_name', 'post_type_archive_style')
Helper::generate_custom_archive_page('post', 1);
