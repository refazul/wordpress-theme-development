<?php

use radiustheme\Optimax_Core\Constants;
/*
Plugin Name: Optimax Core
Plugin URI: https://www.radiustheme.com
Description: Optimax Core Plugin for Optimax Theme
Version: 1.5
Author: RadiusTheme
Author URI: https://www.radiustheme.com
*/
if ( ! defined( 'ABSPATH' ) ) exit;

class Optimax_Core {
  public $plugin  = 'optimax-core';
  public $action  = 'optimax_theme_init';
  public $rt_dir;
  public function __construct() {
    $this->rt_dir      = __DIR__;
    $this->includes();
    $prefix = Constants::$theme_prefix;

    add_action( 'plugins_loaded', [$this, 'demo_importer'], 15 );
    add_action( 'plugins_loaded', array( $this, 'load_textdomain' ), 16 );
    add_action( 'after_setup_theme', [$this, 'post_types'], 15 );
    add_action( 'after_setup_theme', [$this, 'elementor_widgets']);
    add_action( 'after_setup_theme', array( $this, 'fix_layerslider_tgm_compability' ) );


    // Redux Flash permalink after options changed
    add_action( "redux/options/{$prefix}/saved", [$this, 'flush_redux_saved'], 10, 2 );
    add_action( "redux/options/{$prefix}/section/reset", [$this, 'flush_redux_reset']);
    add_action( "redux/options/{$prefix}/reset", [$this, 'flush_redux_reset']);
    add_action( 'init', [$this, 'rewrite_flush_check']);
    
    add_action( 'show_user_profile',        [ $this, 'extra_profile_fields'], 10 );
    add_action( 'edit_user_profile',        [ $this, 'extra_profile_fields'], 10 );
    add_action( 'personal_options_update',  [ $this, 'save_extra_profile_fields' ] );
    add_action( 'edit_user_profile_update', [ $this, 'save_extra_profile_fields' ] );
  }
  public function fix_layerslider_tgm_compability(){
    if ( !is_admin() || !apply_filters( 'rdtheme_disable_layerslider_autoupdate', true ) || get_option( 'layerslider-authorized-site' ) ) return;
    global $LS_AutoUpdate;
    if ( isset( $LS_AutoUpdate ) && defined( 'LS_ROOT_FILE' ) ) {
      remove_filter( 'pre_set_site_transient_update_plugins', array( $LS_AutoUpdate, 'set_update_transient' ) );
      remove_filter( 'plugins_api', array( $LS_AutoUpdate, 'set_updates_api_results'), 10, 3 );
      remove_filter( 'upgrader_pre_download', array( $LS_AutoUpdate, 'pre_download_filter' ), 10, 4 );
      remove_filter( 'in_plugin_update_message-'.plugin_basename( LS_ROOT_FILE ), array( $LS_AutoUpdate, 'update_message' ) );
      remove_filter( 'wp_ajax_layerslider_authorize_site', array( $LS_AutoUpdate, 'handleActivation' ) );
      remove_filter( 'wp_ajax_layerslider_deauthorize_site', array( $LS_AutoUpdate, 'handleDeactivation' ) );
    }
  }
  public function includes()
  {
    require $this->rt_dir . '/inc/constants.php';
    require $this->rt_dir . '/widgets/init.php';
    require $this->rt_dir . '/optimax-templates/init.php';
    require $this->rt_dir . '/inc/sidebar-generator.php';
    require $this->rt_dir . '/inc/lib/wp-svg/init.php';
    require $this->rt_dir . '/inc/socials.php';
    require $this->rt_dir . '/inc/author-social.php';
    require $this->rt_dir . '/inc/case-social.php';
    require $this->rt_dir . '/inc/utilities.php';

  }
  public function demo_importer() {
    require $this->rt_dir . '/inc/demo-importer.php';
  }

  public function load_textdomain() {
    load_plugin_textdomain( $this->plugin , false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
  }

  public function post_types(){
    if ( !did_action( $this->action ) || ! defined( 'RT_FRAMEWORK_VERSION' ) ) {
      return;
    }
    require_once Constants::$plugin_inc_dir . 'post-types.php';
    require_once Constants::$plugin_inc_dir . 'post-meta.php';
  }

  public function elementor_widgets(){
    if ( did_action( $this->action ) && did_action( 'elementor/loaded' ) ) {
      require_once 'elementor/init.php';
    }
  }

  // Flush rewrites
  public function flush_redux_saved( $saved_options, $changed_options ){
    if ( empty( $changed_options ) ) {
      return;
    }
    $prefix = Constants::$theme_prefix;
    $flush  = false;
    $slugs  = ['team_slug', 'case_slug', 'service_slug',];
    foreach ( $slugs as $slug ) {
      if ( array_key_exists( $slug, $changed_options ) ) {
        $flush = true;
      }
    }

    if ( $flush ) {
      update_option( "{$prefix}_rewrite_flash", true );
    }
  }

  public function flush_redux_reset(){
    $prefix = Constants::$theme_prefix;
    update_option( "{$prefix}_rewrite_flash", true );
  }

  public function rewrite_flush_check() {
    $prefix = Constants::$theme_prefix;
    if ( get_option( "{$prefix}_rewrite_flash" ) == true ) {
      flush_rewrite_rules();
      update_option( "{$prefix}_rewrite_flash", false );
    }
  }
  public function extra_profile_fields( $user ) { ?>
    <h3><?php esc_html_e( 'Social Profiles', 'optimax-core' );?></h3>
    <table class="form-table">
      <?php 
      $socials = [
        'facebook',
        'twitter',
        'linkedin',
        'instagram',
        'pinterest',
        'tumblr',
        'reddit',
      ];
      ?>
      <?php foreach ($socials as $key): ?>
        <tr>
          <th><label for="<?php echo esc_attr( $key ); ?>"><?php esc_html_e( $key, 'optimax-core' );?></label></th>
          <td>
            <input type="text" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( get_the_author_meta( $key, $user->ID ) ); ?>" class="regular-text" /><br />
            <span class="description"><?php esc_html_e( "Enter your {$key} profile url.", 'optimax-core' );?></span>
          </td>
        </tr>
      <?php endforeach ?>
    </table>
  <?php 

  }

  public function save_extra_profile_fields( $user_id ) {
    if ( !current_user_can( 'edit_user', $user_id ) ) {
      return false;
    }

    /* Edit the following lines according to your set fields */
    update_usermeta( $user_id, 'facebook', $_POST['facebook'] );
    update_usermeta( $user_id, 'twitter', $_POST['twitter'] );
    update_usermeta( $user_id, 'linkedin', $_POST['linkedin'] );
    update_usermeta( $user_id, 'pinterest', $_POST['pinterest'] );
    update_usermeta( $user_id, 'pinterest', $_POST['pinterest'] );
    update_usermeta( $user_id, 'tumblr', $_POST['tumblr'] );
    update_usermeta( $user_id, 'reddit', $_POST['reddit'] );
  }




}

function optimax_core_admin_notice() {
  $msg = sprintf( esc_html__( 'Error: Your current PHP version is %1$s. You need at least PHP version 5.3+" to work. Please ask your hosting provider to upgrade your PHP version into 5.3+', 'optimax-core' ), PHP_VERSION );
  echo '<div class="error"><p>' . $msg . '</p></div>';
}

if ( version_compare( PHP_VERSION, '5.6', '>=' ) ) {
  new Optimax_Core;
}
else {
  add_action( 'admin_notices', 'optimax_core_admin_notice' );
}

// Optimizer
require_once 'optimizer/__init__.php';

