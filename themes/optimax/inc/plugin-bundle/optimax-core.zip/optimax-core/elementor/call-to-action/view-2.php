<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );
$prefix     = Constants::$theme_prefix;
$thumb_size = "{$prefix}-size8";
$image_url  = Helper::generate_thumbnail_image_by_attachment_id_elementor( $bouncing_image, $thumb_size );
$anchor     = Helper::generate_elementor_anchor( $button_url, esc_html( $button_text ) . '<i class="fas fa-long-arrow-alt-right"></i>', 'btn-fill gradient-accent' );
?>
<div class="rtel-call-to-action2">
  <div class="row">
    <div class="col-lg-6">
      <div class="rtin-banner-box-layout1">
        <img src="<?php echo esc_url( $image_url ); ?>" alt="Call to action image">
      </div>
    </div>
    <div class="col-lg-6">
      <div class="rtin-banner-box-layout2">
        <h2 class="rtin-title"><?php echo wp_kses_post( $title ); ?></h2>
        <h2 class="rtin-subtitle"><?php echo wp_kses_post( $subtitle ); ?></h2>
        <?php echo wp_kses_post( $anchor ); ?>
      </div>
    </div>
  </div>
</div>
