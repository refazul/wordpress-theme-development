<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Utils;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Call_To_Action extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Call to action', 'optimax-core' );
    $this->rt_base = 'rt-call-to-action';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],

      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'default' => 'Lorem Ipsum title',
      ],
      [
        'type'      => Controls_Manager::TEXTAREA,
        'id'        => 'subtitle',
        'label'     => esc_html__( 'Subtitle', 'optimax-core' ),
        'default'   => 'Lorem Ipsum subtitle',
        'condition' => [ 'style' => [ 'style2', ] ],
      ],

      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'button_text',
        'label'       => esc_html__( 'Button Text', 'optimax-core' ),
        'default'     => "default",
      ],
      [
        'type'        => Controls_Manager::URL,
        'id'          => 'button_url',
        'label'       => esc_html__( 'Button Url', 'optimax-core' ),
        'default'     => ['url' => '#'],
      ],
      [
        'type'        => Controls_Manager::MEDIA,
        'condition'   => [ 'style' => [ 'style2', ] ],
        'id'          => 'bouncing_image',
        'label'       => __( 'Bouncing image', 'optimax-core' ),
        'description' => __( 'Upload Your image', 'optimax-core' ),
        'default' => [
          'url' => Utils::get_placeholder_image_src(),
        ],
      ],
      [
        'mode' => 'section_end',
      ],

      // style section started
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Title Color', 'optimax-core' ),
        'default'   => '#111',
        'selectors' => ['{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}'],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-title',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_2',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style2', ] ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'subtitle_color',
        'label'     => esc_html__( 'Subtitle Color', 'optimax-core' ),
        'default'   => '#111',
        'selectors' => ['{{WRAPPER}} .rtin-subtitle' => 'color: {{VALUE}}'],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'sub_title_typo',
        'label'          => esc_html__( 'Sub Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}} .rtin-subtitle',
      ],
      [
        'mode' => 'section_end',
      ],


    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style1':
        $template = 'view-1';
        break;
      case 'style2':
        $template = 'view-2';
        break;
      default:
        $template = 'view-1';
        break;
    }
    return $this->rt_template( $template, $data );
  }
}
