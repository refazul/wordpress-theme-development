<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );
$prefix = Constants::$theme_prefix;
extract($data);
$anchor = Helper::generate_elementor_anchor( $button_url, esc_html( $button_text ) . '<i class="fas fa-long-arrow-alt-right"></i>', 'btn-fill gradient-accent' );
?>
<div class="action-wrap-layout3 gradient-primary round-shape-2">
  <div class="action-box-layout3">
    <h2 class="item-title"><?php echo wp_kses_post( $title ); ?></h2>
    <div class="item-btn-wrap">
      <?php echo wp_kses_post( $anchor ); ?>
    </div>
  </div>
</div>