<?php 
namespace radiustheme\Optimax_Core;

use Elementor\Utils;
use radiustheme\Optimax\Helper;
extract( $data );
$image_url = Utils::get_placeholder_image_src();
$final_icon_class  = " flaticon-play-arrow";
$final_icon_image_url = '';

if ($image_id = $image['id']) {
  $image_url = Helper::generate_thumbnail_image_by_attachment_id( $image_id, $image_size);
}
if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
  $final_icon_class = $dynamic_icon_class;
}
if ( is_array( $icon_class['value'] ) ) {
  $final_icon_image_url = $icon_class['value']['url'];
}


?>

<div class="rtel-video-icon-1 <?php echo esc_html( $style ); ?>">
  <div class="rtin-img">
    <img src="<?php echo esc_url( $image_url ); ?>" alt="About">
    <div class="rtin-icon">
      <a class="play-btn popup-youtube" href="<?php  echo esc_url( $video_url ); ?>">
        <?php if ( $final_icon_image_url ): ?>
          <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="Video Icon">
        <?php else: ?>
          <i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
        <?php endif ?>
      </a>
    </div>
  </div>
</div>

