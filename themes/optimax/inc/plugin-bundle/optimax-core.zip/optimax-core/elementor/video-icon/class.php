<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class Video_Icon extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Video Icon', 'optimax-core' );
    $this->rt_base = 'rt-video-icon';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),

        ],
        'default' => 'style1',
      ],
      [
        'type'         => Controls_Manager::ICONS,
        'id'         => 'icon_class',
        'label'        => esc_html__( 'Icon', 'optimax-core' ),
        'default'      => [
          'value' => " flaticon-play-arrow",
        ],
      ],
      [ 
        'type'    => Controls_Manager::MEDIA,
        'id'      => 'image',
        'label'   => esc_html__( 'Image', 'optimax-core' ),
        'default' => [
          'url' => Utils::get_placeholder_image_src(),
        ],
        'description' => esc_html__( 'Recommended full image', 'optimax-core' ),
		'condition'   => [ 'style' => [ 'style1' ] ],
      ],

      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'id'        => 'image_size',
        'label'     => esc_html__( 'image size', 'optimax-core' ),
		'condition'   => [ 'style' => [ 'style1' ] ],
        'name'      => 'image',
        'separator' => 'none',   
      ],
	  [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'video_text',
        'label'       => esc_html__( 'Video Text', 'optimax-core' ),
        'default'     => 'Watch Video',
		'condition'   => [ 'style' => [ 'style2' ] ],
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'video_url',
        'label'       => esc_html__( 'Video URL', 'optimax-core' ),
        'default'     => 'https://www.youtube.com/watch?v=1iIZeIy7TqM',
      ],
	  [
        'type'    => Controls_Manager::CHOOSE,
		'mode'    => 'responsive',
        'options' => [
          'left' => [
            'title' => esc_html__( 'Left', 'optimax-core' ),
            'icon' => 'fas fa-align-left',
          ],
          'center' => [
            'title' => esc_html__( 'Center', 'optimax-core' ),
            'icon' => 'fas fa-align-center',
          ],
          'right' => [
            'title' => esc_html__( 'Right', 'optimax-core' ),
            'icon' => 'fas fa-align-right',
          ],
          'justify' => [
            'title' => esc_html__( 'Justified', 'optimax-core' ),
            'icon' => 'fas fa-align-justify',
          ],
        ],
        'id'      => 'text_align',
        'label'   => esc_html__( 'Text Align', 'optimax-core' ),
        'default' => 'left',
        'selectors' => [
          '{{WRAPPER}}' => 'text-align: {{VALUE}}',
          '{{WRAPPER}} .style2 .rtin-icon' => 'text-align: {{VALUE}}',
        ],
		'condition'   => [ 'style' => [ 'style2' ] ],
      ],
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'icon_style',
        'label'   => esc_html__( 'Icon Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'icon_bg_color',
        'label'   => esc_html__( 'Icon Background Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-video-icon-1 .rtin-icon .play-btn' => 'background-color: {{VALUE}}'
        ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'icon_color',
        'label'   => esc_html__( 'Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-video-icon-1 .rtin-icon .play-btn i' => 'color: {{VALUE}}'
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],

    ];
    return $fields;
  }
  protected function rt_load_scripts()
  {
    wp_enqueue_script('magnific-popup');
    wp_enqueue_style('magnific-popup');
  }

  protected function render() {
    $this->rt_load_scripts();
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style2':
	  $template = 'view-2';
        break;
      case 'style1':
        $template = 'view-1';
        break;
      default:
        $template = 'view-1';
        break;
    }    
    return $this->rt_template( $template, $data );
  }
}
