<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;


if ( ! defined( 'ABSPATH' ) ) exit;

class Progress_Bar extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Progress bar', 'optimax-core' );
    $this->rt_base = 'rt-progress-bar';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type' => Controls_Manager::SLIDER,
        'id'      => 'number_percent',
        'label'   => __( 'Percent Number', 'optimax-core' ),
        'size_units' => ['%'],
        'range' => [
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default' => [
          'unit' => '%',
          'size' => 75,
        ],
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'title',
        'label'       => esc_html__( 'Title', 'optimax-core' ),
        'default'     => "Finished projects",
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'title_style',
        'label'   => esc_html__( 'Title Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .progress .progress-bar span' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtin-title,
          {{WRAPPER}}  .rtel-progress-bar .progress .progress-bar span
        ',
      ],

      [
        'type' => Controls_Manager::SLIDER,
        'mode' => 'responsive',
        'id'      => 'title_position',
        'label'   => __( 'Title Spacing', 'optimax-core' ),
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => -100,
            'max' => 150,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => -47,
        ],
        'selectors' => [
          '{{WRAPPER}} .rtel-progress-bar .progress .lead' => 'top: {{SIZE}}{{UNIT}};',
          '{{WRAPPER}} .rtel-progress-bar .progress .progress-bar span' => 'top: {{SIZE}}{{UNIT}};',
        ]
      ],
      
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'progress_style',
        'label'   => esc_html__( 'Progress Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'progress_bar_background_color',
        'label'   => esc_html__( 'Progress Bar Background Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .progress' => 'background-color: {{VALUE}}' ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'progress_bar_color',
        'label'   => esc_html__( 'Progress Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .progress .progress-bar' => 'background-color: {{VALUE}}' ],
      ],
      [
        'mode' => 'section_end',
      ],

    ];
    return $fields;
  }

  protected function render() {
    $data = $this->get_settings();
    $template = 'view';
    return $this->rt_template( $template, $data );
  }
}
