<?php
namespace radiustheme\Optimax_Core;
extract($data);
$value = $number_percent['size'] . $number_percent['unit'];
?>
  <div class="rtel-progress-bar">
    <div class="progress">
      <div class="lead rtin-title"><?php echo esc_html( $title ); ?></div>
      <div style="width: <?php echo esc_attr( $value ); ?>; visibility: visible;"
      data-progress="<?php echo esc_attr( $value ); ?>" class="progress-bar">
      <span><?php echo esc_html( $value ); ?></span></div>
    </div>
  </div>

