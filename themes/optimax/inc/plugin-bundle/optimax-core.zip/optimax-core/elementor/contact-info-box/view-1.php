<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;

extract( $data );
$final_icon_class  = " fas fa-thumbs-up";
$final_icon_image_url = '';
if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
  $final_icon_class = $dynamic_icon_class;
}
if ( is_array( $icon_class['value'] ) ) {
  $final_icon_image_url = $icon_class['value']['url'];
}

?>
<div class="rtel-contact-info-box">
  <div class="media media-none--md">
    <div class="rtin-icon">
      <?php if ( $final_icon_image_url ): ?>
        <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
      <?php else: ?>
        <i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
      <?php endif ?>
    </div>
    <div class="media-body space-md">
      <h3 class="rtin-title"><?php if ( $title_url['url'] ) : ?> <?php $all_attributes = Helper::generate_elementor_anchor_attributes( $title_url  ); ?> <a <?php echo wp_kses_post( $all_attributes ); ?> ><?php echo esc_html( $title ); ?></a> <?php else: ?> <?php echo esc_html( $title ); ?> <?php endif ?> </h3>
      <div class="rtin-subtitle"><?php echo wp_kses_post( $subtitle ); ?></div>
    </div>
  </div>
</div>