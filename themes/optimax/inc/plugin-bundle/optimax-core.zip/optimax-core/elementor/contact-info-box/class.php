<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Contact_Info_Box extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Contact Info Box', 'optimax-core' );
    $this->rt_base = 'rt-contact-info-box';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'title',
        'label'       => esc_html__( 'Title', 'optimax-core' ),
        'default'     => 'Lorem ipsum dolor sit amet.',
      ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'subtitle',
        'label'       => esc_html__( 'Subtitle', 'optimax-core' ),
        'default'     => 'Lorem ipsum dolor sit amet.',
      ],
      [
        'type'         => Controls_Manager::ICONS,
        'id'           => 'icon_class',
        'label'        => esc_html__( 'Icon', 'optimax-core' ),
        'default'      => [
          'value' => "fas fa-thumbs-up",
        ],
      ],
      [
        'type'        => Controls_Manager::URL,
        'id'          => 'title_url',
        'label'       => esc_html__( 'Title Url', 'optimax-core' ),
        'default'     => [ 'url' => ''],
      ],

      [
        'mode' => 'section_end',
      ],      

      // title style
      [
        'mode'    => 'section_start',
        'id'      => 'sec_title_style',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title Color', 'optimax-core' ),
        'default' => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box .media .media-body .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2 .media .media-body .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box3 .media .media-body .rtin-title' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_hover_color',
        'label'     => esc_html__( 'Title Link Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box .media .media-body .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2 .media .media-body .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box3 .media .media-body .rtin-title a:hover' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtel-contact-info-box .media .media-body .rtin-title, {{WRAPPER}}  .rtel-contact-info-box2 .media .media-body .rtin-title, {{WRAPPER}}  .rtel-contact-info-box3 .media .media-body .rtin-title',
      ],
      [
        'mode' => 'section_end',
      ],

      // subtitle
      [
        'mode'    => 'section_start',
        'id'      => 'sec_subtitle_style',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'subtitle_color',
        'label'     => esc_html__( 'Subtitle Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box .media .media-body .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2 .media .media-body .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box3 .media .media-body .rtin-subtitle' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'Subtitle Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}} .rtel-contact-info-box .media .media-body .rtin-subtitle, {{WRAPPER}} .rtel-contact-info-box2 .media .media-body .rtin-subtitle, {{WRAPPER}} .rtel-contact-info-box3 .media .media-body .rtin-subtitle',
      ],
      
      [
        'mode' => 'section_end',
      ],

      // icon style
      [
        'mode'    => 'section_start',
        'id'      => 'sec_icon_style',
        'label'   => esc_html__( 'Icon', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'icon_color',
        'label'     => esc_html__( 'Icon Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box .rtin-icon i:before' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2 .media .rtin-icon i:before' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box3 .media .rtin-icon i:before' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'icon_background_color',
        'label'     => esc_html__( 'Icon Background Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box .media .rtin-icon' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2 .media .rtin-icon' => 'background-color: {{VALUE}}',
        ],
		'condition'   => [ 'style' => [ 'style1', 'style2' ] ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'hover_icon_color',
        'label'     => esc_html__( 'Hover Icon Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box:hover .media .rtin-icon i:before' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2:hover .media .rtin-icon i:before' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box3:hover .media .rtin-icon i:before' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'hover_icon_background_color',
        'label'     => esc_html__( 'Hover Icon Background Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-contact-info-box:hover .media .rtin-icon' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-contact-info-box2:hover .media .rtin-icon' => 'background-color: {{VALUE}}',
        ],
		'condition'   => [ 'style' => [ 'style1', 'style2' ] ],
      ],
      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }


  protected function render() {
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style3':
        $template = 'view-3';
        break;
      case 'style2':
        $template = 'view-2';
        break;
      default:
        $template = 'view-1';
        break;
    }
    return $this->rt_template( $template, $data );
  }
}
