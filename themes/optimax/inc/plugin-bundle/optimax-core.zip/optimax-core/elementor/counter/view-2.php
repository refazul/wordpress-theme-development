<?php
namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;
extract( $data );

$image_url = Utils::get_placeholder_image_src();

$image_url = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );

?>

<div class="rtel-counter-2 <?php echo esc_html( $style ); ?>">
  <div class="rtin-counter">
    <div class="rtin-counter-right">
      <div class="rtin-counter-right-content">
		    <?php echo wp_kses_post($image_url);?>   
        <div class="counter-number-postfix-wrapper">
          <span class="counter counter-number" data-num="<?php echo esc_attr( $number ); ?>">
            <?php echo esc_html( $number ); ?>
          </span>
          <?php if ($counter_postfix) { ?>
            <span class="counter-postfix"><?php echo esc_html( $counter_postfix ); ?></span>
          <?php } ?>
		  <?php if ($title) { ?>
		  <div class="counter-title"><?php echo esc_html( $title ); ?></div>
		  <?php } ?>
        </div>
		
      </div>
    </div>
  </div>
</div>
