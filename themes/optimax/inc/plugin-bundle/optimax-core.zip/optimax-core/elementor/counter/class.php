<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use \Elementor\Utils;
use radiustheme\Optimax\Helper;
use radiustheme\Optimax\URI_Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Counter extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Counter', 'optimax-core' );
    $this->rt_base = 'rt-counter';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
	  [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),

        ],
        'default' => 'style1',
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'number',
        'label'       => esc_html__( 'Number', 'optimax-core' ),
        'default'     => '480',
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'title',
        'label'       => esc_html__( 'Title', 'optimax-core' ),
        'default'     => "Finished projects",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'counter_postfix',
        'label'       => esc_html__( 'Counter Postfix', 'optimax-core' ),
        'default'     => "+",
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'time',
        'description' => 'One Second equal to 1000 millisecond. Here Default 15000 millisecond equal 15 seconds',
        'label'       => __( 'Total duration in millisecond', 'optimax-core' ),
        'default'     => 5000,
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'delay',
        'description' => 'The delay in milliseconds per number count up',
        'label'       => __( 'Delay in millisecond', 'optimax-core' ),
        'default'     => 50,
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'has_icon',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Has Icon', 'optimax-core' ),
        'default'     => "no",
		'condition'   => [ 'style' => [ 'style1' ] ],
      ],
      [
        'type'        => Controls_Manager::ICON,
        'condition'   => [ 'has_icon' => 'yes' ],
        'id'          => 'icon_class',
        'label'       => esc_html__( 'Icon', 'optimax-core' ),
        'default'     => "fa fa-dribbble",
      ],
	  [ 
        'type'    => Controls_Manager::MEDIA,
        'id'      => 'image',
        'label'   => esc_html__( 'Image', 'optimax-core' ),
        'default' => [
          'url' => Utils::get_placeholder_image_src(),
        ],
        'description' => esc_html__( 'Recommended full image', 'optimax-core' ),
		'condition'   => [ 'style' => [ 'style2' ] ],
      ],

      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'name'        => 'image_size',
        'label'     => esc_html__( 'image size', 'optimax-core' ),
		    'condition'   => [ 'style' => [ 'style2' ] ],
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'number_style',
        'label'   => esc_html__( 'Number style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'number_color',
        'label'     => esc_html__( 'Number Color', 'optimax-core' ),
        'default'   => '#ff5b17',
        'selectors' => [ '{{WRAPPER}} .counter-number' => 'color: {{VALUE}}' ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'number_typo',
        'label'          => esc_html__( 'Number Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .counter-number',
      ],
	  [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'content_position',
        'label'      => __( 'Content Position', 'optimax-core' ),
        'size_units' => ['%'],
        'range'      => [
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default'    => [
          'unit' => '%',
          'size' => 50,
        ],
        'selectors'  => [
          '{{WRAPPER}} .rtel-counter-2 .counter-number-postfix-wrapper' => 'top: {{SIZE}}{{UNIT}};',
        ],
		'condition'   => [ 'style' => [ 'style2' ] ],
      ],

      [
        'mode' => 'section_end',
      ],
      // number style ended 
      [
        'mode'    => 'section_start',
        'id'      => 'postfix_style',
        'label'   => esc_html__( 'postfix style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'postfix_color',
        'label'     => esc_html__( 'postfix Color', 'optimax-core' ),
        'default'   => '#ff5b17',
        'selectors' => [ '{{WRAPPER}} .counter-postfix' => 'color: {{VALUE}}' ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'postfix_typo',
        'label'          => esc_html__( 'postfix Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .counter-postfix',
      ],

      [
        'mode' => 'section_end',
      ],
      // number style ended 

      [
        'mode'    => 'section_start',
        'id'      => 'title_style',
        'label'   => esc_html__( 'Title style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Title Color', 'optimax-core' ),
        'default'   => '#444444',
        'selectors' => [ '{{WRAPPER}} .counter-title' => 'color: {{VALUE}}' ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .counter-title',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_content_margin',
        'label'      => __( 'Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .counter-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],
      // end title style
      [
        'mode'      => 'section_start',
        'id'        => 'icon_style',
        'condition'   => [ 'style' => [ 'style1' ] ],
        'label'     => esc_html__( 'Icon style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'icon_color',
        'label'     => esc_html__( 'Icon Color', 'optimax-core' ),
        'default'   => '#111',
        'selectors' => [ '{{WRAPPER}} .rtel-counter-1 .rtin-counter .rtin-counter-left i' => 'color: {{VALUE}}' ],
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'Icon Font Size',
        'label'      => __( 'Icon Font Size', 'optimax-core' ),
        'size_units' => ['px'],
        'range'      => [
          'px' => [
            'min' => 0,
            'max' => 200,
          ],
        ],
        'default'    => [
          'unit' => 'px',
          'size' => 50,
        ],
        'selectors'  => [
          '{{WRAPPER}} .rtel-counter-1 .rtin-counter .rtin-counter-left i' => 'font-size: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'Icon spacing',
        'label'      => __( 'Icon Spacing', 'optimax-core' ),
        'size_units' => ['px'],
        'range'      => [
          'px' => [
            'min' => 0,
            'max' => 400,
          ],
        ],
        'default'    =>    [
          'unit' => 'px',
          'size' => 40,
        ],
        'selectors'  =>  [
          '{{WRAPPER}} .rtel-counter-1 .rtin-counter .rtin-counter-left' => 'margin-right: {{SIZE}}{{UNIT}};',
        ]
      ],

      
      [
        'mode' => 'section_end',
      ],

    ];
    return $fields;
  }

  protected function rt_load_scripts()
  {
    wp_enqueue_script('waypoints');
    wp_enqueue_script('jquery-counterup');
  }

  protected function render() {
    $this->rt_load_scripts();
    $data = $this->get_settings();
    $template = 'view-1';
	
	switch ( $data['style'] ) {
      case 'style2':
	  $template = 'view-2';
        break;
      case 'style1':
        $template = 'view-1';
        break;
      default:
        $template = 'view-1';
        break;
    }   
	
    return $this->rt_template( $template, $data );
  }
}
