<?php
namespace radiustheme\Optimax_Core;
extract( $data );
?>

<div class="rtel-counter-1 <?php echo esc_html( $style ); ?>">
  <div class="rtin-counter">
    <?php if ( $has_icon == 'yes' ): ?>
      <div class="rtin-counter-left">
        <i class="<?php echo esc_attr( $icon_class ); ?>"></i>
      </div>
    <?php endif ?>
    <div class="rtin-counter-right">
      <div class="rtin-counter-right-content">
        <div class="counter-number-postfix-wrapper">
          <div class="counter counter-number" data-num="<?php echo esc_attr( $number ); ?>">
            <?php echo esc_html( $number ); ?>
          </div>
          <?php if ($counter_postfix): ?>
            <div class="counter-postfix"><?php echo esc_html( $counter_postfix ); ?></div>
          <?php endif ?>
        </div>
        <div class="counter-title"><?php echo esc_html( $title ); ?></div>
      </div>
    </div>
  </div>
</div>
