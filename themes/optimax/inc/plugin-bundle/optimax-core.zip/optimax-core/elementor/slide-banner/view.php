<?php 

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;

extract( $data );


// default value

$main_image_url     = Helper::get_img('essential/rocket.png');
$bottom_image_1_url = Helper::get_img('essential/cloud1.png');
$bottom_image_2_url = Helper::get_img('essential/cloud2.png');

if ( $main_image['url'] ) {
  $main_image_url;
}

if ($main_image_id = $main_image['id']) {
  $main_image_url = Helper::generate_thumbnail_image_by_attachment_id( $main_image_id, $main_image_size);
}

if ($bottom_image_1_id  = $bottom_image_1['id']) {
  $bottom_image_1_url = Helper::generate_thumbnail_image_by_attachment_id( $bottom_image_1_id, $bottom_image_1_size);
}

if ($bottom_image_2_id  = $bottom_image_2['id']) {
  $bottom_image_2_url = Helper::generate_thumbnail_image_by_attachment_id( $bottom_image_2_id, $bottom_image_2_size);
}

?>
<div class="rtel-slide-banner-1">
  <div class="row">
    <div class="col">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-12">
            <div class="banner-content">
              <div class="banner-subtitle"><?php echo esc_html( $subtitle ); ?></div>
              <h1 class="banner-title"><?php echo esc_html( $title ); ?></h1>
              <div class="banner-form-box">
                <?php echo  wp_kses_post( $short_code ); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-4 d-none d-lg-block">
            <div class="banner-rocket">
              <img src="<?php echo esc_url( $main_image_url ); ?>" alt="Slide Banner Image">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="cloud-bottom">
    <div class="cloud-dark">
      <img src="<?php echo esc_url( $bottom_image_1_url ); ?>" alt="Bottom Image 1">
    </div>
    <div class="cloud-light">
      <img src="<?php echo esc_url( $bottom_image_2_url ); ?>" alt="Bottom Image 2">
    </div>
  </div>
</div>
