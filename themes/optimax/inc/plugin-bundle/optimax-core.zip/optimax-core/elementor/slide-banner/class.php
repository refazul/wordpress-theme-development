<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Slide_Banner extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Slide Banner', 'optimax-core' );
    $this->rt_base = 'rt-slide-banner';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'title',
        'label'       => esc_html__( 'Title', 'optimax-core' ),
        'default'     => "Check your SEO Score",
      ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'subtitle',
        'label'       => esc_html__( 'Subtitle', 'optimax-core' ),
        'default'     => "See how well your page is optimized",
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'short_code',
        'label'   => esc_html__( 'Short Code', 'optimax-core' ),
        'default' => '',
      ],
      [
        'type' => Controls_Manager::SLIDER,
        'mode' => 'responsive',
        'id'      => 'padding_top',
        'label'   => __( 'Content Padding Top', 'optimax-core' ),
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 800,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => 330,
        ],
        'selectors' => [
          '{{WRAPPER}}  .rtel-slide-banner-1' => 'padding-top: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type' => Controls_Manager::SLIDER,
        'mode' => 'responsive',
        'id'      => 'padding_bottom',
        'label'   => __( 'Content Padding Bottom', 'optimax-core' ),
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 800,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => 350,
        ],
        'selectors' => [
          '{{WRAPPER}}  .rtel-slide-banner-1' => 'padding-bottom: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type'        => Controls_Manager::MEDIA,
        'id'          => 'main_image',
        'label'       => esc_html__( 'Main image', 'optimax-core' ),
      ],
      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'label'     => esc_html__( 'Main Image size', 'optimax-core' ),    
        'name'      => 'main_image', 
        'separator' => 'none',        
        'default'   => 'full',
      ],
      [
        'type'        => Controls_Manager::MEDIA,
        'id'          => 'bottom_image_1',
        'label'       => esc_html__( 'Bottom Image 1', 'optimax-core' ),
      ],
      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'id'        => 'bottom_image_1_size',
        'label'     => esc_html__( 'Bottom image 1 size', 'optimax-core' ),    
        'name'      => 'bottom_image_1',
        'separator' => 'none',        
        'default'   => 'full',
      ],
      [
        'type'        => Controls_Manager::MEDIA,
        'id'          => 'bottom_image_2',
        'label'       => esc_html__( 'Bottom image 2', 'optimax-core' ),
      ],
      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'id'        => 'bottom_image_2_size',
        'label'     => esc_html__( 'Bottom Image 2 Size', 'optimax-core' ),    
        'name'      => 'bottom_image_2',
        'separator' => 'none',        
        'default'   => 'full',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'title_style',
        'label'   => esc_html__( 'Title Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-slide-banner-1 .banner-content .banner-title
        ',
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-slide-banner-1 .banner-content .banner-title' => 'color: {{VALUE}}'
        ],
      ],
      [
        'type'    => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'      => 'title_content_margin',
        'label'   => __( 'Title Margin', 'optimax-core' ),                 
        'selectors' => [
          '{{WRAPPER}} .rtel-slide-banner-1 .banner-content .banner-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator' => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'subtitle_style',
        'label'   => esc_html__( 'Subtitle Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'Subtitle Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-slide-banner-1 .banner-content .banner-subtitle
        ',
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'subtitle_color',
        'label'   => esc_html__( 'Subtitle color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-slide-banner-1 .banner-content .banner-subtitle' => 'color: {{VALUE}}'
        ],
      ],
      [
        'type'    => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'      => 'subtitle_content_margin',
        'label'   => __( 'Subtitle Margin', 'optimax-core' ),                 
        'selectors' => [
          '{{WRAPPER}} .rtel-slide-banner-1 .banner-content .banner-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator' => 'before',
      ],
      
      
      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }
  protected function render() {
    $data     = $this->get_settings();
    $template = 'view';
    return $this->rt_template( $template, $data );
  }
}
