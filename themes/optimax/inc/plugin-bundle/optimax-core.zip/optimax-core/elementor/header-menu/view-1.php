<?php
namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\RDTheme;
extract( $data );
?>
<div class='main-header-area'>
  <div class="main-header-block">
     <?php
      get_template_part( 'template-parts/header/header', $style );
      get_template_part( 'template-parts/header/mobile/header', 'mobile');
      ?>
  </div>
</div>
