<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class Header_Menu extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Header Menu', 'optimax-core' );
    $this->rt_base = 'rt-header-menu';
    parent::__construct( $data, $args );
  }


  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SELECT,
        'id'          => 'style',
        'description' => 'NB: It actually render default menu. So menu related all style will be available inside post 
          meta. go to edit page and change menu style from there. Like full width menu, transparent menu',
        'label'       => esc_html__( 'Layout Style', 'optimax-core' ),
        'options'     => [
          '1' => esc_html__( 'style 1', 'optimax-core' ),
          '2' => esc_html__( 'style 2', 'optimax-core' ),
          '3' => esc_html__( 'style 3', 'optimax-core' ),
        ],
        'default'     => '1',
      ],

      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
