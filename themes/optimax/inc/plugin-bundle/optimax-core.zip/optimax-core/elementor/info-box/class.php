<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class Info_Box extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Info Box', 'optimax-core' );
    $this->rt_base = 'rt-service-info-box';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
        ],
        'default' => 'style1',
       ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'title',
        'label'       => esc_html__( 'Title', 'optimax-core' ),
        'default'     => 'Lorem ipsum dolor sit amet.',
      ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'subtitle',
        'label'       => esc_html__( 'Subtitle', 'optimax-core' ),
        'default'     => 'Lorem ipsum dolor sit amet.',
        'condition'   => [ 'style' => [ 'style1', 'style2', 'style4' ] ],
      ],
      [
        'type'     => Controls_Manager::ICONS,
        'id'       => 'icon_class',
        'label'    => esc_html__( 'Icon', 'optimax-core' ),
        'default'  => [
          'value' => "fas fa-thumbs-up",
        ],
      ],
		[
			'type'    => Controls_Manager::MEDIA,
			'id'      => 'icon_image',
			'label'   => esc_html__( 'Image', 'optimax-core' ),
			'default' => array(
				'url' => Utils::get_placeholder_image_src(),
			),
			'description' => esc_html__( 'Recommended full image', 'optimax-core' ),
			'condition'   => [ 'style' => [ 'style4' ] ],
		],
		[
			'type'    => Group_Control_Image_Size::get_type(),
			'mode'    => 'group',				
			'label'   => esc_html__( 'image size', 'optimax-core' ),	
			'name' => 'icon_image_size', 
			'separator' => 'none',		
			'condition'   => [ 'style' => [ 'style4' ] ],
		],
      [
        'type'        => Controls_Manager::URL,
        'id'          => 'title_url',
        'label'       => esc_html__( 'Title Url', 'optimax-core' ),
        'default'     => [ 'url' => ''],
      ],
      
      [
        'mode' => 'section_end',
      ], 

      //
      // title style
      //
      [
        'mode'    => 'section_start',
        'id'      => 'sec_title_style',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Title Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-body .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-info-box-3 .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-info-box-3 .rtin-title a' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_link_hover_color',
        'label'     => esc_html__( 'Title Link Hover Color (If it has Link)', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-body .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-info-box-3 .rtin-title a:hover' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-body .rtin-title,
          {{WRAPPER}} .rtel-info-box-3 .rtin-title,
          {{WRAPPER}} .rtel-info-box-3 .rtin-title a
        ',
      ],
      [
        'mode' => 'section_end',
      ],     

      //
      // subtitle style
      //
      [
        'mode'      => 'section_start',
        'id'        => 'sec_subtitle_style',
        'label'     => esc_html__( 'subtitle', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style1', 'style2', 'style4' ] ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'subtitle_color',
        'label'     => esc_html__( 'Subtitle Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-body .rtin-subtitle' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'subtitle Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-body .rtin-subtitle',
      ],
      [
        'mode' => 'section_end',
      ],  

      // 
      // Icon style
      // 
      [
        'mode'    => 'section_start',
        'id'      => 'sec_icon_style',
        'label'   => esc_html__( 'Icon', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'icon_color',
        'label'     => esc_html__( 'Icon Color', 'optimax-core' ),
        'default'   => '',
        'selectors' => [
          '{{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-icon-wrapper .rtin-icon i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-info-box-3 .rtin-icon i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-info-box-4 .rtin-info-box .rtin-img i' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'      => 'group',
        'type'      => Group_Control_Background::get_type(),
        'name'      => 'icon_background_color',
        'title'     => __( 'On Hover Background', 'uael' ),
        'selector'  => '{{WRAPPER}} .rtel-info-box .rtin-info-box .rtin-icon-wrapper .rtin-icon',
        'condition' => [ 'style' => [ 'style1', 'style2' ] ],
      ],
      [
        'mode' => 'section_end',
      ],

    ];
    return $fields;
  }


  protected function render() {
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style4':
        $template = 'view-4';
        break;
      case 'style3':
        $template = 'view-3';
        break;
      case 'style2':
        $template = 'view-2';
        break;
      default:
        $template = 'view-1';
        break;
    }
    return $this->rt_template( $template, $data );
  }
}
