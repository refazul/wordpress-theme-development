<?php
namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
extract($data);

$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'icon_image' );
$final_icon_class       = " fas fa-thumbs-up";
if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
  $final_icon_class     = $dynamic_icon_class;
}
?>
<div class="rtel-info-box rtel-info-box-4">
  <div class="rtin-info-box">
    <div class="rtin-img-wrapper">
      <div class="rtin-img">
        <?php if ( $getimg ) { ?>
          <?php echo wp_kses_post($getimg);?>
		  <i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
        <?php } ?>
      </div>
    </div>
    <div class="rtin-body">
      <h3 class="rtin-title">
        <?php if ( $title_url['url'] ): ?>
          <?php 
          $all_attributes = Helper::generate_elementor_anchor_attributes( $title_url  );
          ?>
          <a <?php echo wp_kses_post( $all_attributes ); ?> ><?php echo esc_html( $title ); ?></a>
        <?php else: ?>
          <?php echo esc_html( $title ); ?>
        <?php endif ?>
      </h3>
      <p class="rtin-subtitle"><?php echo esc_html( $subtitle ); ?></p>
    </div>
  </div>
</div>
