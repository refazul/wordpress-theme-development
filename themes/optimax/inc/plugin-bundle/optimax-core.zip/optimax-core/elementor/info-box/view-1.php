<?php
namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$final_icon_class       = " fas fa-thumbs-up";
$final_icon_image_url   = '';
if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
  $final_icon_class     = $dynamic_icon_class;
}
if ( is_array( $icon_class['value'] ) ) {
  $final_icon_image_url = $icon_class['value']['url'];
}
?>
<div class="rtel-info-box rtel-info-box-1">
  <div class="rtin-info-box">
    <div class="rtin-icon-wrapper">
      <div class="rtin-icon gradient-accent">
        <?php if ( $final_icon_image_url ): ?>
          <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
        <?php else: ?>
          <i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
        <?php endif ?>
      </div>
    </div>
    <div class="rtin-body">
      <h3 class="rtin-title">
        <?php if ( $title_url['url'] ): ?>
          <?php 
          $all_attributes = Helper::generate_elementor_anchor_attributes( $title_url  );
          ?>
          <a <?php echo wp_kses_post( $all_attributes ); ?> ><?php echo esc_html( $title ); ?></a>
        <?php else: ?>
          <?php echo esc_html( $title ); ?>
        <?php endif ?>
      </h3>
      <p class="rtin-subtitle"><?php echo esc_html( $subtitle ); ?></p>
    </div>
  </div>
</div>
