<?php

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );
$text1 = wpautop( $text, true );
$href_target_attr = Helper::generate_elementor_anchor_attributes($button_url);
?>

<div class="rtel-title-subtitle-text-button-1">
  <div class="rtin-tsbt">
    <div class="rtin-subtitle"><?php echo esc_html( $subtitle ); ?></div>
    <h2 class="rtin-title"><?php echo wp_kses_post( $title ); ?></h2>
    <p class="rtin-text"><?php echo wp_kses_post( $text ); ?></p>
	
	<?php if(!empty($button_text)) { ?>
    <?php if ( $button_style == 'style1' ) : ?>
      <a <?php echo wp_kses_post( $href_target_attr ); ?> class="btn-fill gradient-accent"><?php echo esc_html( $button_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
    <?php elseif ($button_style == 'style2'): ?>
      <a <?php echo wp_kses_post( $href_target_attr ); ?> class="ghost-btn-2 text-accent border-accent mg-t-20">
        <?php echo esc_html( $button_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
    <?php endif; ?>
    <?php } ?>
  </div>
</div>
