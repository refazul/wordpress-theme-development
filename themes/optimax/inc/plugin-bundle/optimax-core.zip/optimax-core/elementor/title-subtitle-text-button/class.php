<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Title_Subtitle_Text_Button extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Title Subtitle Text Button', 'optimax-core' );
    $this->rt_base = 'rt-title-subtitle-text-button';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],

      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'title',
        'label'       => esc_html__( 'Title', 'optimax-core' ),
        'default'     => "We are the best Agency Of Marketing Expert",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'subtitle',
        'label'       => esc_html__( 'Subtitle Top', 'optimax-core' ),
        'default'     => "The Best Marketing Expert In The World",
      ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'text',
        'label'       => esc_html__( 'Text', 'optimax-core' ),
        'default'     => "Innovation is hard. It really is. Because most people don't get it. Remember, the automobile, the airplane, their are telephone, these were all considered toys at their are introduction because they had no constituency. \n
                          There are people who intensely clutch an idea that yoga is a higher system, not to be lowered to the weight loss even fitness category... ",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'button_text',
        'label'       => esc_html__( 'Button Text', 'optimax-core' ),
        'default'     => "More About Us",
      ],
      [
        'type'        => Controls_Manager::URL,
        'id'          => 'button_url',
        'label'       => esc_html__( 'Button URL', 'optimax-core' ),
        'default'     => [ 'url' => '#'],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'button_style',
        'label'   => esc_html__( 'Button Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],

      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title color', 'optimax-core' ),
        'default' => '#444444',
        'selectors' => [ '{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}' ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-title',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_subtitle',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'subtitle_color',
        'label'   => esc_html__( 'Subtitle Color', 'optimax-core' ),
        'default' => '#444444',
        'selectors' => [ '{{WRAPPER}} .rtin-subtitle' => 'color: {{VALUE}}' ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'Subtitle Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-subtitle',
      ],
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_text',
        'label'   => esc_html__( 'Text', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'text_color',
        'label'   => esc_html__( 'Text Color', 'optimax-core' ),
        'default' => '#444444',
        'selectors' => [
          '{{WRAPPER}} .rtin-text' => 'color: {{VALUE}};',
          '{{WRAPPER}} .rtin-text p' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'text_typo',
        'label'          => esc_html__( 'Text Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-text',
      ],
      
      [
        'mode' => 'section_end',
      ],
      
      
    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
