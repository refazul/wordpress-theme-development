<?php
namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
?>

<div class="rt-animate-image animate-image-<?php echo esc_attr( $data['style'] ); ?>">
	<div class="figure-holder">
		<div class="right-holder wow <?php echo esc_attr( $data['animation_right'] ); ?> " data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="450" height="640" src="<?php echo Helper::get_img('shape/shape-7.png'); ?>" alt="shape-7">
		</div>
	</div>
</div>