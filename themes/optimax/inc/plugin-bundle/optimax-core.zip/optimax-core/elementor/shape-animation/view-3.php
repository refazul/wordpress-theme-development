<?php
namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
?>

<div class="rt-animate-image animate-image-<?php echo esc_attr( $data['style'] ); ?>">
	<div class="figure-holder">
		<div class="left-holder wow <?php echo esc_attr( $data['animation_left'] ); ?>" data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="551" height="350" src="<?php echo Helper::get_img('shape/shape-5.png');  ?>" alt="shape-5">
		</div>
		<div class="right-holder wow <?php echo esc_attr( $data['animation_right'] ); ?> " data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="233" height="636" src="<?php echo Helper::get_img('shape/shape-6.png'); ?>" alt="shape-6">
		</div>
	</div>
</div>