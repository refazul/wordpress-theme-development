<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Shape_Animation extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Shape Animation', 'optimax-core' );
    $this->rt_base = 'rt-shape-animation';
    parent::__construct( $data, $args );
  }
  
  public function rt_fields(){
    $fields = [      
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
          'style5' => esc_html__( 'style 5', 'optimax-core' ),
			],
        'default' => 'style1',
       ],
	   
	   [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'animation_left',
        'label'   => esc_html__( 'Animation Left', 'optimax-core' ),
        'options' => [		
			'bounce' => esc_html__( 'bounce', 'optimax-core' ),
			'flash' => esc_html__( 'flash', 'optimax-core' ),
			'pulse' => esc_html__( 'pulse', 'optimax-core' ),
			'rubberBand' => esc_html__( 'rubberBand', 'optimax-core' ),
			'shakeX' => esc_html__( 'shakeX', 'optimax-core' ),
			'shakeY' => esc_html__( 'shakeY', 'optimax-core' ),
			'headShake' => esc_html__( 'headShake', 'optimax-core' ),
			'swing' => esc_html__( 'swing', 'optimax-core' ),
			'tada' => esc_html__( 'tada', 'optimax-core' ),
			'wobble' => esc_html__( 'wobble', 'optimax-core' ),
			'jello' => esc_html__( 'jello', 'optimax-core' ),
			'heartBeat' => esc_html__( 'heartBeat', 'optimax-core' ),			
			'bounceIn' => esc_html__( 'bounceIn', 'optimax-core' ),
			'bounceInDown' => esc_html__( 'bounceInDown', 'optimax-core' ),
			'bounceInLeft' => esc_html__( 'bounceInLeft', 'optimax-core' ),
			'bounceInRight' => esc_html__( 'bounceInRight', 'optimax-core' ),
			'bounceInUp' => esc_html__( 'bounceInUp', 'optimax-core' ),			
			'slideInDown' => esc_html__( 'slideInDown', 'optimax-core' ),
			'slideInLeft' => esc_html__( 'slideInLeft', 'optimax-core' ),
			'slideInRight' => esc_html__( 'slideInRight', 'optimax-core' ),
			'slideInUp' => esc_html__( 'slideInUp', 'optimax-core' ), 
			],
        'default' => 'slideInLeft',
		'condition' => [ 'style' => [ 'style1', 'style3', 'style5' ] ],
       ],
	   
	   [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'animation_right',
        'label'   => esc_html__( 'Animation Right', 'optimax-core' ),
        'options' => [		
			'bounce' => esc_html__( 'bounce', 'optimax-core' ),
			'flash' => esc_html__( 'flash', 'optimax-core' ),
			'pulse' => esc_html__( 'pulse', 'optimax-core' ),
			'rubberBand' => esc_html__( 'rubberBand', 'optimax-core' ),
			'shakeX' => esc_html__( 'shakeX', 'optimax-core' ),
			'shakeY' => esc_html__( 'shakeY', 'optimax-core' ),
			'headShake' => esc_html__( 'headShake', 'optimax-core' ),
			'swing' => esc_html__( 'swing', 'optimax-core' ),
			'tada' => esc_html__( 'tada', 'optimax-core' ),
			'wobble' => esc_html__( 'wobble', 'optimax-core' ),
			'jello' => esc_html__( 'jello', 'optimax-core' ),
			'heartBeat' => esc_html__( 'heartBeat', 'optimax-core' ),			
			'bounceIn' => esc_html__( 'bounceIn', 'optimax-core' ),
			'bounceInDown' => esc_html__( 'bounceInDown', 'optimax-core' ),
			'bounceInLeft' => esc_html__( 'bounceInLeft', 'optimax-core' ),
			'bounceInRight' => esc_html__( 'bounceInRight', 'optimax-core' ),
			'bounceInUp' => esc_html__( 'bounceInUp', 'optimax-core' ),			
			'slideInDown' => esc_html__( 'slideInDown', 'optimax-core' ),
			'slideInLeft' => esc_html__( 'slideInLeft', 'optimax-core' ),
			'slideInRight' => esc_html__( 'slideInRight', 'optimax-core' ),
			'slideInUp' => esc_html__( 'slideInUp', 'optimax-core' ),
			],
        'default' => 'slideInRight',
		'condition' => [ 'style' => [ 'style1', 'style2', 'style3', 'style4', 'style5' ] ],
       ],
	   
	   [
        'type'    => Controls_Manager::TEXT,
        'id'      => 'delay',
        'label'   => esc_html__( 'Delay', 'optimax-core' ),
        'default' => '0.51s',
		'description' => esc_html__( 'Use delay 0.51s default', 'optimax-core' ),
       ],
	   
	   [
        'type'    => Controls_Manager::TEXT,
        'id'      => 'duration',
        'label'   => esc_html__( 'Duration', 'optimax-core' ),
        'default' => '2s',
		'description' => esc_html__( 'Use Duration 2s default', 'optimax-core' ),
       ],
		[
		'type'    => Controls_Manager::NUMBER,
		'id'      => 'left_position',
		'mode'    => 'responsive',
		'label'   => esc_html__( 'Left Shape Position', 'optimax-core' ),
		'selectors' => array(
		  '{{WRAPPER}} .rt-animate-image .left-holder' => 'top: {{VALUE}}px',
		),
		'default' => '',
		'description' => esc_html__( 'Use unit px', 'optimax-core' ),
		],
		[
		'type'    => Controls_Manager::NUMBER,
		'id'      => 'right_position',
		'mode'    => 'responsive',
		'label'   => esc_html__( 'Right Shape Position', 'optimax-core' ),
		'selectors' => array(
		  '{{WRAPPER}} .rt-animate-image .right-holder' => 'top: {{VALUE}}px',
		),
		'default' => '',
		'description' => esc_html__( 'Use unit px', 'optimax-core' ),
		],
      
		[
		'mode' => 'section_end',
		],     

    ];
    return $fields;
  }


  protected function render() {
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style5':
        $template = 'view-5';
        break;
      case 'style4':
        $template = 'view-4';
        break;
      case 'style3':
        $template = 'view-3';
        break;
      case 'style2':
        $template = 'view-2';
        break;
      default:
        $template = 'view-1';
        break;
    }
	
    return $this->rt_template( $template, $data );
  }
}
