<?php
namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
?>

<div class="rt-animate-image animate-image-<?php echo esc_attr( $data['style'] ); ?>">
	<div class="figure-holder">
		<div class="left-holder wow <?php echo esc_attr( $data['animation_left'] ); ?>" data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="720" height="439" src="<?php echo Helper::get_img('shape/shape-4.png');  ?>" alt="shape-4">
		</div>
		<div class="right-holder wow <?php echo esc_attr( $data['animation_right'] ); ?>" data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="363" height="1166" src="<?php echo Helper::get_img('shape/shape-1.png'); ?>" alt="shape-1">
		</div>
	</div>
</div>