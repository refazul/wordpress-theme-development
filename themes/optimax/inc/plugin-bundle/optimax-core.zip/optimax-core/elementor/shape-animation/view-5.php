<?php
namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
?>

<div class="rt-animate-image animate-image-<?php echo esc_attr( $data['style'] ); ?>">
	<div class="figure-holder">
		<div class="left-holder wow <?php echo esc_attr( $data['animation_left'] ); ?>" data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="387" height="1008" src="<?php echo Helper::get_img('shape/shape-10.png');  ?>" alt="shape-10">
		</div>
		<div class="right-holder wow <?php echo esc_attr( $data['animation_right'] ); ?>" data-wow-delay="<?php echo esc_attr( $data['delay'] ); ?>" data-wow-duration="<?php echo esc_attr( $data['duration'] ); ?>">			
			<img width="611" height="884" src="<?php echo Helper::get_img('shape/shape-11.png'); ?>" alt="shape-11">
		</div>
	</div>
</div>