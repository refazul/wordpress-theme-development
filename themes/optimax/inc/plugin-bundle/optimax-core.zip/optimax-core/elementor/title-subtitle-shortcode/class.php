<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Title_Subtitle_Shortcode extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Title Subtitle Shortcode', 'optimax-core' );
    $this->rt_base = 'rt-title-subtitle-email-subscribe';
    parent::__construct( $data, $args );
  }

  public function rt_fields() {
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'default' => 'Lorem ipsum dolor sit amet.',
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'subtitle',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam optio sint dolor, architecto cum qui nesciunt, neque tempore.',
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'short_code',
        'label'   => esc_html__( 'Short Code', 'optimax-core' ),
        'default' => '',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title Color', 'optimax-core' ),
        'default' => '#111111',
        'selectors' => ['{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}'],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}} .rtin-title',
      ], 
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_margin',
        'label'      => __( 'Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-title-subtitle-email-subscribe .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator'  => 'before',
      ],

      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_subtitle',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'subtitle_color',
        'label'   => esc_html__( 'Sub title Color', 'optimax-core' ),
        'default' => '#111111',
        'selectors' => ['{{WRAPPER}} .rtin-subtitle' => 'color: {{VALUE}}'],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'Subtitle Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-subtitle',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'subtitle_margin',
        'label'      => __( 'Subtitle Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-title-subtitle-email-subscribe .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator'  => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'shortcode_style',
        'label'   => esc_html__( 'Shortcode Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'shortcode_width',
        'label'      => __( 'Shortcode Width', 'optimax-core' ),
        'size_units' => ['px', '%'],
        'range'      => [
          'px' => [
            'min' => 0,
            'max' => 2000,
          ],
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default'    => [
          'unit' => '%',
          'size' => 80,
        ],
        'selectors'  => [
          '{{WRAPPER}} .rtel-title-subtitle-email-subscribe .rtin-content .rtin-form' => 'width: {{SIZE}}{{UNIT}};',
        ]
      ],
      
      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }

  protected function render() {
    $data = $this->get_settings();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
