<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
extract($data);
?>

<div class="rtel-title-subtitle-email-subscribe">
  <div class="rtin-content">
    <div class="rtin-heading">
      <?php if ( $title ): ?>
        <h2 class="rtin-title"><?php echo esc_html( $title ); ?></h2>
      <?php endif ?>
      <?php if ( $subtitle ): ?>
        <p class="rtin-subtitle"><?php echo wp_kses_post( nl2br( $subtitle ) ); ?></p>
      <?php endif ?>
    </div>
    <div class="rtin-form">
      <?php echo  wp_kses_post( $short_code ); ?>
    </div>
  </div>
</div>


