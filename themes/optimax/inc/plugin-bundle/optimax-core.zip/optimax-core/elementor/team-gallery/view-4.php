<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
use radiustheme\Optimax\RDTheme;

extract( $data );

$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";
$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size10";
$args = [
  'post_type'        => "{$prefix}_team",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
];

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_team_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}
$posts = get_posts( $args );
?>
<div class="rtel-team-gallery4">
  <div class="rtin-team-gallery">
  <div class="owl-theme owl-carousel rt-owl-carousel nav-control-layout4" data-carousel-options="<?php echo esc_attr( $owl_data );?>">
    <?php foreach ($posts as $post): ?>
      <?php
      $img          = Helper::generate_thumbnail_image( $post, $thumb_size );
      $designation  = get_post_meta( $post->ID, "{$prefix}_team_designation", true );
      $socials      = get_post_meta( $post->ID, "{$prefix}_team_socials", true );
      $permalink    = get_the_permalink($post);
      $content      = Helper::generate_excerpt($post, 25);
      ?>
      <div class="rtin-team-each-post">
        <div class="rtin-team-box-layout-content">
          <div class="row">
            <div class="col-lg-6">
              <div class="rtin-img">
                <img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $post->post_title ); ?>">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="rtin-content-wrapper">
                <div class="rtin-content">
                  <h3 class="rtin-title"><a href="<?php echo esc_attr( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h3>
                  <?php if ($designation): ?>
                    <div class="rtin-subtitle"><?php echo esc_html( $designation ); ?></div>
                  <?php endif ?>
                  <?php if (count($socials) ): ?>
                    <ul class="rtin-social">
                      <?php foreach (Helper::team_social_infos() as $social_info): ?>
                        <?php if ( isset( $socials[$social_info['key']] ) && $link = $socials[$social_info['key']]): ?>
                          <li>
                            <a href="<?php echo esc_attr($link); ?>">
                              <i class="<?php echo esc_attr( $social_info['icon'] ); ?>"></i>
                            </a>
                          </li>
                        <?php endif ?>
                      <?php endforeach ?>
                    </ul>
                  <?php endif ?>
                  <p class="team-excerpt"><?php echo wp_kses_post( $content ); ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
    <div class="row">
      <div class="col-lg-6"></div>
      <div class="col-lg-6">
        <div id="<?php echo esc_attr( $data['uniqueid'] ); ?>" class="rtin-smart-nav-layout1"></div>
      </div>
    </div>

  </div>
</div>
