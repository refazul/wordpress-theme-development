<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Team_Gallery extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Team Gallery', 'optimax-core' );
    $this->rt_base = 'rt-team-gallery';
    $this->rt_translate = [
      'cols'  => [
        // here its bootstrap class
        '12' => esc_html__( '1 Col', 'optimax-core' ),
        '6'  => esc_html__( '2 Col', 'optimax-core' ),
        '4'  => esc_html__( '3 Col', 'optimax-core' ),
        '3'  => esc_html__( '4 Col', 'optimax-core' ),
        '2'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
      'cols_slider'  => [
        '1'  => esc_html__( '1 Col', 'optimax-core' ),
        '2'  => esc_html__( '2 Col', 'optimax-core' ),
        '3'  => esc_html__( '3 Col', 'optimax-core' ),
        '4'  => esc_html__( '4 Col', 'optimax-core' ),
        '5'  => esc_html__( '5 Col', 'optimax-core' ),
        '6'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
    ];

    parent::__construct( $data, $args );
  }

  private function rt_cat_dropdown() {
    $prefix = Constants::$theme_prefix;

    $terms = get_terms( [
      'taxonomy' => "{$prefix}_team_category",
      'hide_empty' => true,
    ]);

    $category_dropdown = [];
    foreach ( $terms as $category ) {
      $category_dropdown[$category->term_id] = $category->name;
    }

    return $category_dropdown;
  }
  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
          'style5' => esc_html__( 'style 5', 'optimax-core' ),
          'style6' => esc_html__( 'style 6', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'pagination_display',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Pagination', 'optimax-core' ),
        'default'     => "no",
        'condition' => [ 'style' => [ 'style3' ] ],
      ],
      [
        'type'        => Controls_Manager::SELECT2,
        'id'          => 'multiple_category',
        'label'       => __( 'Categories', 'optimax-core' ),
        'options'     => $this->rt_cat_dropdown(),
        'multiple'    => true,
        'description' => esc_html__( 'All categories is selected by default', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'posts_per_page',
        'label'       => esc_html__( 'Posts Per Page', 'optimax-core' ),
        'default'     => 3,
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'orderby',
        'label'   => esc_html__( 'Order By', 'optimax-core' ),
        'options' => [
          'date'        => esc_html__( 'Date (Recents comes first)', 'optimax-core' ),
          'title'       => esc_html__( 'Title', 'optimax-core' ),
          'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'optimax-core' ),
        ],
        'default' => 'date',
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'optimax_slider_top',
        'condition' => [ 'style' => [ 'style4', ] ],
        'label'      => __( 'Slider Nav Top Position', 'optimax-core' ),
        'size_units' => ['px'],
        'range'      => [
          'px' => [
            'min' => -200,
            'max' => 200,
          ],
        ],
        'default'    => [
          'unit' => 'px',
          'size' => -46,
        ],
        'selectors'  => [
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-smart-nav-layout1' => 'top: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'optimax_slider_left',
        'condition' => [ 'style' => [ 'style4', ] ],
        'label'      => __( 'Slider Nav Left Position', 'optimax-core' ),
        'size_units' => ['px'],
        'range'      => [
          'px' => [
            'min' => -200,
            'max' => 200,
          ],
        ],
        'default'    => [
          'unit' => 'px',
          'size' => 15,
        ],
        'selectors'  => [
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-smart-nav-layout1' => 'Left: {{SIZE}}{{UNIT}};',
        ]
      ],
      
      [
        'mode' => 'section_end',
      ],

      // Responsive Columns for general
      // it will generate bootstrap column
      [
        'mode'    => 'section_start',
        'condition'   => ['style' => [ 'style3', 'style5', 'style6']],
        'id'      => 'sec_responsive',
        'label'   => esc_html__( 'Number of Responsive Columns', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xl',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '6',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm',
        'label'   => esc_html__( 'Phones: > 576px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '12',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col',
        'label'   => esc_html__( 'Phones: < 576px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '12',
      ],
      [
        'mode' => 'section_end',
      ],


      ///////////////////////////////////////////////////////////////////////////////////
      // Responsive Columns for slider
      [
        'mode'    => 'section_start',
        'id'      => 'sec_responsive_slider',
        'condition' => [ 'style' => [ 'style1', 'style2' ] ],
        'label'   => esc_html__( 'Number of Responsive Columns for slider', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg_slider',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md_slider',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '3',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm_slider',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '2',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xs_slider',
        'label'   => esc_html__( 'Phones: < 768px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_mobile_slider',
        'label'   => esc_html__( 'Small Phones: < 480px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'mode' => 'section_end',
      ],

      // Slider options
      [
        'mode'        => 'section_start',
        'id'          => 'sec_slider',
        'label'       => esc_html__( 'Slider Options', 'optimax-core' ),
        'condition' => [ 'style' => [ 'style1', 'style2', 'style4',  ] ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_autoplay',
        'label'       => esc_html__( 'Autoplay', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_stop_on_hover',
        'label'       => esc_html__( 'Stop on Hover', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Stop autoplay on mouse hover. Default: On', 'optimax-core' ),
        'condition'   => [ 'slider_autoplay' => 'yes' ],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'slider_interval',
        'label'   => esc_html__( 'Autoplay Interval', 'optimax-core' ),
        'options' => [
          '5000' => esc_html__( '5 Seconds', 'optimax-core' ),
          '4000' => esc_html__( '4 Seconds', 'optimax-core' ),
          '3000' => esc_html__( '3 Seconds', 'optimax-core' ),
          '2000' => esc_html__( '2 Seconds', 'optimax-core' ),
          '1000' => esc_html__( '1 Second',  'optimax-core' ),
        ],
        'default' => '5000',
        'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'optimax-core' ),
        'condition'   => [ 'slider_autoplay' => 'yes' ],
      ],
      [
        'type'    => Controls_Manager::NUMBER,
        'id'      => 'slider_autoplay_speed',
        'label'   => esc_html__( 'Autoplay Slide Speed', 'optimax-core' ),
        'default' => 200,
        'description' => esc_html__( 'Slide speed in milliseconds. Default: 200', 'optimax-core' ),
        'condition'   => [ 'slider_autoplay' => 'yes' ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_loop',
        'label'       => esc_html__( 'Loop', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Loop to first item. Default: On', 'optimax-core' ),
      ],
      [
        'mode' => 'section_end',
      ],
      // Starting Style Section 
      // Title Style
      [
        'mode'    => 'section_start',
        'id'      => 'title_style_section',
        'label'   => esc_html__( 'Title Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Title Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-title a' => 'color: {{VALUE}}',
         
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_hover_color',
        'label'     => esc_html__( 'Title Hover Color', 'optimax-core' ),
        // selector hover is bit tricky
        'selectors' => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        // Its Not An ARRAY
        // Its Not An ARRAY
        'selector'       => '
          {{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-title a,
          {{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-title
          
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_margin',
        'label'      => __( 'Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
       
        ],
        'separator'  => 'before',
      ],
      [
        'mode' => 'section_end',
      ],
      // Subtitle/designation Style
      [
        'mode'    => 'section_start',
        'id'      => 'designation_style_section',
        'label'   => esc_html__( 'Designation Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'designation_color',
        'label'     => esc_html__( 'Designation Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-subtitle' => 'color: {{VALUE}}',
         
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'designation_typo',
        'label'          => esc_html__( 'Designation Typography', 'optimax-core' ),
        // Its Not An ARRAY
        // Its Not An ARRAY
        'selector'       => '
          {{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-subtitle,
          {{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-subtitle,
          {{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-subtitle,
          {{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-subtitle
          
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'designation_margin',
        'label'      => __( 'Designation Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-team-gallery2-v2 .rtin-team-box-layout .rtin-content .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator'  => 'before',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'social_icon_style',
        'label'   => esc_html__( 'Social Icon Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style1', 'style3', 'style4' ] ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'social_icon_background_color',
        'label'   => esc_html__( 'Social Icon Background Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-social li a' => 'background-color: {{VALUE}}' ],
        'condition' => [ 'style' => [ 'style3'] ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'social_icon_hover_background_color',
        'label'   => esc_html__( 'Social Icon Hover Background Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-social li a:hover' => 'background-color: {{VALUE}}' ],
        'condition' => [ 'style' => [ 'style3'] ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'social_icon_color',
        'label'   => esc_html__( 'Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-social li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-social li a i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-social li a' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'social_icon_hover_color',
        'label'   => esc_html__( 'Icon Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-team-gallery1-v2 .rtin-team-gallery .rtin-team-box-layout .rtin-content .rtin-social li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery3-v2 .rtin-team-box-layout .rtin-content .rtin-social li a:hover i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .rtin-social li a:hover' => 'color: {{VALUE}}',
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],
      // Content Style
      array(
        'mode'      => 'section_start',
        'id'        => 'content_style',
        'label'     => esc_html__( 'Content Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
      ),
      array(
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'content_typo',
        'label'          => esc_html__( 'Content Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .team-excerpt,
          {{WRAPPER}}  noselector
        ',
      ),
      array(
        'type'      => Controls_Manager::COLOR,
        'id'        => 'content_color',
        'label'     => esc_html__( 'Content Color', 'optimax-core' ),
        'selectors' => array(
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .team-excerpt' => 'color: {{VALUE}}',
          '{{WRAPPER}} noselector' => 'color: {{VALUE}}',
        ),
      ),
      array(
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => array( 'px', '%', 'em' ),
        'id'         => 'content_content_margin',
        'mode'       => 'responsive',
        'label'      => __( 'Content Margin', 'optimax-core' ),                 
        'selectors'  => array(
          '{{WRAPPER}} .rtel-team-gallery4 .rtin-team-gallery .rtin-team-each-post .rtin-team-box-layout-content .rtin-content .team-excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} noselector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ),
        'separator'  => 'before',
      ),      
      array(
        'mode' => 'section_end',
      ),
    ];
    return $fields;
  }

  private function rt_load_scripts(){
    wp_enqueue_style( 'owl-carousel' );
    wp_enqueue_script( 'owl-carousel' );
  }

  public function generate_owl_settings($data) {

    $owl_data = [
      'nav'                => true,
      'navText'            => ['<i class="fas fa-angle-left" aria-hidden="true"></i>', '<i class="fas fa-angle-right" aria-hidden="true"></i>'],
      'dots'               => false,
      'autoplay'           => $data['slider_autoplay'] == 'yes' ? true : false,
      'autoplayTimeout'    => $data['slider_interval'],
      'autoplaySpeed'      => $data['slider_autoplay_speed'],
      'autoplayHoverPause' => $data['slider_stop_on_hover'] == 'yes' ? true : false,
      'loop'               => $data['slider_loop'] == 'yes' ? true : false,
      'margin'             => 10,
      'smartSpeed'         => 1200,
      'items'              => 1,
    ];



    if ( $data['style'] == 'style4' ) {
      $owl_data['navContainer'] = '#'.$data['uniqueid'];
      $owl_data['navText']      = array('<i class="fas fa-long-arrow-alt-left"></i>', '<i class="fas fa-long-arrow-alt-right"></i>') ;
    } else {
      $owl_data['responsive'] = [
        '0'    => [
          'items' => $data['col_mobile_slider'],
          'nav'   => false,
          'dots'  => false,
        ],
        '480'  => [
          'items' => $data['col_xs_slider'],
          'nav'   => false,
          'dots'  => false,
        ],
        '768'  => [
          'items' => $data['col_sm_slider'],
          'nav'   => true,
          'dots'  => false,
        ],
        '992'  => [
          'items' => $data['col_md_slider'],
          'nav'   => true,
          'dots'  => false,
        ],
        '1200' => [
          'items' => $data['col_lg_slider'],
          'nav'   => true,
          'dots'  => false,
        ],
      ];
    }
    
    if ( is_rtl () ) {
      $owl_data['rtl'] = true;
    }
    return $owl_data;
  }


  protected function render() {

    $data = $this->get_settings();
    $uniqueid = 'id-'.uniqid();
    $data['uniqueid'] = $uniqueid;
    $owl_data = $this->generate_owl_settings( $data );
    $data['owl_data'] = json_encode( $owl_data );

    $this->rt_load_scripts();


    switch ( $data['style'] ) {
      case 'style2':
      $template = 'view-2';
      break;
      case 'style3':
      $template = 'view-3';
      break;
      case 'style4':
      $template = 'view-4';
      break;
      case 'style5':
      $template = 'view-5';
      break;
      case 'style6':
      $template = 'view-6';
      break;
      default:
      $template = 'view-1';
      break;
    }

    return $this->rt_template( $template, $data );

  }

}
