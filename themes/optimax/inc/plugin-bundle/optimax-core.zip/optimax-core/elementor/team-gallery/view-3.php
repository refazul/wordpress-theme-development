<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
use radiustheme\Optimax\RDTheme;

extract( $data );
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";
$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";
$args = [
  'post_type'        => "{$prefix}_team",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_team_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";

?>
<div class="rtel-team-gallery3-v2">
  <div class="rtin-team-gallery">
    <div class="row">
      <?php while( $query->have_posts() ): $query->the_post(); ?>
        <?php
        $post         = get_post();
        $img          = Helper::generate_thumbnail_image( $post, $thumb_size );
        $designation  = get_post_meta( $post->ID, "{$prefix}_team_designation", true );
        $socials      = get_post_meta( $post->ID, "{$prefix}_team_socials", true );
        $permalink    = get_the_permalink($post);
        $content      = Helper::generate_excerpt($post, 15);
        ?>
        <div class="<?php echo esc_attr( $col_class ); ?>">
          <div class="rtin-team-box-layout">
            <div class="rtin-img">
              <?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail(); ?><?php } ?>
            </div>
            <div class="rtin-content">
              <h3 class="rtin-title"><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h3>
              <?php if ( $designation ): ?>
                <div class="rtin-subtitle"><?php echo esc_html( $designation ); ?></div>
              <?php endif ?>

              <?php 

                $social_wrapper_class_name_list = [
                  '1' => 'one-item',
                  '2' => 'two-items',
                  '3' => 'three-items',
                  '4' => 'four-items',
                ];
                $filtered_socials = Helper::filter_filled_team_socials( $socials );
                $number_of_socials = count( $filtered_socials );
                $social_wrapper_class_name = 'five-items';
                if ( array_key_exists( $number_of_socials, $social_wrapper_class_name_list) ) {
                  $social_wrapper_class_name = $social_wrapper_class_name_list[ $number_of_socials ];
                }
               ?>

              <?php if ( $number_of_socials ): ?>
                <ul class="rtin-social <?php echo esc_attr( $social_wrapper_class_name ); ?>">
                  <?php foreach (Helper::team_social_infos() as $social_info): ?>
                    <?php if ( isset( $socials[$social_info['key']] ) && $link = $socials[$social_info['key']]): ?>
                      <li>
                        <a href="<?php echo esc_attr($link); ?>">
                          <i class="<?php echo esc_attr( $social_info['icon'] ); ?>"></i>
                        </a>
                      </li>
                    <?php endif ?>
                  <?php endforeach ?>
                </ul>
              <?php endif ?>

            </div>
          </div>
        </div>
      <?php endwhile; ?>
  
    </div>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>
