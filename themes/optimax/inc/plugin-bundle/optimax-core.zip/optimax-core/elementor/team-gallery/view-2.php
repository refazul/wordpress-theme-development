<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
use radiustheme\Optimax\RDTheme;

extract( $data );
use \WP_Query;

$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";
$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";
$thumb_size  = "full";
$args = [
  'post_type'        => "{$prefix}_team",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
];

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_team_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$query = new WP_Query( $args );
?>
<div class="rtel-team-gallery2-v2">
  <div class="rtin-team-gallery">
  <div class="owl-carousel rt-owl-carousel nav-control-layout1" data-carousel-options="<?php echo esc_attr( $owl_data );?>">
    <?php if ( $query->have_posts() ) :?>
		<?php while ( $query->have_posts() ) : $query->the_post();?>
		  <?php
		  $id            	= get_the_id();
		  $designation  = get_post_meta( $id, "{$prefix}_team_designation", true );
		  $socials  = get_post_meta( $id, "{$prefix}_team_socials", true );
		  ?>
		  <div class="rtin-team-box-layout">
			<div class="rtin-img">
			  <?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail( $thumb_size ); ?><?php } ?>
			</div>
			<div class="rtin-content">
			  <h3 class="rtin-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
			  <div class="rtin-subtitle"><?php echo esc_html( $designation ); ?></div>
			  <?php if (count($socials) ): ?>
				<ul class="rtin-social">
				  <?php foreach (Helper::team_social_infos() as $social_info): ?>
					<?php if ( isset( $socials[$social_info['key']] ) && $link = $socials[$social_info['key']]): ?>
					  <li>
						<a href="<?php echo esc_attr($link); ?>" class="bg-<?php echo esc_attr( $social_info['key'] ); ?>">
						  <i class="<?php echo esc_attr( $social_info['icon'] ); ?>"></i>
						</a>
					  </li>
					<?php endif ?>
				  <?php endforeach ?>
				</ul>
			  <?php endif ?>
			</div>
		  </div>
		<?php endwhile;?>
	<?php endif;?>
    </div>
  </div>
</div>
