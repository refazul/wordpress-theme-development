<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class Brand_Showcase extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'brand Showcase', 'optimax-core' );
    $this->rt_base = 'rt-brand-showcase';
    $this->rt_translate = [
      'cols_slider'  => [
        '1'  => esc_html__( '1 Col', 'optimax-core' ),
        '2'  => esc_html__( '2 Col', 'optimax-core' ),
        '3'  => esc_html__( '3 Col', 'optimax-core' ),
        '4'  => esc_html__( '4 Col', 'optimax-core' ),
        '5'  => esc_html__( '5 Col', 'optimax-core' ),
        '6'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
    ];
    parent::__construct( $data, $args );
  }

  private function rt_load_scripts(){
    wp_enqueue_style( 'owl-carousel' );
    wp_enqueue_script( 'owl-carousel' );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'has_border',
        'label'   => esc_html__( 'Has Border', 'optimax-core' ),
        'options' => [
          'has-border' => esc_html__( 'Yes', 'optimax-core' ),
          'no-border' => esc_html__( 'No', 'optimax-core' ),
        ],
        'default' => 'no-border',
      ],
      
      [
        'type'    => Controls_Manager::REPEATER,
        'id'      => 'clients',
        'label'   => esc_html__( 'Upload clients logo', 'optimax-core' ),
        'fields'  => [
          [
            'type'  => Controls_Manager::MEDIA,
            'name'  => 'image',
            'label' => esc_html__( 'Image', 'optimax-core' ),
          ],
          [
            'type'  => Controls_Manager::URL,
            'name'  => 'button_url',
            'label' => esc_html__( 'URL(optional)', 'optimax-core' ),
          ],
          [
            'type'    => Controls_Manager::TEXT,
            'name'    => 'alt_text',
            'label'   => esc_html__( 'Alternative Text', 'optimax-core' ),
            'default' => 'Brand image'
          ],
        ],
      ],
      [
        'mode' => 'section_end',
      ],
      // Slider options
      [
        'mode'        => 'section_start',
        'id'          => 'sec_slider',
        'label'       => esc_html__( 'Slider Options', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_autoplay',
        'label'       => esc_html__( 'Autoplay', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_stop_on_hover',
        'label'       => esc_html__( 'Stop on Hover', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Stop autoplay on mouse hover. Default: On', 'optimax-core' ),
        'condition'   => ['slider_autoplay' => 'yes'],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'slider_interval',
        'label'   => esc_html__( 'Autoplay Interval', 'optimax-core' ),
        'options' => [
          '5000' => esc_html__( '5 Seconds', 'optimax-core' ),
          '4000' => esc_html__( '4 Seconds', 'optimax-core' ),
          '3000' => esc_html__( '3 Seconds', 'optimax-core' ),
          '2000' => esc_html__( '2 Seconds', 'optimax-core' ),
          '1000' => esc_html__( '1 Second',  'optimax-core' ),
        ],
        'default' => '5000',
        'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'optimax-core' ),
        'condition'   => ['slider_autoplay' => 'yes'],
      ],
      [
        'type'    => Controls_Manager::NUMBER,
        'id'      => 'slider_autoplay_speed',
        'label'   => esc_html__( 'Autoplay Slide Speed', 'optimax-core' ),
        'default' => 200,
        'description' => esc_html__( 'Slide speed in milliseconds. Default: 200', 'optimax-core' ),
        'condition'   => ['slider_autoplay' => 'yes'],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_loop',
        'label'       => esc_html__( 'Loop', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Loop to first item. Default: On', 'optimax-core' ),
      ],
      [
        'mode' => 'section_end',
      ],
      // Responsive Columns for slider
      [
        'mode'    => 'section_start',
        'id'      => 'sec_responsive_slider',
        'label'   => esc_html__( 'Number of Responsive Columns', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg_slider',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '5',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md_slider',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm_slider',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '2',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xs_slider',
        'label'   => esc_html__( 'Phones: < 768px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_mobile_slider',
        'label'   => esc_html__( 'Small Phones: < 480px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'mode' => 'section_end',
      ],
      // Responsive Columns for general
    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    $owl_data = [
      'nav'                => true,
      'navText'            => ['<i class="fas fa-angle-left" aria-hidden="true"></i>', '<i class="fas fa-angle-right" aria-hidden="true"></i>'],
      'dots'               => false,
      'autoplay'           => $data['slider_autoplay'] == 'yes' ? true : false,
      'autoplayTimeout'    => $data['slider_interval'],
      'autoplaySpeed'      => $data['slider_autoplay_speed'],
      'autoplayHoverPause' => $data['slider_stop_on_hover'] == 'yes' ? true : false,
      'loop'               => $data['slider_loop'] == 'yes' ? true : false,
      'margin'             => 30,
      'smartSpeed'         => 1200,
      'responsive'         => [
        '0'    => [
          'items' => $data['col_mobile_slider'],
          'nav'   => false,
          'dots'  => false,
        ],
        '480'  => [
          'items' => $data['col_xs_slider'],
          'nav'   => false,
          'dots'  => false,
        ],
        '768'  => [
          'items' => $data['col_sm_slider'],
          'nav'   => true,
          'dots'  => false,
        ],
        '992'  => [
          'items' => $data['col_md_slider'],
          'nav'   => true,
          'dots'  => false,
        ],
        '1200' => [
          'items' => $data['col_lg_slider'],
          'nav'   => true,
          'dots'  => false,
        ],
      ]
    ];
    if ( is_rtl () ) {
      $owl_data['rtl'] = true;
    }

    $data['owl_data'] = json_encode( $owl_data );
    $this->rt_load_scripts();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
