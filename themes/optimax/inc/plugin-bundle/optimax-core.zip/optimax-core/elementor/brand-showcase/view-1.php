<?php

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );
?>
<div class="rtel-brand-showcase">
  <div class="owl-carousel rt-owl-carousel nav-control-layout4" data-carousel-options="<?php echo esc_attr( $owl_data );?>">
    <?php foreach ($clients as $client): ?>
      <div class="rtin-brand-box <?php echo esc_attr( $has_border ); ?>">
        <div class="item-img">
          <?php if ( $url =  $client['button_url']['url']  ): ?>
            <?php 
              $anchor_attr = Helper::generate_elementor_anchor_attributes( $client['button_url'] );

            ?>
            <a <?php echo wp_kses_post( $anchor_attr ); ?> >
              <?php echo wp_get_attachment_image( $client['image']['id'], 'full' )?>
            </a>
          <?php else: ?>
            <?php echo wp_get_attachment_image( $client['image']['id'], 'full' )?>
          <?php endif ?>
        </div>
      </div>
    <?php endforeach ?>
  </div>
</div>

