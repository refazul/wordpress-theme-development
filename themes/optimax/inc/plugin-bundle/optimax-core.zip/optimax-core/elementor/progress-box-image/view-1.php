<?php 
namespace radiustheme\Optimax_Core;

use Elementor\Utils;
use radiustheme\Optimax\Helper;
extract( $data );

$top_image_url = Utils::get_placeholder_image_src();

if ($top_image_id = $top_image['id']) {
  $top_image_url = Helper::generate_thumbnail_image_by_attachment_id( $top_image_id, $top_image_size);
}

$bottom_image_url = Utils::get_placeholder_image_src();

if ($bottom_image_id = $bottom_image['id']) {
  $bottom_image_url = Helper::generate_thumbnail_image_by_attachment_id( $bottom_image_id, $bottom_image_size);
}

?>
<div class="rtel-progress-box-image-1">
  <div class="rtin-progress-box">
    <div class="item-img">
      <img src="<?php echo esc_url( $top_image_url ); ?>" alt="progress">
      <div class="bottom-img">
        <img src="<?php echo esc_url( $bottom_image_url ); ?>" alt="progress">
      </div>
    </div>
  </div> 
</div>
