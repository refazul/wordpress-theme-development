<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class Progress_Box_Image extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Progress Box Image', 'optimax-core' );
    $this->rt_base = 'rt-progress-box-image';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [ 
        'type'    => Controls_Manager::MEDIA,
        'id'      => 'top_image',
        'label'   => esc_html__( 'Top Image', 'optimax-core' ),
        'default' => [
          'url' => Utils::get_placeholder_image_src(),
        ],
        'description' => esc_html__( 'Recommended full image', 'optimax-core' ),
      ],

      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'id'        => 'top_image_size',
        'label'     => esc_html__( 'image size', 'optimax-core' ),    
        'name'      => 'top_image',
        'separator' => 'none',        
      ],
      [ 
        'type'    => Controls_Manager::MEDIA,
        'id'      => 'bottom_image',
        'label'   => esc_html__( 'Bottom Image', 'optimax-core' ),
        'default' => [
          'url' => Utils::get_placeholder_image_src(),
        ],
        'description' => esc_html__( 'Recommended full image', 'optimax-core' ),
      ],

      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'id'        => 'bottom_image_size',
        'label'     => esc_html__( 'image size', 'optimax-core' ),    
        'name'      => 'bottom_image',
        'separator' => 'none',        
      ],
      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
