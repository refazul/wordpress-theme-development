<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";

$args = [
  'post_type'        => "{$prefix}_service",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,

];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_service_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";

?>
<div class="rtel-service-gallery1">
  <div class="rtin-service-wrap">
    <div class="row">
      <?php
      while( $query->have_posts() ): $query->the_post();
        $post                  = get_post();
        $title                 = $post->post_title;
        $excerpt               = Helper::generate_excerpt( $post, $no_of_excerpt_words );
        $permalink             = get_the_permalink($post);
        $thumb                 = Helper::generate_thumbnail_image( $post, $thumb_size );
        $service_icon          = get_post_meta( $post->ID, "{$prefix}_service_icon", true );
        $service_image         = get_post_meta( $post->ID, "{$prefix}_service_image", true );
        $service_color         = get_post_meta( $post->ID, "{$prefix}_service_color", true );
        $service_color         = $service_color ? $service_color : '#ff9317';
        $service_background    = "background-color: {$service_color}";
        if ($service_image) {
          $thumb            = Helper::generate_thumbnail_image_by_attachment_id($service_image, $thumb_size);
        }
        ?>
        <div class="<?php echo esc_attr( $col_class ); ?>">
          <div class="rtin-service-box">
            <?php if ($service_image): ?>
              <div class="rtin-img">
                <img class="img-responsive" src="<?php echo esc_url( $thumb ); ?>">
              </div>
            <?php else: ?>
              <div class="rtin-icon" style="<?php echo esc_attr( $service_background ); ?>">
                <i class="<?php echo esc_attr( $service_icon ); ?>"></i>
              </div>
            <?php endif ?>
            <div class="rtin-content">
                <h3 class="rtin-title"><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></h3>
                <p>
                  <?php echo esc_html( $excerpt ); ?>
                </p>
                <?php if ( $read_more_text ): ?>
                  <a href="<?php echo esc_url( $permalink ); ?>" class="rtin-btn readmore"><?php echo esc_html( $read_more_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
                <?php endif ?>
            </div>
          </div>

        </div>
      <?php endwhile; ?>
    </div>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>
