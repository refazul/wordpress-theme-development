<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Mexitek\PHPColors\Color;
use radiustheme\Optimax\Helper;
extract($data);
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";

$args = [
  'post_type'        => "{$prefix}_service",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_service_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );

if ( $posts_per_page % 2 == 1 ) {
	$is_offset = 'offset-lg-3 offset-md-3 offset-xl-0 ';
}

$col_class = " col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";

?>
<div class="rtel-service-gallery5">
  <div class="rtin-service-wrap">
    <div class="row">
      <?php
	  $i = 1;
      while( $query->have_posts() ) { $query->the_post();
        $post                  = get_post();
        $title                 = $post->post_title;
        $excerpt               = Helper::generate_excerpt( $post, $no_of_excerpt_words );
        $permalink             = get_the_permalink($post);
        $thumb                 = Helper::generate_thumbnail_image( $post, $thumb_size );
        $service_icon          = get_post_meta( $post->ID, "{$prefix}_service_icon", true );
        $service_image         = get_post_meta( $post->ID, "{$prefix}_service_image", true );
        $service_color         = get_post_meta( $post->ID, "{$prefix}_service_color", true );
        $service_color_2         = get_post_meta( $post->ID, "{$prefix}_service_color_2", true );
        $service_color         = $service_color ? $service_color : '#ff975f';
        $service_color_2       = $service_color_2 ? $service_color_2 : '#ff1744';
		
        if ($service_image) {
          $thumb = Helper::generate_thumbnail_image_by_attachment_id($service_image, $thumb_size);
        }
        ?>
        <div class="<?php if ( ( $i == $posts_per_page ) && ( $posts_per_page % 2 == 1 ) ) { echo esc_attr( $is_offset ); } echo esc_attr( $col_class ); ?>">

          <div class="rtin-service-box">
             <?php if ( $service_image && ( $show_iconimage == 'image' ) ) { ?>
              <div class="rtin-img">
                <img class="img-responsive" src="<?php echo esc_url( $thumb ); ?>" alt="<?php the_title_attribute(); ?>">
              </div>
			 <?php } else { ?>
              <div class="rtin-icon"> 
                <i class="<?php echo esc_attr( $service_icon ); ?>"></i>
                <div class="icon-bg">
                  <?php 
                  $random_id_gradient = 'gradient_id_' . Helper::generate_random_string();
                  $random_id_shadow = 'shadow_id_' . Helper::generate_random_string();
                  ?>
				<svg viewBox="0 28 100 100" width="100%" height="100%"  xmlns="http://www.w3.org/2000/svg">
					<linearGradient id="<?php echo esc_attr( $random_id_gradient ); ?>" gradientTransform="rotate(90)" >
						<stop stop-color="<?php echo esc_attr( $service_color ); ?>" class="alt-stop" offset="15%" />
						<stop stop-color="<?php echo esc_attr( $service_color_2 ); ?>" class="main-stop" offset="85%" />
					</linearGradient>
					<path fill="url(#<?php echo esc_attr( $random_id_gradient ); ?>)" d="M28.6,17.6C17.8,35.3,-23.6,36.4,-33.5,19.3C-43.3,2.2,-21.7,-33.1,-1,-33.7C19.7,-34.2,39.5,0,28.6,17.6Z" transform="translate(54 73)" />
				</svg>			
				
               </div>
              </div>
			 <?php } ?>
            <div class="rtin-content">
              <h3 class="rtin-title"><a href="<?php echo esc_attr( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></h3>
              <p><?php echo esc_html( $excerpt ); ?></p>
              <?php if ($read_more_text){ ?>
                <a href="<?php echo esc_url( $permalink ); ?>" class="readmore btn-fill gradient-accent rtel-button-1 style1  d-inline-flex align-items-center"><?php echo esc_html( $read_more_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
              <?php } ?>
            </div>
          </div>

        </div>
      <?php $i++; } ?>
    </div>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>
