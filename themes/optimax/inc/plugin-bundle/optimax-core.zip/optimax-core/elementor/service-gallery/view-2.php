<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";

$args = [
  'post_type'        => "{$prefix}_service",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_service_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";

?>
<div class="rtel-service-gallery2">
  <div class="rtin-service-wrap">
    <div class="row">
      <?php
      while( $query->have_posts() ): $query->the_post();
        $post                  = get_post();
        $title                 = $post->post_title;
        $excerpt               = Helper::generate_excerpt( $post, $no_of_excerpt_words );
        $permalink             = get_the_permalink($post);
        $thumb                 = Helper::generate_thumbnail_image( $post, $thumb_size );
        $service_icon          = get_post_meta( $post->ID, "{$prefix}_service_icon", true );
        $service_image         = get_post_meta( $post->ID, "{$prefix}_service_image", true );
        $service_color         = get_post_meta( $post->ID, "{$prefix}_service_color", true );
        $service_color         = $service_color ? $service_color : '#ff9317';
        $service_background    = "background-color: {$service_color}";
        if ($service_image) {
          $thumb            = Helper::generate_thumbnail_image_by_attachment_id($service_image, $thumb_size);
        }
        ?>
        <div class="<?php echo esc_attr( $col_class ); ?>">

          <div class="rtin-service-box">
            <?php if ($service_image): ?>
              <div class="rtin-img">
                <img class="img-responsive" src="<?php echo esc_url( $thumb ); ?>">
              </div>
            <?php else: ?>
              <div class="rtin-icon">
                <i class="<?php echo esc_attr( $service_icon ); ?>"></i>
                <div class="icon-bg">
                  <svg version="1.0" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 91.000000 86.000000" preserveAspectRatio="none">
                    <g transform="translate(0.000000,86.000000) scale(0.100000,-0.100000)" fill="<?php echo esc_attr( $service_color ); ?>" stroke="none">
                      <path d="M179 832 c-61 -32 -115 -100 -151 -191 -30 -76 -33 -286 -5 -342 25 -50 109 -131 170 -164 29 -16 87 -52 130 -82 74 -50 82 -53 140 -53 83 0 145 30 231 111 131 123 216 270 216 376 0 103 -37 169 -136 239 -121 87 -278 134 -442 134 -90 0 -105 -3 -153 -28z"/>
                    </g>
                  </svg>
               </div>
              </div>
            <?php endif ?>
            <div class="rtin-content">
              <h3 class="rtin-title"><a href="<?php echo esc_attr( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></h3>
              <p><?php echo esc_html( $excerpt ); ?></p>
              <?php if ( $read_more_text ): ?>
                <a href="<?php echo esc_url( $permalink ); ?>" class="ghost-btn-2 text-accent border-accent readmore"><?php echo esc_html( $read_more_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
              <?php endif ?>
            </div>
          </div>

        </div>
      <?php endwhile; ?>
    </div>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>
