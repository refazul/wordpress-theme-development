<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Plugin;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Custom_Widget_Init {

  public $version;
  public function __construct() {
    $this->version = Constants::$theme_version;
    add_action( 'elementor/widgets/widgets_registered',     [$this, 'init']);
    add_action( 'elementor/elements/categories_registered', [$this, 'widget_category']);
    add_action( 'elementor/controls/controls_registered',   [$this, 'custom_icon_for_elementor'], 10, 1 );
    add_action( 'elementor/editor/after_enqueue_styles',    [$this, 'after_enqueue_styles_elementor_editor'], 10, 1 );
    add_action( 'elementor/editor/after_enqueue_scripts',   [$this, 'after_enqueue_scripts_elementor_editor'], 10, 1 );
    add_filter( 'elementor/icons_manager/additional_tabs',  [$this, 'additional_tabs'], 10, 1 );
  }


  public function init() {
    require_once __DIR__ . '/base.php';

    // Widgets -- dirname=>classname /@dev
    // never change rt_base from each class
    // otherwise next iteration user site will be broken
    
    $widgets1 = [
      'info-box'                         => 'Info_Box',
      'widget-title'                     => 'Widget_Title',
      'title-subtitle-shortcode'         => 'Title_Subtitle_Shortcode',
      'service-gallery'                  => 'Service_Gallery',
      'radius-button'                    => 'Radius_Button',
      'section-title-subtitle'           => 'Section_Title_Subtitle',
      'case-study'                       => 'Case_Study',
      'team-gallery'                     => 'Team_Gallery',
      'pricing-plan'                     => 'Pricing_Plan',
      'title-subtitle-text-button'       => 'Title_Subtitle_Text_Button',
      'testimonial'                      => 'Testimonial',
      'blog-post'                        => 'Blog_Post',
      'brand-showcase'                   => 'Brand_Showcase',
      'contact-info-box'                 => 'Contact_Info_Box',
      'progress-box-image'               => 'Progress_Box_Image',
      'video-icon'                       => 'Video_Icon',
      'slide-banner'                     => 'Slide_Banner',
      'progress-bar'                     => 'Progress_Bar',
      'counter'                          => 'Counter',
      'header-menu'                      => 'Header_Menu',
      'content-toggle'                   => 'Content_Toggle',
      'shape-animation'                  => 'Shape_Animation',
    ];


    $widgets = array_merge( $widgets1);
    
    foreach ( $widgets as $dirname => $class ) {

      /**
       * following "if else" for cheeking user defined custom style
       * @var [type]
       */
      $template_name = DIRECTORY_SEPARATOR . 'elementor-custom' . DIRECTORY_SEPARATOR . $dirname . DIRECTORY_SEPARATOR . 'class.php';
      if ( file_exists( STYLESHEETPATH . $template_name ) ) {
        $file = STYLESHEETPATH . $template_name;
      }
      elseif ( file_exists( TEMPLATEPATH . $template_name ) ) {
        $file = TEMPLATEPATH . $template_name;
      }
      else {
        $file = __DIR__ . DIRECTORY_SEPARATOR . $dirname . DIRECTORY_SEPARATOR . 'class.php';
      }

      require_once $file;

      $classname = __NAMESPACE__ . '\\' . $class;
      Plugin::instance()->widgets_manager->register_widget_type( new $classname );
    }
  }

  public function widget_category( $class ) {
    $id         = Constants::$theme_prefix . '-widgets'; // Category /@dev
    $properties = [
      'title' => esc_html__( 'RadiusTheme Elements', 'optimax-core' ),
    ];

    Plugin::$instance->elements_manager->add_category( $id, $properties );
  }
  public function after_enqueue_styles_elementor_editor()
  {
    wp_enqueue_style( 'flaticon',         Helper::get_asset_file( 'vendor/flaticon/flaticon.css' ), [], $this->version );
  }

  public function after_enqueue_scripts_elementor_editor()
  {

    wp_enqueue_script( 'optimax-elementor-addon',  Helper::get_asset_file( 'js/elementor-editor.js' ), array('jquery'), $this->version , true);
  }


  public function custom_icon_for_elementor( $controls_registry )
  {
 // Get existing icons
  $icons = $controls_registry->get_control( 'icon' )->get_settings( 'options' );

    $new_icons = array_merge(
      Helper::get_flaticon_icons(),
      Helper::get_flaticon_seo_icons(),
      Helper::get_flaticon_digital_icons(),
      $icons
    );
    $controls_registry->get_control( 'icon' )->set_settings( 'options', $new_icons );
  }

  public function additional_tabs($tabs)
  {
    $json_url = Helper::get_asset_file('json/flaticon.json');
    $flaticon = [
      'name'          => 'flaticon',
      'label'         => esc_html__( 'Flaticon', 'optimax-core' ),
      'url'           => false,
      'enqueue'       => false,
      'prefix'        => '',
      'displayPrefix' => '',
      'labelIcon'     => 'fab fa-font-awesome-alt',
      'ver'           => '1.0.0',
      'fetchJson'     => $json_url,
    ];
    array_push( $tabs, $flaticon);
    return $tabs;
  }
}


new Custom_Widget_Init();
