<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

// Style is alike of blog archive 2

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size2";
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
}
else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}
else {
  $paged = 1;
}

$args = [
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'ignore_sticky_posts' => 1,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['category__in'] = $multiple_category;
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );

$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";

?>

<div class="rtel-blog-post-6">
  <div class="row masonry-grid-paused">
    <?php while( $query->have_posts() ): $query->the_post(); ?>
      <?php 
      $post = get_post();
      $img              = Helper::generate_thumbnail_image( $post, $thumb_size);
      $permalink        = get_the_permalink($post);
      $content          = Helper::generate_excerpt($post, $no_of_excerpt_words);
      $author           = get_the_author_meta( 'display_name' , $post->post_author );
      $author_post_link = get_author_posts_url($post->post_author);
      $categories       = get_the_category( $post->ID );
      $avatar           = get_avatar_url($post->post_author);

      $having_image_class = $img ? 'has-image' : 'no-image';
      $post_class         = $col_class;
      $post_class         .= $img ? ' post-has-image' : '';
      $post_class         .= $categories ? ' post-has-category' : '';
      $item_content_class = $img ? 'item-content post-has-image' : 'item-content';
      if ( $categories ) {
        $item_content_class .= " post-has-category";
      }

      ?>

      <div id="post-<?php echo esc_attr($post->ID) ?>" <?php post_class( $post_class ) ?> >
		<div class="rtin-blog-box">
         <?php if ( has_post_thumbnail() ) { ?>
           <div class="item-img">
              <a href="<?php echo esc_url( $permalink ); ?>"><?php the_post_thumbnail( $thumb_size ); ?></a>
			  <?php if ( $show_category == 'yes' ): ?>
			  <div class="item-category">
				<?php foreach ($categories as $category): ?>
				  <?php $category_link = get_category_link( $category ); ?>
				  <a href="<?php echo esc_url( $category_link ); ?>"><?php echo esc_html( $category->cat_name ); ?></a>
				<?php endforeach ?>
			  </div>
			  <?php endif ?>
          </div>
         <?php } else { ?>
				<a href="<?php echo esc_url( $permalink ); ?>"><img src="<?php echo esc_url( Helper::get_img( 'noimage/noimage_490x330.jpg' ) ); ?>" alt="<?php echo esc_attr( $post->post_title ); ?>"></a>				
		  <?php } ?>

        <div class="<?php echo esc_attr( $item_content_class ); ?>">
          <?php // blog author name + date field ?>
          <?php if ( $show_author == 'yes' || $show_date == 'yes' ): ?>
            <ul class="entry-meta">
              <?php if ( $show_date == 'yes' ) : ?>
                <li><i class="far fa-clock"></i><?php 
                  $unixtimestamp =  get_the_time('U', $post );
                  echo date_i18n( get_option( 'date_format' ), $unixtimestamp );?></li>
              <?php endif ?>
			  <?php if ( $show_author == 'yes' ) :  ?>
                <li class="author"><i class="fas fa-user"></i> <span class="bytag"><?php esc_html_e( 'by ', 'optimax' );?></span>
                  <a href="<?php echo esc_attr( $author_post_link ); ?>"> <?php echo esc_html( $author ); ?> </a>
                </li>
              <?php endif; ?>
            </ul>
          <?php endif; ?>
			<h3 class="item-title"><a href="<?php echo esc_attr( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h3>
          <p> <?php echo wp_kses_post( $content ); ?><?php echo esc_html( $postfix_text ); ?> </p>

          <div class="action-area">
            <?php if ( $show_readmore == 'yes'): ?>
              <a href="<?php echo esc_attr( $permalink ); ?>" class="btn-fill gradient-accent"><?php echo esc_html( $read_more_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
            <?php endif ?>
            <?php if ( $show_comments_number == 'yes' ): ?>
              <?php $comments_number = get_comments_number( $post ); ?>
              <a href="<?php echo esc_attr( $permalink ); ?>" class="item-comment"><i class="far fa-comment-dots"></i> <?php echo esc_html( $comments_number ); ?></a>
            <?php endif ?>
          </div>
        </div>
		</div>
      </div>
    <?php endwhile; ?>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>

