<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size9";

$args = [
  'posts_per_page'   => 4,
  'ignore_sticky_posts' => 1,
  'suppress_filters' => false,
  'orderby'          => $orderby,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}


if ( $data['which_post'] == 'all_post' ) {
  $bool = is_array( $multiple_category_view_2 );
  $bool = $bool && count( $multiple_category_view_2  ) ;
  if ( $bool ) {
    $args['category__in'] = $multiple_category_view_2;
  }
}

if ( $data['which_post'] == 'custom_select' ) {
  $args['post__in'] = [$data['first_post'], $data['second_post'], $data['third_post'], $data['fourth_post'] ];
  $args['orderby']  = 'post__in';
}


$posts = get_posts( $args );



$posts = get_posts( $args );
$first_post = array_shift($posts);

$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";

?>
<div class="rtel-blog-post-5">
  <div class="row">
    <?php if ( $first_post ): ?>
      <?php 
      $img = Helper::generate_thumbnail_image( $first_post, $thumb_size, true );

      // img alternative 
      $attachment_id        = get_post_thumbnail_id( $first_post );
      $img_alt              = $attachment_id ?  Helper::get_attachment_alt( $attachment_id ) : $first_post->post_title ;
      $permalink            = get_the_permalink($first_post);
      $content              = Helper::generate_excerpt($first_post, $first_post_no_of_excerpt_words);
      $author               = get_the_author_meta( 'display_name' , $first_post->post_author );
      $author_post_link     = get_author_posts_url($first_post->post_author);
      $categories           = get_the_category( $first_post->ID );
      $having_image_class   = $img ? 'has-image' : 'no-image';
      ?>
      <div class="col-lg-6 col-12">
        <div class="rtin-blog-box-layout2">
          <?php if ( $img ): ?>
            <div class="rtin-img">
              <a href="<?php echo esc_url( $permalink ); ?>"><img width="900" height="600" src="<?php echo esc_attr( $img ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>"></a>
            </div>
          <?php endif ?>
          <div class="rtin-content">
            <?php if ( $show_date == 'yes' || $show_author == 'yes' ): ?>
              <ul class="entry-meta">
                <?php if ( $show_date == 'yes' ): ?>
                  <li><i class="far fa-clock"></i> <?php 
                    $unixtimestamp =  get_the_time('U', $first_post );
                    echo date_i18n( get_option( 'date_format' ), $unixtimestamp );?></li>
                <?php endif ?>
                <?php if ( $show_author == 'yes' ): ?>
                  <li><i class="fas fa-user"></i><a href="<?php echo esc_attr( $author_post_link ); ?>"> <?php echo esc_html( $author ); ?> </a></li>
                <?php endif ?>
                <?php if ( $categories && $show_category == 'yes' ): ?>
                  <li>
                    <i class="fas fa-folder-open"></i>
                    <?php foreach ($categories as $category): ?>
                      <a href="<?php echo esc_url( get_category_link( $category ) ); ?>">
                        <?php echo esc_html( $category->cat_name ); ?>
                      </a>
                    <?php endforeach ?>
                  </li>
                <?php endif ?>

              </ul>
            <?php endif ?>
            <h3 class="rtin-title"><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $first_post->post_title ); ?></a></h3>
            <p><?php echo esc_html( $content ); ?><?php echo esc_html( $postfix_text ); ?></p>
            <div class="action-area adjust-padding">
              <?php if ( $show_readmore == 'yes' ): ?>
                <a href="<?php echo esc_url( $permalink ); ?>" class="rtin-btn">
                  <?php echo esc_html( $read_more_text ); ?>
                  <i class="fas fa-long-arrow-alt-right"></i>
                </a>
              <?php endif ?>
              <a href="<?php echo esc_url( $permalink ); ?>#comments" class="rtin-comment"><i class="far fa-comment-dots"></i><?php echo esc_html( $first_post->comment_count ); ?></a>
            </div>
          </div>
        </div>
      </div>
    <?php endif ?>
    <div class="col-lg-6 col-12">
      <?php foreach ($posts as $post): ?>
        <?php 
        $img = Helper::generate_thumbnail_image( $post, $thumb_size, true );
        $permalink = get_the_permalink($post);
        $content = Helper::generate_excerpt($post, $no_of_excerpt_words);
        $author = get_the_author_meta( 'display_name' , $post->post_author );
        $author_post_link = get_author_posts_url($post->post_author);
        $categories = get_the_category( $post->ID );
        ?>
        <div class="rtin-blog-box-layout3">
          <div class="rtin-content">
            <?php if ( $show_author == 'yes' || $show_date == 'yes'): ?>
              <ul class="entry-meta">
                <?php if ( $show_date == 'yes' ){ ?>
                  <li>
                    <i class="far fa-clock"></i> <?php 
                    $unixtimestamp =  get_the_time('U', $post );
                    echo date_i18n( get_option( 'date_format' ), $unixtimestamp ); ?>
                  </li>
                <?php } ?>
                <?php if ( $show_author == 'yes' ){ ?>
                  <li><i class="fas fa-user"></i><a href="<?php echo esc_attr( $author_post_link ); ?>"> <?php echo esc_html( $author ); ?> </a></li>
                <?php } ?>
                <?php if ( $categories && $show_category == 'yes' ): ?>
                  <li>
                    <i class="fas fa-folder-open"></i>
                    <?php foreach ($categories as $category): ?>
                      <a href="<?php echo esc_url( get_category_link( $category ) ); ?>">
                        <?php echo esc_html( $category->cat_name ); ?>
                      </a>
                    <?php endforeach ?>
                  </li>
                <?php endif ?>
              </ul>
            <?php endif ?>
            <h3 class="rtin-title"><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h3>
            <p><?php echo esc_html( $content ); ?><?php echo esc_html( $postfix_text ); ?></p>
          </div>
        </div>
      <?php endforeach ?>

    </div>
  </div>
</div>


