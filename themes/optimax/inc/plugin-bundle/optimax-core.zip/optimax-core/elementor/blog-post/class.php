<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Blog_Post extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Blog Post', 'optimax-core' );
    $this->rt_base = 'rt-blog-post';
    $this->rt_translate = [
      'cols'  => [
        '12' => esc_html__( '1 Col', 'optimax-core' ),
        '6'  => esc_html__( '2 Col', 'optimax-core' ),
        '4'  => esc_html__( '3 Col', 'optimax-core' ),
        '3'  => esc_html__( '4 Col', 'optimax-core' ),
        '2'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
    ];
    parent::__construct( $data, $args );
  }

  private function rt_cat_dropdown() {

    $categories = get_categories();
    foreach ( $categories as $category ) {
      $category_dropdown[$category->term_id] = $category->name;
    }
    return $category_dropdown;
  }
  public function rt_fields() {

    $posts = get_posts( ['posts_per_page' => -1, 'orderby' => 'title','order' => 'ASC','post_status' => 'publish','suppress_filters' => false]);
    $posts_dropdown = [];
    foreach ( $posts as $post ) {
      $posts_dropdown[$post->ID] = $post->post_title;
    }
    $default_post_id_1 = '';
    $default_post_id_2 = '';
    $default_post_id_3 = '';
    $default_post_id_4 = '';
    if ( count($posts_dropdown) ) {
      $default_post_id_1 = array_rand($posts_dropdown);
      $default_post_id_2 = array_rand($posts_dropdown);
      $default_post_id_3 = array_rand($posts_dropdown);
      $default_post_id_4 = array_rand($posts_dropdown);
    }

    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'default' => 'style1',
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
          'style5' => esc_html__( 'style 5', 'optimax-core' ),
          'style6' => esc_html__( 'style 6', 'optimax-core' ),
          'style7' => esc_html__( 'style 7', 'optimax-core' ),
        ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'pagination_display',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Pagination', 'optimax-core' ),
        'default'     => "no",
        'condition'   => [ 'style' => [ 'style1', 'style3', 'style6', 'style7' ] ],
      ],

      [
        'type'      => Controls_Manager::SELECT2,
        'id'        => 'which_post',
        'label'     => esc_html__( 'Which type of post you want to display', 'optimax-core' ),
        'default'   => 'all_post',
        'options'   => [
          'all_post'      => esc_html__( 'All Posts', 'optimax-core' ),
          'custom_select' => esc_html__( 'Custom Select', 'optimax-core' ),
        ],
        'condition' => ['style' => ['style2', 'style5']],
      ],
      [
        'type'        => Controls_Manager::SELECT2,
        'id'          => 'multiple_category',
        'label'       => __( 'Categories', 'optimax-core' ),
        'options'     => $this->rt_cat_dropdown(),
        'multiple'    => true,
        'description' => esc_html__( 'All categories is selected by default', 'optimax-core' ),
        'condition'   => ['style' => [ 'style1', 'style3', ] ],
      ],

      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'show_date',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Date', 'optimax-core' ),
        'default'     => "yes",
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'show_category',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Category', 'optimax-core' ),
        'default'     => "yes",
        'condition'   => [ 'style' => [ 'style1', 'style2', 'style5', 'style6', 'style7' ] ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'show_author',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Author', 'optimax-core' ),
        'default'     => "yes",
        'condition'   => [ 'style' => [ 'style2', 'style3', 'style4', 'style5', 'style6', 'style7' ] ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'show_comments_number',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Comments Number', 'optimax-core' ),
        'default'     => "yes",
        'condition'   => [ 'style' => [ 'style6', 'style7' ] ],
      ],


      [
        'type'        => Controls_Manager::SELECT2,
        'id'          => 'multiple_category_view_2',
        'label'       => __( 'Categories', 'optimax-core' ),
        'options'     => $this->rt_cat_dropdown(),
        'multiple'    => true,
        'description' => esc_html__( 'All categories is selected by default', 'optimax-core' ),
        'condition'   => ['style' => [ 'style2', 'style5', ], 'which_post' => 'all_post' ],
      ],

      [
        'type'      => Controls_Manager::SELECT2,
        'id'        => 'first_post',
        'label'     => esc_html__( 'First Post', 'optimax-core' ),
        'options'   => $posts_dropdown,
        'default'   => $default_post_id_1,
        'condition' => [
          'style'      => ['style2', 'style5'],
          'which_post' => 'custom_select'
        ],
      ],
      [
        'type'      => Controls_Manager::SELECT2,
        'id'        => 'second_post',
        'label'     => esc_html__( 'Second Post', 'optimax-core' ),
        'options'   => $posts_dropdown,
        'default'   => $default_post_id_2,
        'condition' => [
          'style'      => ['style2', 'style5',],
          'which_post' => 'custom_select'
        ],
      ],
      [
        'type'      => Controls_Manager::SELECT2,
        'id'        => 'third_post',
        'default'   => $default_post_id_3,
        'label'     => esc_html__( 'Third Post', 'optimax-core' ),
        'options'   => $posts_dropdown,
        'condition' => [
          'style'      => ['style2', 'style5',],
          'which_post' => 'custom_select'
        ],
      ],
      [
        'type'      => Controls_Manager::SELECT2,
        'id'        => 'fourth_post',
        'default'   => $default_post_id_4,
        'label'     => esc_html__( 'Fourth Post', 'optimax-core' ),
        'options'   => $posts_dropdown,
        'condition' => [
          'style'      => ['style5',],
          'which_post' => 'custom_select'
        ],
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'posts_per_page',
        'label'       => esc_html__( 'Posts Per Page', 'optimax-core' ),
        'default'     => 3,
        'condition'   => [ 'style' => [ 'style1', 'style3', 'style6', 'style7' ] ],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'orderby',
        'label'   => esc_html__( 'Order By', 'optimax-core' ),
        'options' => [
          'date'        => esc_html__( 'Date (Recents comes first)', 'optimax-core' ),
          'title'       => esc_html__( 'Title', 'optimax-core' ),
          'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'optimax-core' ),
        ],
        'default' => 'date',
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'first_post_no_of_excerpt_words',
        'label'       => esc_html__( 'Number Of words for excerpt (first post)', 'optimax-core' ),
        'default'     => '25',
        'condition'   => ['style' => ['style2', 'style4', 'style5',]],
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'no_of_excerpt_words',
        'label'       => esc_html__( 'Number Of words for excerpt', 'optimax-core' ),
        'default'     => '25',
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'postfix_text',
        'label'       => esc_html__( 'Postfix Dot', 'optimax-core' ),
        'default'     => "...",
      ],

      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'show_readmore',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Readmore', 'optimax-core' ),
        'default'     => "yes",
        'condition'   => [ 'style' => [ 'style1', 'style2', 'style3', 'style5', 'style6' ] ],
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'read_more_text',
        'label'       => esc_html__( 'Read More Text', 'optimax-core' ),
        'default'     => "Read More",
        'condition'   => [ 'show_readmore' => 'yes' ],
        'condition'   => [ 'style' => [ 'style1', 'style2', 'style3', 'style5', 'style6' ] ],
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'adjust_padding',
        'condition'  => [ 'style' => [ 'style2', 'style1', 'style5', ] ],
        'label'      => __( '1st post adjust bottom padding', 'optimax-core' ),
        'size_units' => ['px'],
        'range'      => [
          'px' => [
            'min' => 0,
            'max' => 250,
          ],
        ],
        'default'    => [
          'unit' => 'px',
          'size' => 5,
        ],
        'selectors'  => [
          '{{WRAPPER}}  .action-area.adjust-padding' => 'padding-bottom: {{SIZE}}{{UNIT}};',
        ]
      ],
      
      [
        'mode' => 'section_end',
      ],
      
      // Responsive Columns for general
      // it will generate bootstrap column
      [
        'mode'    => 'section_start',
        'id'      => 'sec_responsive',
        'label'   => esc_html__( 'Number of Responsive Columns', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xl',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '6',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm',
        'label'   => esc_html__( 'Phones: > 576px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '12',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col',
        'label'   => esc_html__( 'Phones: < 576px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '12',
      ],
      [
        'mode'    => 'section_end',
      ],

      // Starting Style Section 
      [
        'mode'    => 'section_start',
        'id'      => 'title_style_section',
        'label'   => esc_html__( 'Title Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Title Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .post-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .item-title a' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_hover_color',
        'label'     => esc_html__( 'Title Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .post-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .item-title a:hover' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .post-title,
          {{WRAPPER}} .rtel-blog-post-2 .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-blog-post-5 .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .rtin-title,
          {{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .item-title
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_margin',
        'label'      => __( 'Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .post-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator' => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],

      // Content
      [
        'mode'    => 'section_start',
        'id'      => 'content_style_section',
        'label'   => esc_html__( 'Content Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'content_color',
        'label'     => esc_html__( 'Content Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content p' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'content_typo',
        'label'          => esc_html__( 'Content Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content p,
          {{WRAPPER}} .rtel-blog-post-2 .rtin-content p,
          {{WRAPPER}} .rtel-blog-post-5 .rtin-content p,
          {{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content p,
          {{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content p,
          {{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body p,
          {{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content p,
          {{WRAPPER}} noselector
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'content_margin',
        'label'      => __( 'Content Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-4 .first-post-section .rtin-content p ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator' => 'before',
      ],
      [
        'mode' => 'section_end',
      ], 

      // Author Style
      [
        'mode'      => 'section_start',
        'id'        => 'meta_author_style',
        'label'     => esc_html__( 'Author Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style1', 'style6', 'style7' ] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'author_typo',
        'label'          => esc_html__( 'Author Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .rtin-author span,
          {{WRAPPER}}  .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li a,
          {{WRAPPER}}  noselector,
          {{WRAPPER}}  noselector

          ',
      ],
      
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'author_color',
        'label'     => esc_html__( 'Author Meta Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .rtin-author span' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li a' => 'color: {{VALUE}}',
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],

      // read more color and typo
      [
        'mode'      => 'section_start',
        'id'        => 'readmore_style',
        'label'     => esc_html__( 'Readmore', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style1', 'style2', 'style3', 'style5', 'style6', 'style7' ] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'readmore_typo',
        'label'          => esc_html__( 'Readmore Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .action-area .rtin-btn,
          {{WRAPPER}}  .rtel-blog-post-2 .rtin-content .action-area .rtin-btn,
          {{WRAPPER}}  .rtel-blog-post-5 .rtin-content .action-area .rtin-btn,
          {{WRAPPER}}  .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-btn,
          {{WRAPPER}}  .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore 
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_color',
        'label'     => esc_html__( 'Read More Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .action-area .rtin-btn' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-2 .rtin-content .action-area .rtin-btn' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-5 .rtin-content .action-area .rtin-btn' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore ' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore ' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-btn' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_color_hover',
        'label'     => esc_html__( 'Readmore Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .action-area .rtin-btn:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-2 .rtin-content .action-area .rtin-btn:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-5 .rtin-content .action-area .rtin-btn:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-btn:hover' => 'color: {{VALUE}}',
        ],
      ],

      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_icon_color',
        'label'     => esc_html__( 'Readmore Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .action-area .rtin-btn i' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-2 .rtin-content .action-area .rtin-btn i' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-5 .rtin-content .action-area .rtin-btn i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-btn i' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_icon_hover_color',
        'label'     => esc_html__( 'Readmore Icon Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-blog-post-1 .blog-box-layout1 .rtin-content .action-area .rtin-btn:hover i' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-2 .rtin-content .action-area .rtin-btn:hover i' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-blog-post-5 .rtin-content .action-area .rtin-btn:hover i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore:hover i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-btn:hover i' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'            => 'group',
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'condition' => [ 'style' => [ 'style2', 'style3', 'style5', ] ],
        'name'            => 'readmore_hover_background',
        'types'           => [ 'gradient' ],
        'label'           => esc_html__( 'Hover Background', 'optimax-core' ),
        'selector'        => '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore:hover',
        'condition'       => [ 'style' => ['style3' ] ],
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Hover Background', 'optimax-core' ),
          ],
        ],
      ],      
      [
        'type'      => Controls_Manager::COLOR,
        'condition'       => [ 'style' => ['style3' ] ],
        'id'        => 'readmore_border_color',
        'label'     => esc_html__( 'Readmore border Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore' => 'border-color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'condition'       => [ 'style' => ['style3' ] ],
        'id'        => 'readmore_hover_border_color',
        'label'     => esc_html__( 'Readmore Hover border Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content a.readmore:hover' => 'border-color: {{VALUE}}',
        ],
      ],
      [
        'mode' => 'section_end',
      ],

      // Other Style  
      [
        'mode'    => 'section_start',
        'id'      => 'other_style_section',
        'label'   => esc_html__( 'Others Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'meta_text_typo',
        'label'          => esc_html__( 'Meta Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .entry-meta li,
          {{WRAPPER}} .rtel-blog-post-2 .rtin-content .entry-meta li,
          {{WRAPPER}} .rtel-blog-post-5 .rtin-content .entry-meta li,
          {{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .entry-meta li,
          {{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li,
          {{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-comment,
          {{WRAPPER}} .rtel-blog-post-4 .entry-meta li
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_text_color',
        'label'     => esc_html__( 'Meta Text Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .entry-meta li' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .entry-meta li' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .entry-meta li' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .entry-meta li' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .entry-meta li' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-comment' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_link_color',
        'label'     => esc_html__( 'Meta Link Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .entry-meta li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .entry-meta li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .action-area .rtin-comment' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .entry-meta li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .action-area .rtin-comment' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .entry-meta li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .entry-meta li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .entry-meta li a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li a' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_link_hover_color',
        'label'     => esc_html__( 'Meta Link Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .entry-meta li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .entry-meta li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .action-area .rtin-comment:hover' => 'color: {{VALUE}}',

          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .entry-meta li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .action-area .rtin-comment:hover' => 'color: {{VALUE}}',

          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .entry-meta li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .entry-meta li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .entry-meta li a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li a:hover' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_icon_color',
        'label'     => esc_html__( 'Meta Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-blog-post-1 .blog-box-layout1 .rtin-content .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-2 .rtin-content .action-area .rtin-comment i' => 'color: {{VALUE}}',

          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-5 .rtin-content .action-area .rtin-comment i' => 'color: {{VALUE}}',

          '{{WRAPPER}} .rtel-blog-post-3 .blog-box-3 .rtin-content .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-4 .others-post-section .media .media-body .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .entry-meta li i' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-blog-post-6 .rtin-blog-box .item-content .action-area .item-comment i' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style2':
      $template = 'view-2';
      break;
      case 'style3':
      $template = 'view-3';
      break;
      case 'style4':
      $template = 'view-4';
      break;
      case 'style5':
      $template = 'view-5';
      break;
      case 'style6':
      $template = 'view-6';
      break;
      case 'style7':
      $template = 'view-7';
      break;
      default:
      $template = 'view-1';
      break;
    }
    return $this->rt_template( $template, $data );
  }
}
