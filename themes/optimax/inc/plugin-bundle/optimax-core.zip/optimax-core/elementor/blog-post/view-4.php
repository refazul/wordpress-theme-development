<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);

$prefix      = Constants::$theme_prefix;
$thumb_size1  = "{$prefix}-size1";
$thumb_size2  = "{$prefix}-size2";

$args = [
  'posts_per_page'   => 4,
  'ignore_sticky_posts' => 1,
  'suppress_filters' => false,
  'orderby'          => $orderby,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = isset($multiple_category);
$bool = $bool && is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['category__in'] = $multiple_category;
}
$posts = get_posts( $args );
$first_post = array_shift($posts);

?>
<div class="rtel-blog-post-4">
  <div class="row">
    <div class="col-xl-6">
     <?php 
      $img              = Helper::generate_thumbnail_image( $first_post, $thumb_size1);
      $permalink        = get_the_permalink($first_post);
      $excerpt          = Helper::generate_excerpt($first_post, $first_post_no_of_excerpt_words);
      $author           = get_the_author_meta( 'display_name' , $first_post->post_author );
      $author_post_link = get_author_posts_url($first_post->post_author);
      $categories       = get_the_category( $first_post->ID );
      $avatar           = get_avatar_url($first_post->post_author);
      $attachment_id    = get_post_thumbnail_id( $first_post );
      $img_alt          = $attachment_id ?  Helper::get_attachment_alt( $attachment_id ) : $first_post->post_title ;
      ?>
      <div class="first-post-section">
        <div class="rtin-img">
          <a href="<?php echo esc_url( $permalink ); ?>">
            <img src="<?php echo esc_attr( $img ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>">
          </a>
        </div>
        <div class="rtin-content">
          <?php if ( $show_author == 'yes' || $show_date == 'yes' ): ?>
            <ul class="entry-meta">
              <?php if ( $show_date == 'yes' ): ?>
                <li><i class="far fa-clock"></i><?php $unixtimestamp =  get_the_time('U', $first_post );
				  echo date_i18n( get_option( 'date_format' ), $unixtimestamp );?></li>
              <?php endif ?>
              <?php if ( $show_author == 'yes' ): ?>
                <li><i class="fas fa-user"></i><a href="<?php echo esc_url( $author_post_link ); ?>"><?php echo esc_html( $author ); ?></a></li>
              <?php endif ?>
            </ul>
          <?php endif ?>
          <h3 class="rtin-title">
            <a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $first_post->post_title ); ?></a>
          </h3>
          <p>
            <?php echo esc_html( $excerpt ); ?>
            <?php echo esc_html( $postfix_text ); ?>
          </p>
        </div>
      </div>
    </div>
    <!-- left side completed -->

    <div class="col-xl-6 col-12">
      <div class="others-post-section">
      <?php foreach ($posts as $post): ?>
        <?php 
        $img              = Helper::generate_thumbnail_image( $post, $thumb_size2);
        $permalink        = get_the_permalink($post);
        $excerpt          = Helper::generate_excerpt($post, $no_of_excerpt_words);
        $author           = get_the_author_meta( 'display_name' , $post->post_author );
        $author_post_link = get_author_posts_url($post->post_author);
        $categories       = get_the_category( $post->ID );
        $avatar           = get_avatar_url($post->post_author);
        $attachment_id    = get_post_thumbnail_id( $post );
        $img_alt          = $attachment_id ?  Helper::get_attachment_alt( $attachment_id ) : $post->post_title ;
        ?>
        <div class="media media-none--sm">
          <div class="rtin-img">
            <a href="<?php echo esc_url( $permalink ); ?>">
              <img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>">
            </a>
          </div>
          <div class="media-body">
            <?php if (  $show_date == 'yes' || $show_author == 'yes'  ): ?>
              <ul class="entry-meta">
                <?php if ( $show_date == 'yes' ): ?>
                  <li><i class="far fa-clock"></i><?php $unixtimestamp =  get_the_time('U', $post );
				  echo date_i18n( get_option( 'date_format' ), $unixtimestamp ); ?></li>
                <?php endif ?>
                <?php if ( $show_author == 'yes' ): ?>
                  <li><i class="fas fa-user"></i><a href="<?php echo esc_url( $author_post_link ); ?>"><?php echo esc_html( $author ); ?></a></li>
                <?php endif ?>
              </ul>
            <?php endif ?>
            
             <h3 class="rtin-title">
              <a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a>
            </h3>
            <p>
              <?php echo esc_html( $excerpt ); ?> 
              <?php echo esc_html( $postfix_text ); ?>
            </p>
          </div>
        </div>
      <?php endforeach ?>
    </div>
  </div>

  </div>
</div>



