<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$anchor_attr = Helper::generate_elementor_anchor_attributes( $anchor_url );
$classes = [
  'style1' =>  "btn-fill gradient-accent rtel-button-1 style1",
  'style2' =>  "ghost-btn-2 text-accent rtel-button-1 style2",
  'style3' =>  "btn-fill-accent-2 gradient-accent-2 rtel-button-1 style3",
  'style4' =>  "rtel-button-1 style4",
];
$anchor_class = $classes['style1'];
if ( array_key_exists($style, $classes) ) {
  $anchor_class = $classes[$style];
}
$final_icon_class  = " fas fa-long-arrow-alt-right";
$final_icon_image_url = '';
if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
  $final_icon_class = $dynamic_icon_class;
}
if ( is_array( $icon_class['value'] ) ) {
  $final_icon_image_url = $icon_class['value']['url'];
}
?>
<div class="rtel-radius-button">
   <a <?php echo wp_kses_post( $anchor_attr ); ?> class="<?php echo esc_attr( $anchor_class ); ?>  d-inline-flex align-items-center">
    <?php if ( $has_icon && $icon_position == 'before' ): ?>
      <?php if ( $final_icon_image_url ): ?>
        <img class="before-icon" src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
      <?php else: ?>
        <i class="<?php  echo esc_attr( $final_icon_class ); ?>  before-icon"></i>
      <?php endif ?>
    <?php endif ?>
    <span>
      <?php echo esc_html( $anchor_text ); ?>
    </span>
    <?php if ( $has_icon && $icon_position == 'after'): ?>
      <?php if ( $final_icon_image_url ): ?>
        <img class="after-icon" src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
      <?php else: ?>
        <i class="<?php  echo esc_attr( $final_icon_class ); ?> after-icon"></i>
      <?php endif ?>
    <?php endif ?>
  </a> 
</div>
