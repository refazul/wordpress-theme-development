<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Radius_Button extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Radius Button', 'optimax-core' );
    $this->rt_base = 'rt-radius-button';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          // Style use inside single view
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4 - (customizable bg-color)', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'anchor_text',
        'label'       => esc_html__( 'Anchor Text', 'optimax-core' ),
        'default'     => 'READ MORE',
      ],
      [ 
        'type'        => Controls_Manager::URL,
        'id'          => 'anchor_url',
        'label'       => esc_html__( 'label', 'optimax-core' ),
        'default'     => [ 'url' => '#'],
      ],
      [
        'type'    => Controls_Manager::CHOOSE,
        'mode'    => 'responsive',
        'options' => [
          'left' => [
            'title' => esc_html__( 'Left', 'optimax-core' ),
            'icon' => 'fas fa-align-left',
          ],
          'center' => [
            'title' => esc_html__( 'Center', 'optimax-core' ),
            'icon' => 'fas fa-align-center',
          ],
          'right' => [
            'title' => esc_html__( 'Right', 'optimax-core' ),
            'icon' => 'fas fa-align-right',
          ],
          'justify' => [
            'title' => esc_html__( 'Justified', 'optimax-core' ),
            'icon' => 'fas fa-align-justify',
          ],
        ],
        'id'      => 'button_align',
        'label'   => esc_html__( 'Button Text Align', 'optimax-core' ),
        'default' => 'left',
        'selectors'  => [
          '{{WRAPPER}} .rtel-radius-button' => 'text-align: {{VALUE}};',
        ],
      ],
      
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'has_icon',
        'label_on' => esc_html__( 'Show', 'optimax-core' ),
        'label_off' => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Has Icon', 'optimax-core' ),
        'default'     => "yes",
      ],
      [
        'type'        => Controls_Manager::ICONS,
        'id'          => 'icon_class',
        'label'       => esc_html__( 'Icon', 'optimax-core' ),
        'condition'   => [ 'has_icon' => 'yes' ],
        'default'     => [
          'value' => "fas fa-long-arrow-alt-right",
        ],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'icon_position',
        'label'   => esc_html__( 'Icon Position', 'optimax-core' ),
        'options' => [
          'before' => esc_html__( 'Before Text', 'optimax-core' ),
          'after'  => esc_html__( 'After Text', 'optimax-core' ),
        ],
        'default' => 'after',
        'condition'   => [ 'has_icon' => 'yes' ],
      ],      
      [
        'mode' => 'section_end',
      ],
      // style
      [
        'mode'    => 'section_start',
        'id'      => 'button_content',
        'label'   => esc_html__( 'Button Content', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'content_color',
        'label'   => esc_html__( 'Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}}  .rtel-radius-button a' => 'color: {{VALUE}}' ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'content_hover_color',
        'label'   => esc_html__( 'Hover Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}}  .rtel-radius-button a:hover' => 'color: {{VALUE}}' ],
      ],

      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'content_typo',
        'label'          => esc_html__( 'Content Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}   .rtel-radius-button a',
      ],
       [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'border_color',
        'label'   => esc_html__( 'Border Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .rtel-radius-button a' => 'border-color: {{VALUE}}' ],
        'condition' => [ 'style' => [ 'style2', ] ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'border_hover_color',
        'label'   => esc_html__( 'Border Hover Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .rtel-radius-button a:hover' => 'border-color: {{VALUE}}' ],
        'condition' => [ 'style' => [ 'style2', ] ],
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'icon_size',
        'label'       => esc_html__( 'Icon Size', 'optimax-core' ),
        'condition'   => [ 'has_icon' => 'yes' ],
        'default'     => '14',
        'selectors' => [ '{{WRAPPER}} .rtel-radius-button a i' => 'font-size: {{VALUE}}px' ],
      ],



      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'icon_margin',
        'label'      => __( 'Icon Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-radius-button i.before-icon ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-radius-button i.after-icon '  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator'  => 'before',
      ],
      [
        'mode'            => 'group',
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'button_background',
        'types'           => [ 'classic', 'gradient' ],
        'label'           => esc_html__( 'Button Background Gradient', 'optimax-core' ),
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Button Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '{{WRAPPER}} .rtel-radius-button a',
      ],
      [
        'mode'            => 'group',
        'separator'       => 'after',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'button_background_hover',
        'types'           => [ 'classic', 'gradient' ],
        'label'           => esc_html__( '', 'optimax-core' ),
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Button Background Hover', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtel-radius-button .btn-fill:after,
          {{WRAPPER}} .rtel-radius-button .style4:after,
          {{WRAPPER}} .rtel-radius-button a:hover
        ',
      ],
      [
        'mode' => 'section_end',
      ],
    ];
    return $fields;
  }
  protected function render() {
    $data     = $this->get_settings();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
