<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class Testimonial extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Testimonial', 'optimax-core' );
    $this->rt_base = 'rt-testimonial';
    $this->rt_translate = [
      'cols'  => [
        // here its bootstrap class
        '12' => esc_html__( '1 Col', 'optimax-core' ),
        '6'  => esc_html__( '2 Col', 'optimax-core' ),
        '4'  => esc_html__( '3 Col', 'optimax-core' ),
        '3'  => esc_html__( '4 Col', 'optimax-core' ),
        '2'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
      'cols_slider'  => [
        '1'  => esc_html__( '1 Col', 'optimax-core' ),
        '2'  => esc_html__( '2 Col', 'optimax-core' ),
        '3'  => esc_html__( '3 Col', 'optimax-core' ),
        '4'  => esc_html__( '4 Col', 'optimax-core' ),
        '5'  => esc_html__( '5 Col', 'optimax-core' ),
        '6'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
    ];
    parent::__construct( $data, $args );
  }


  private function rt_cat_dropdown() {
    $prefix = Constants::$theme_prefix;

    $terms = get_terms( [
      'taxonomy' => "{$prefix}_testimony_category",
      'hide_empty' => true,
    ]);

    $category_dropdown = [];
    foreach ( $terms as $category ) {
      $category_dropdown[$category->term_id] = $category->name;
    }

    return $category_dropdown;
  }

  public function bool_casting($value)
  {
    return $value == 'yes' ? true : false;
  }
  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
          'style5' => esc_html__( 'style 5', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      [
        'type'        => Controls_Manager::TEXTAREA,
        'id'          => 'title',
        'label'       => esc_html__( 'Testimonial Title', 'optimax-core' ),
        'default'     => "Clients Feedback",
        'condition' => [ 'style' => [ 'style1', ] ],
      ],
      [ 
        'type'    => Controls_Manager::MEDIA,
        'id'      => 'image',
        'label'   => esc_html__( 'Image', 'optimax-core' ),
        'default' => [
          'url' => Utils::get_placeholder_image_src(),
        ],
        'description' => esc_html__( 'Recommended full image', 'optimax-core' ),
        'condition' => [ 'style' => [ 'style1', ] ],
      ],

      [
        'type'      => Group_Control_Image_Size::get_type(),
        'mode'      => 'group',
        'name'        => 'image_size',
        'label'     => esc_html__( 'image size', 'optimax-core' ),    
        'separator' => 'none',        
        'condition' => [ 'style' => [ 'style1' ] ],
      ],

      [
        'type'        => Controls_Manager::SELECT2,
        'id'          => 'multiple_category',
        'label'       => __( 'Categories', 'optimax-core' ),
        'options'     => $this->rt_cat_dropdown(),
        'multiple'    => true,
        'description' => esc_html__( 'All categories is selected by default', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'posts_per_page',
        'label'       => esc_html__( 'Testimonial Per Page', 'optimax-core' ),
        'default'     => 3,
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'slick_go_to',
        'label'       => esc_html__( 'Carousel go to', 'optimax-core' ),
        'default'     => '1',
        'condition' => [ 'style' => [ 'style2', ] ],
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'number_of_words_for_testimonial',
        'label'       => esc_html__( 'No of words for testimonials', 'optimax-core' ),
        'default'     => '14',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'orderby',
        'label'   => esc_html__( 'Order By', 'optimax-core' ),
        'options' => [
          'date'        => esc_html__( 'Date (Recents comes first)', 'optimax-core' ),
          'title'       => esc_html__( 'Title', 'optimax-core' ),
          'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'optimax-core' ),
        ],
        'default' => 'date',
      ],
      [
        'mode' => 'section_end',
      ],
      ///////////////////////////////////////////////////////////////////////////////////
      // Responsive Columns for slider
      [
        'mode'    => 'section_start',
        'id'      => 'sec_responsive_slider',
        'condition' => [ 'style' => [ 'style3','style5', ] ],
        'label'   => esc_html__( 'Number of Responsive Columns for slider', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg_slider',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '2',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md_slider',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '2',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm_slider',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xs_slider',
        'label'   => esc_html__( 'Phones: < 768px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_mobile_slider',
        'label'   => esc_html__( 'Small Phones: < 480px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'mode' => 'section_end',
      ],


       // Slider options
      [
        'mode'        => 'section_start',
        'id'          => 'sec_slider',
        'label'       => esc_html__( 'Slider Options', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_autoplay',
        'label'       => esc_html__( 'Autoplay', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_stop_on_hover',
        'label'       => esc_html__( 'Stop on Hover', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Stop autoplay on mouse hover. Default: On', 'optimax-core' ),
        'condition'   => ['slider_autoplay' => 'yes', 'style' => 'unavailable'],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'slider_interval',
        'label'   => esc_html__( 'Autoplay Interval', 'optimax-core' ),
        'options' => [
          '10000' => esc_html__( '10 Seconds', 'optimax-core' ),
          '8000' => esc_html__( '8 Seconds', 'optimax-core' ),
          '5000' => esc_html__( '5 Seconds', 'optimax-core' ),
          '4000' => esc_html__( '4 Seconds', 'optimax-core' ),
          '3000' => esc_html__( '3 Seconds', 'optimax-core' ),
          '2000' => esc_html__( '2 Seconds', 'optimax-core' ),
          '1000' => esc_html__( '1 Second',  'optimax-core' ),
        ],
        'default' => '5000',
        'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'optimax-core' ),
        'condition'   => ['slider_autoplay' => 'yes'],
      ],
      [
        'type'    => Controls_Manager::NUMBER,
        'id'      => 'slider_autoplay_speed',
        'label'   => esc_html__( 'Autoplay Slide Speed', 'optimax-core' ),
        'default' => 600,
        'description' => esc_html__( 'Slide speed in milliseconds. Default: 200', 'optimax-core' ),
        'condition'   => ['slider_autoplay' => 'yes'],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_loop',
        'label'       => esc_html__( 'Loop', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Loop to first item. Default: On', 'optimax-core' ),
        'condition'   => ['style' => 'style1'],
      ],
      [
        'mode' => 'section_end',
      ],


      // Style start
      [
        'mode'    => 'section_start',
        'id'      => 'title_style',
        'label'   => esc_html__( 'title Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Testimonial Title Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-content .testimonial-content .item-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-3 .testimonial-box-layout .media .media-body .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .title-subtitle .rtin-title' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Testimonial Title Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-title,
          {{WRAPPER}}  .rtel-testimonial-2 .slick-carousel-content .testimonial-content .item-title,
          {{WRAPPER}}  .rtel-testimonial-3 .testimonial-box-layout .media .media-body .rtin-title,
          {{WRAPPER}}  .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .title-subtitle .rtin-title,
          {{WRAPPER}}  noselector,
          {{WRAPPER}}  noselector
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_margin',
        'label'      => __( 'Testimonial Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-content .testimonial-content .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-3 .testimonial-box-layout .media .media-body .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .title-subtitle .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} noselector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      [
        'mode' => 'section_end',
      ],

      [
        'mode'    => 'section_start',
        'id'      => 'subtitle_style',
        'label'   => esc_html__( 'Subtitle Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'subtitle_color',
        'label'     => esc_html__( 'Sub-Title Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-content .testimonial-content .item-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-3 .testimonial-box-layout .media .media-body .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .title-subtitle .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} noselector' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'Sub-Title Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-subtitle,
          {{WRAPPER}}  .rtel-testimonial-2 .slick-carousel-content .testimonial-content .item-subtitle,
          {{WRAPPER}}  .rtel-testimonial-3 .testimonial-box-layout .media .media-body .rtin-subtitle,
          {{WRAPPER}}  .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .title-subtitle .rtin-subtitle,
          {{WRAPPER}}  noselector,
          {{WRAPPER}}  noselector,
          {{WRAPPER}}  noselector
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'subtitle_margin',
        'label'      => __( 'Subtitle Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-content .testimonial-content .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-3 .testimonial-box-layout .media .media-body .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .title-subtitle .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} noselector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      [
        'mode' => 'section_end',
      ],

      [
        'mode'    => 'section_start',
        'id'      => 'content_style',
        'label'   => esc_html__( 'Testimonial Content Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'testimonial_content_color',
        'label'     => esc_html__( 'Testimonial Content Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-paragraph' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-content .testimonial-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-3 .testimonial-box-layout .rtin-paragraph' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .rtin-paragraph' => 'color: {{VALUE}}',
          '{{WRAPPER}} noselector' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'testimonial_content_typo',
        'label'          => esc_html__( 'Testimonial Content Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-paragraph,
          {{WRAPPER}}  .rtel-testimonial-2 .slick-carousel-content .testimonial-content p,
          {{WRAPPER}}  .rtel-testimonial-3 .testimonial-box-layout .rtin-paragraph,
          {{WRAPPER}}  .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .rtin-paragraph,
          {{WRAPPER}}  noselector
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'testimonial_content_margin',
        'label'      => __( 'Testimonial Content Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-right .single-testimonial .item-paragraph' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-content .testimonial-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-3 .testimonial-box-layout .rtin-paragraph' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-testimonial-4 .testimonial-box-layout .image-with-meta .rtin-paragraph' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} noselector' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'dot_style',
        'label'   => esc_html__( 'Dot Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'dot_color',
        'label'     => esc_html__( 'Dot Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-testimonial-1 .dot-control-layout1 .owl-dots button' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-nav .nav-item img' => 'border-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-3 .dot-control-layout2 .owl-dots button' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-4 .dot-control-layout2 .owl-dots button' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} noselector' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'dot_accent_color',
        'label'     => esc_html__( 'Dot Accent Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-testimonial-1 .rtin-testimonial-left:after' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-1 .dot-control-layout1 .owl-dots button.active' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-2 .slick-carousel-nav .slick-current .nav-item img' => 'border-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-3 .dot-control-layout2 .owl-dots button.active' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} .rtel-testimonial-4 .dot-control-layout2 .owl-dots button.active' => 'background-color: {{VALUE}}',
          '{{WRAPPER}} noselector' => 'color: {{VALUE}}',
          '{{WRAPPER}} noselector' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'testimonial_heading_style',
        'label'   => esc_html__( 'Heading Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
        'condition'   => [ 'style' => 'style1' ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'heading_color',
        'label'     => esc_html__( 'Heading Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-testimonial-1 .heading-layout1 h2' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'heading_typo',
        'label'          => esc_html__( 'Heading Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}   .rtel-testimonial-1 .heading-layout1 h2
        ',
      ],
      
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'heading_content_margin',
        'label'      => __( 'Heading Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}}  .rtel-testimonial-1 .heading-layout1 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],

    ];
    return $fields;
  }
  private function rt_load_scripts( $script ){
    if ($script == 'slick') {
      wp_enqueue_style( 'slick' );
      wp_enqueue_style( 'slick-theme' );
      wp_enqueue_script( 'imagesloaded' );
      wp_enqueue_script( 'slick' );
    }
    if ($script == 'owl') {
      wp_enqueue_style('owl-carousel');
      wp_enqueue_script('owl-carousel');
    }
  }
  protected function slick_settings( $data ) {
    // $slick is using in testimonial 2
    $slick_content_id = "slick-carousel-content-" . uniqid();
    $slick_nav_id     = "slick-carousel-nav-" . uniqid();
   $slick_options_common = [
    "speed"               => $data['slider_autoplay_speed'],
    "autoplaySpeed"       => $data['slider_interval'],
    "pauseOnHover"        => $this->bool_casting( $data['slider_stop_on_hover'] ),
    "autoplay"            => $this->bool_casting( $data['slider_autoplay'] ),
    "lazyLoad"            => "progressive",
    "dots"                => false,
    "arrows"              => false,
    "adaptiveHeight"      => false,
    "rtl"                 => false,
     "initialSlide"       => $data['slick_go_to'] - 1,
   ];
   if ( is_rtl() ) {
     $slick_options_common['rtl'] = true;
   }
   $slick_content_options = [
      "slidesToShow"        => 1,
      "slidesToShowTab"     => 1,
      "slidesToShowMobile"  => 1,
      "slidesToScroll"      => 1,
      "asNavFor"            => '#'. $slick_nav_id,
    ];
    $slick_content_options = array_merge($slick_options_common, $slick_content_options);
    $slick_nav_options  = [
      "slidesToShow"        => 5,
      "slidesToShowTab"     => 5,
      "slidesToShowMobile"  => 3,
      "slidesToScroll"      => 1,
      "focusOnSelect"       => true,
      "asNavFor"            => '#'. $slick_content_id,
      "prevArrow"           => "<span class=\"slick-prev slick-navigation\"><i class=\"flaticon-back\"></i></span>",
      "nextArrow"           => "<span class=\"slick-next slick-navigation\"><i class=\"flaticon-next\"></i></span>",
    ];
    $slick_nav_options = array_merge($slick_options_common, $slick_nav_options);

    $data['slick_content_options']   = json_encode( $slick_content_options );
    $data['slick_content_id']        = $slick_content_id;
    $data['slick_nav_options']       = json_encode( $slick_nav_options );
    $data['slick_nav_id']            = $slick_nav_id;
    return $data;
  }
  public function owl_settings( $data ) {

    $uniqueid = uniqid();
    $owl_data = [
      'nav'                => false,
      'dots'               => false,
      'autoplay'           => $data['slider_autoplay'] == 'yes' ? true : false,
      'autoplayTimeout'    => $data['slider_interval'],
      'autoplaySpeed'      => $data['slider_autoplay_speed'],
      'autoplayHoverPause' => $data['slider_stop_on_hover'] == 'yes' ? true : false,
      'loop'               => $data['slider_loop'] == 'yes' ? true : false,
      'margin'             => 10,
      'smartSpeed'         => 1200,
      'responsive'         => [
        '0'    => [
          'items' => 1,
          'nav'   => false,
          'dots'  => true,
        ],
        '480'  => [
          'items' => 1,
          'nav'   => false,
          'dots'  => true,
        ],
        '768'  => [
          'items' => 1,
          'nav'   => false,
          'dots'  => true,
        ],
        '992'  => [
          'items' => 1,
          'nav'   => false,
          'dots'  => true,
        ],
        '1200' => [
          'items' => 1,
          'nav'   => false,
          'dots'  => true,
        ],
      ]
    ];

    if ( $data['style'] == 'style3' || $data['style'] == 'style5' ) {
      $owl_data['responsive'] = [
        '0'    => [
          'items' => $data['col_mobile_slider'],
          'nav'   => false,
          'dots'  => true,
        ],
        '480'  => [
          'items' => $data['col_xs_slider'],
          'nav'   => false,
          'dots'  => true,
        ],
        '768'  => [
          'items' => $data['col_sm_slider'],
          'nav'   => false,
          'dots'  => true,
        ],
        '992'  => [
          'items' => $data['col_md_slider'],
          'nav'   => false,
          'dots'  => true,
        ],
        '1200' => [
          'items' => $data['col_lg_slider'],
          'nav'   => false,
          'dots'  => true,
        ],
      ];

    }
 

    if ( is_rtl () ) {
      $owl_data['rtl'] = true;
    }


    $data['owl_data'] = json_encode( $owl_data );
    $data['uniqueid'] = $uniqueid;
    return $data;

  }
  protected function render() {
    $data = $this->get_settings();
    $data = $this->slick_settings( $data );
    $data = $this->owl_settings( $data );

    $script = '';
    switch ( $data['style'] ) {
      case 'style5':
        $template = 'view-5';
        $script = 'owl';
        break;
      case 'style4':
        $template = 'view-4';
        $script = 'owl';
        break;
      case 'style3':
        $template = 'view-3';
        $script = 'owl';
        break;
      case 'style2':
        $template = 'view-2';
        $script = 'slick';
        break;
      case 'style1':
        $template = 'view-1';
        $script = 'owl';
        break;
      default:
        $template = 'view-1';
        break;
    }
    $this->rt_load_scripts($script);

    return $this->rt_template( $template, $data );
  }
}
