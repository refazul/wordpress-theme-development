<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";

$args = [
  'post_type'        => "{$prefix}_testimony",
  'posts_per_page'   => -1,
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = isset($multiple_category);
$bool = $bool && is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_testimony_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$posts = get_posts( $args );

?>

<div class="rtel-testimonial-2">
  <div class="slick-carousel slick-carousel-content" id="<?php echo esc_attr( $slick_content_id ); ?>" data-slick='<?php echo esc_attr( $slick_content_options ); ?>'>
    <?php foreach ($posts as $post): ?>
      <?php 
      $designation  = get_post_meta( $post->ID, "{$prefix}_tes_designation", true );
      $content = Helper::generate_excerpt($post, $number_of_words_for_testimonial);
      ?>
      <div class="testimonial-content">
        <p>“
          <?php echo wp_kses_post( $content ) ?>
        ”</p>
        <h3 class="item-title"><?php echo esc_html( $post->post_title ); ?></h3>
        <div class="item-subtitle"><?php echo esc_html( $designation ); ?></div>
      </div>
    <?php endforeach ?>
  </div>
  <div class="slick-carousel slick-carousel-nav" id="<?php echo esc_attr( $slick_nav_id ); ?>" data-slick="<?php echo esc_attr( $slick_nav_options ); ?>">
    <?php foreach ($posts as $post): ?>
      <?php 
      $img = Helper::generate_thumbnail_image( $post, $thumb_size );
      ?>
      <div class="nav-item"><img width="320" height="320" src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $post->post_title ); ?>"></div>
    <?php endforeach ?>
  </div>
</div>