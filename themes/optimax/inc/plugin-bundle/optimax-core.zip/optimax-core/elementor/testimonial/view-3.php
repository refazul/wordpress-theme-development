<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Utils;
use radiustheme\Optimax\Helper;
extract( $data );

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size4";

$args = [
  'post_type'        => "{$prefix}_testimony",
  'posts_per_page'   => -1,
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$bool = isset($multiple_category);
$bool = $bool && is_array($multiple_category);
$bool = $bool && count( $multiple_category ) ;
if ($bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_testimony_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}

$posts = get_posts( $args );

?>
<div class="rtel-testimonial-3">
    <div class="owl-carousel rt-owl-carousel rc-carousel dot-control-layout2" data-carousel-options="<?php echo esc_attr( $owl_data ); ?>">
      <?php foreach ($posts as $post): ?>
        <?php 
        $img          = Helper::generate_thumbnail_image( $post, $thumb_size );
        $designation  = get_post_meta( $post->ID, "{$prefix}_tes_designation", true );
        $content      = Helper::generate_excerpt( $post, $number_of_words_for_testimonial )
        ?>
        <div class="testimonial-box-layout">
          <div class="rtin-paragraph"><?php echo esc_html( $content ); ?></div>
          <div class="media media-none--xs">
            <?php if ($img): ?>
              <div class="rtin-img">
                <img src="<?php echo esc_html( $img ); ?>" class="media-img-auto" alt="testimonial">
              </div>
            <?php endif ?>
            <div class="media-body space-md">
              <h3 class="rtin-title"><?php echo esc_html( $post->post_title ); ?></h3>
              <div class="rtin-subtitle"><?php echo esc_html( $designation ); ?></div>
            </div>
          </div>
        </div>
      <?php endforeach ?>
    </div>
</div> 

