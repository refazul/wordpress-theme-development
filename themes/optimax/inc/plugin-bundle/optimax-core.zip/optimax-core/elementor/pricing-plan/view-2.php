<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );
$anchor = Helper::generate_elementor_anchor(
  $button_url,
  esc_html( $button_text ),
  'pricing-btn btn-fill gradient-accent-2 font-semibold'
);

?>

<div class="rtel-pricing-plan-2 ul-zero">
   <div class="rtin-pricing-plan">
    <?php if ( $is_popular == 'yes' ): ?>
      <div class="rtin-tag gradient-accent-2"><?php echo esc_html( $popular_text ); ?></div>
    <?php endif ?>
    <h3 class="rtin-title"><?php echo esc_html( $package_name ); ?></h3>
    <div class="rtin-subtitle"><?php echo esc_html( $package_subtitle ); ?></div>
    <ul class="rtin-features">
      <?php foreach ($features as $feature): ?>
        <li>
          <?php
          extract( $feature );
          $final_icon_class  = " fas fa-check";
          $final_icon_image_url = '';
          if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
            $final_icon_class = $dynamic_icon_class;
          }
          if ( is_array( $icon_class['value'] ) ) {
            $final_icon_image_url = $icon_class['value']['url'];
          }
          ?>
          <?php if ( $has_icon == 'yes' ): ?>
            <?php if ( $final_icon_image_url ): ?>
              <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
            <?php else: ?>
              <i  style="color: <?php echo esc_attr( $icon_color ); ?>" class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
            <?php endif ?>
          <?php endif ?>

          <span class="rtin-features-text">
            <?php echo esc_html( $feature['text'] ); ?>
          </span>
        </li>
      <?php endforeach ?>
    </ul>
    <div class="rtin-bottom-content">
        <div class="rtin-price"><?php echo esc_html( $currency_icon ); ?><?php echo esc_html( $price ); ?><span> / <?php echo esc_html( $duration ); ?></span></div>
        <?php echo wp_kses_post( $anchor ); ?>
    </div>
  </div> 
</div>
