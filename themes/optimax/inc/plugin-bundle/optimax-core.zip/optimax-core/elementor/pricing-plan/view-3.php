<?php
namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$anchor = Helper::generate_elementor_anchor(
  $button_url,
  esc_html( $button_text ) . '',
  'btn-fill-accent-3 pricing-btn'
);

$final_icontop_class       = " fas fa-thumbs-up";
if ( is_string( $icon_top['value'] ) && $dynamic_icontop_class =  $icon_top['value']  ) {
  $final_icontop_class     = $dynamic_icontop_class;
}

?>
<div class="rtel-pricing-plan-3 ul-zero">
  <div class="rtin-pricing-plan">
	<div class="top-section">
		<div class="icon_shape">
		<?php if ( $icon_top ) { ?>
		  <i class="<?php  echo esc_attr( $final_icontop_class ); ?>"></i>
        <?php } ?>
		</div>
	</div>
    <div class="rtin-price">
      <?php if(!empty($currency_icon)) { ?><span class="currency"><?php echo esc_html( $currency_icon ); ?></span><?php } ?>
      <span class="price"><?php echo esc_html( $price ); ?></span>
      <?php if(!empty($duration)) { ?><span class="duration"><?php echo esc_html( $duration ); ?></span><?php } ?>
    </div>
	<h3 class="rtin-title"><?php echo esc_html( $package_name ); ?></h3>
    <?php if(!empty($package_subtitle)) { ?><div class="rtin-subtitle"><?php echo esc_html( $package_subtitle ); ?></div><?php } ?>
    <ul class="rtin-features">
      <?php foreach ($features as $feature): ?>
          <li>
            <?php
            extract( $feature );
            $final_icon_image_url = '';
            if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
              $final_icon_class = $dynamic_icon_class;
            }
            if ( is_array( $icon_class['value'] ) ) {
              $final_icon_image_url = $icon_class['value']['url'];
            }
            ?>
            <?php if ( $has_icon == 'yes' ): ?>
              <?php if ( $final_icon_image_url ): ?>
                <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
              <?php else: ?>
                <i style="color: <?php echo esc_attr( $icon_color ); ?>" class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
              <?php endif ?>
            <?php endif ?>

            <span class="rtin-features-text"><?php echo esc_html( $feature['text'] ); ?></span>
          </li>
        <?php endforeach ?>
    </ul>
    <?php echo wp_kses_post( $anchor ); ?>
  </div>
</div>
