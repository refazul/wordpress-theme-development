<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Pricing_Plan extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Pricing Plan', 'optimax-core' );
    $this->rt_base = 'rt-pricing-plan';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
          'style5' => esc_html__( 'style 5', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      [
		'type'         => Controls_Manager::ICONS,
		'id'           => 'icon_top',
		'label'        => esc_html__( 'Top Icon', 'optimax-core' ),
		'default'      => [
		  'value' => "fas fa-check",
		],
		'condition'   => [ 'style' => [ 'style3', ] ],
	  ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'package_name',
        'label'       => esc_html__( 'Package Name', 'optimax-core' ),
        'default'     => "Silver Package",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'package_subtitle',
        'label'       => esc_html__( 'Package Subtitle', 'optimax-core' ),
        'default'     => "Limited Access",
        'condition'   => [ 'style' => [ 'style2', 'style3', ] ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'is_popular',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Is Popular', 'optimax-core' ),
        'default'     => "No",
        'condition'   => [ 'style' => [ 'style2', ] ],
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'popular_text',
        'label'       => esc_html__( 'Popular Text', 'optimax-core' ),
        'default'     => "POPULAR",
        'condition'   => [
          'style' => ['style2'],
          'is_popular' => 'yes'
        ],
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'currency_icon',
        'label'       => esc_html__( 'Currency Icon', 'optimax-core' ),
        'default'     => "$",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'price',
        'label'       => esc_html__( 'Price', 'optimax-core' ),
        'description' => esc_html__( 'Prefix of currency.', 'optimax-core' ),
        'default'     => "39.99",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'duration',
        'label'       => esc_html__( 'Duration', 'optimax-core' ),
        'Description' => esc_html__( 'Use prefix if you want', 'optimax-core' ),
        'default'     => "Per Month",
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'button_text',
        'label'       => esc_html__( 'Button Text', 'optimax-core' ),
        'default'     => "Buy Now",
      ],
      [
        'type'        => Controls_Manager::URL,
        'id'          => 'button_url',
        'label'       => esc_html__( 'Button URL', 'optimax-core' ),
        'default'     => ['url' => '#'],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'has_icon',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Features prefix icon', 'optimax-core' ),
        'default'     => "yes",
      ],
      [
        'type'    => Controls_Manager::REPEATER,
        'id'      => 'features',
        'label'   => esc_html__( 'Features ', 'optimax-core' ),
        'fields'  => [
          [
            'type'  => Controls_Manager::TEXT,
            'name'  => 'text',
            'label' => esc_html__( 'Text', 'optimax-core' ),
          ],
          [
            'type'         => Controls_Manager::ICONS,
            'name'         => 'icon_class',
            'label'        => esc_html__( 'Icon', 'optimax-core' ),
            'Description'  => esc_html__( 'Icon will place before features text', 'optimax-core' ),
            'default'      => [
              'value' => "fas fa-check",
            ],
          ],
          [
            'type'     => Controls_Manager::COLOR,
            'name'     => 'icon_color',
            'label'    => esc_html__( 'Icon Color', 'optimax-core' ),
            'default'  => '#43a047',
          ],

        ],
       'default' => [
          ['text' => '1 E-mail Address', ],
          ['text' => '10 Space Users', ],
          ['text' => '15 GB Space', ],
          ['text' => 'Unlimited Bandwidth', ],
          ['text' => 'Support Reports', ],
          ['text' => '15GB Uploads', ],
        ],
      ],      

      [
        'mode' => 'section_end',
      ],
	  
	  // Package Top Icon
      [
        'mode'      => 'section_start',
        'id'        => 'package_topicon_style',
        'label'     => esc_html__( 'Icon Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style3'] ],
      ],
	  [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'package_topicon_typo',
        'label'          => esc_html__( 'Icon Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .top-section i
        ',
      ],
	  [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'packange_topicon_color',
        'label'     => esc_html__( 'Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-pricing-plan-3 .rtin-pricing-plan .top-section i' => 'color: {{VALUE}}',
        ],
      ],
	  
	  [
        'mode' => 'section_end',
      ],

      // Style
      [
        'mode'    => 'section_start',
        'id'      => 'package_name_style',
        'label'   => esc_html__( 'Package Name Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'package_name_typo',
        'label'          => esc_html__( 'Package Name Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-title,
          {{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-title,
          {{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-title,
          {{WRAPPER}}  .rtel-pricing-plan-5 .rtin-pricing-plan .rtin-title,
          {{WRAPPER}}  .rtel-pricing-plan-4 .rtin-title
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'packange_name_color',
        'label'     => esc_html__( 'Package Name Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-title' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-title'               => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-title'               => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-5 .rtin-pricing-plan .rtin-title'               => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-4 .rtin-title'                                  => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'package_name_content_margin',
        'label'      => __( 'Package Name Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-title'               => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-title'               => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-pricing-plan-5 .rtin-pricing-plan .rtin-title'               => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtel-pricing-plan-4 .rtin-title'                                  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],

      // Package subtitle
      [
        'mode'      => 'section_start',
        'id'        => 'package_subtitle_style',
        'label'     => esc_html__( 'Package Subtitle Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style2', 'style3'] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'package_subtitle_typo',
        'label'          => esc_html__( 'Package Subtitle Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-subtitle,
          {{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-subtitle
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'package_subtitle_color',
        'label'     => esc_html__( 'Package Subtitle Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-subtitle' => 'color: {{VALUE}}'
        ],
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'package_subtitle_content_margin',
        'label'      => __( 'Package Subtitle Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],

      // currency icon style

      [
        'mode'      => 'section_start',
        'id'        => 'currency_icon_style',
        'label'     => esc_html__( 'Currency Icon Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style3', 'style4',  'style5',] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'currency_icon_typo',
        'label'          => esc_html__( 'Currency Icon Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-price .currency,
          {{WRAPPER}}  .rtel-pricing-plan-5 .rtin-pricing-plan .price_and_currency .currency,
          {{WRAPPER}}  .rtel-pricing-plan-4 .rtin-price-box .currency
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'currency_icon_color',
        'label'     => esc_html__( 'Currency Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-price .currency' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-5 .rtin-pricing-plan .price_and_currency .currency' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-4 .rtin-price-box .currency'                => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode' => 'section_end',
      ],

      // price Style
      [
        'mode'    => 'section_start',
        'id'      => 'pricing_style',
        'label'   => esc_html__( 'Pricing Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'pricing_typo',
        'label'          => esc_html__( 'Pricing Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-price,
          {{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-bottom-content .rtin-price,
          {{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-price .price,
          {{WRAPPER}}  .rtel-pricing-plan-5 .rtin-pricing-plan .price_and_currency .price,
          {{WRAPPER}}  .rtel-pricing-plan-4 .rtin-price-box .price
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'pricing_color',
        'label'     => esc_html__( 'Pricing Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-price'        => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-bottom-content .rtin-price' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-price .price'               => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-pricing-plan-5 .rtin-pricing-plan .price_and_currency .price'               => 'color: {{VALUE}}',
          '{{WRAPPER}}  .rtel-pricing-plan-4 .rtin-price-box .price'                              => 'color: {{VALUE}}',
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],
      // Pricing Cent
      [
        'mode'      => 'section_start',
        'id'        => 'pricing_cent_style',
        'label'     => esc_html__( 'Pricing-Cent Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style4', ] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'pricing_cent_typo',
        'label'          => esc_html__( 'Pricing Cent Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-4 .rtin-price-box .cent
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'pricing_cent_color',
        'label'     => esc_html__( 'Pricing-Cent Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-pricing-plan-4 .rtin-price-box .cent' => 'color: {{VALUE}}'
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],

      // Duration Style
      [
        'mode'    => 'section_start',
        'id'      => 'duration_style',
        'label'   => esc_html__( 'Duration Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'duration_typo',
        'label'          => esc_html__( 'Duration Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-duration,
          {{WRAPPER}} .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-bottom-content .rtin-price span,
          {{WRAPPER}} .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-price .duration,
          {{WRAPPER}} .rtel-pricing-plan-5 .rtin-pricing-plan .duration,
          {{WRAPPER}} .rtel-pricing-plan-4 .rtin-price-box .duration
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'duration_color',
        'label'     => esc_html__( 'Duration Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-pricing-plan-1 .rtin-pricing-plan .rtin-heading .rtin-duration'          => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-bottom-content .rtin-price span' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-3 .rtin-pricing-plan .rtin-price .duration'                 => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-5 .rtin-pricing-plan .duration'                 => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-pricing-plan-4 .rtin-price-box .duration'                                => 'color: {{VALUE}}',
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'item_text_icon_style',
        'label'   => esc_html__( 'Item Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'item_text_typo',
        'label'          => esc_html__( 'Item Text Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtin-features li .rtin-features-text
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'item_text_color',
        'label'     => esc_html__( 'Item Text Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtin-features li .rtin-features-text' => 'color: {{VALUE}}'
        ],
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'icon_font_size',
        'label'      => __( 'Item Icon Font Size', 'optimax-core' ),
        'size_units' => ['px', '%'],
        'range'      => [
          'px' => [
            'min' => 5,
            'max' => 120,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .rtin-features li i' => 'font-size: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'item_text_content_margin',
        'label'      => __( 'Item Text Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtin-features li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator'  => 'before',
      ],
      [
        'type'       => Controls_Manager::SLIDER,
        'mode'       => 'responsive',
        'id'         => 'icon_margin_right',
        'label'      => __( 'Icon Margin Right', 'optimax-core' ),
        'size_units' => ['px', '%'],
        'range'      => [
          'px' => [
            'min' => 0,
            'max' => 2000,
          ],
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => 10,
        ],
        'selectors' => [
          '{{WRAPPER}} .rtin-pricing-plan .rtin-features li i' => 'margin-right: {{SIZE}}{{UNIT}};',
        ]
      ],
      
      [
        'mode' => 'section_end',
      ],

      // popular text style
      [
        'mode'      => 'section_start',
        'id'        => 'popular_text_style',
        'label'     => esc_html__( 'Popular Text Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [
          'style' => ['style2'],
          'is_popular' => 'yes'
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'popular_text_typo',
        'label'          => esc_html__( 'Popular Text Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-tag
        ',
      ],
      [
        'mode'            => 'group',
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'popular_text_background',
        'types'           => [ 'gradient', 'classic' ],
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Popular Text Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-tag
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'popular_text_color',
        'label'     => esc_html__( 'Popular Text Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-tag' => 'color: {{VALUE}}'
        ],
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'popular_text_content_margin',
        'label'      => __( 'Popular Text Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-pricing-plan-2 .rtin-pricing-plan .rtin-tag' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator' => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],

     // Button Style
      [
        'mode'    => 'section_start',
        'id'      => 'button_content',
        'label'   => esc_html__( 'Button Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'content_color',
        'label'     => esc_html__( 'Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtin-pricing-plan a.pricing-btn' => 'color: {{VALUE}}'
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'content_hover_color',
        'label'     => esc_html__( 'Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .rtin-pricing-plan a.pricing-btn:hover' => 'color: {{VALUE}}',
        ],
      ],

      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'content_typo',
        'label'          => esc_html__( 'Content Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-pricing-plan a.pricing-btn',
      ],
       [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'border_color',
        'label'     => esc_html__( 'Border Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtin-pricing-plan a.pricing-btn' => 'border-color: {{VALUE}}'
        ],
        'condition' => [ 'style' => [ 'style1', 'style3', 'style4' ] ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'border_hover_color',
        'label'     => esc_html__( 'Border Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtin-pricing-plan a.pricing-btn:hover' => 'border-color: {{VALUE}}',
        ],
        'condition' => [ 'style' => [ 'style1', 'style3', 'style4' ] ],
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'icon_size',
        'label'       => esc_html__( 'Icon Size', 'optimax-core' ),
        'default'     => '14',
        'selectors'   => [
          '{{WRAPPER}} .rtin-pricing-plan a.pricing-btn i' => 'font-size: {{VALUE}}px'
        ],
        'condition'   => [ 'has_icon' => 'yes' ],
      ],

      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'icon_margin',
        'label'      => __( 'Icon Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtin-pricing-plan a.pricing-btn i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator'  => 'before',
      ],
      [
        'mode'            => 'group',
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'button_background',
        'types'           => [ 'classic', 'gradient' ],
        'label'           => esc_html__( 'Button Background Gradient', 'optimax-core' ),
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Button Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtin-pricing-plan a.pricing-btn
        ',
      ],
      [
        'mode'            => 'group',
        'separator'       => 'after',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'button_background_hover',
        'types'           => [ 'classic', 'gradient' ],
        'label'           => esc_html__( '', 'optimax-core' ),
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Button Background Hover', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtin-pricing-plan a.pricing-btn.btn-fill:after,
          {{WRAPPER}} .rtin-pricing-plan a.pricing-btn:hover
        ',
      ],
      [
        'mode' => 'section_end',
      ],

    ];
    return $fields;
  }
  protected function render() {
    $data = $this->get_settings();
    switch ( $data['style'] ) {
      case 'style5':
        $template = 'view-5';
        break;
      case 'style4':
        $template = 'view-4';
        break;
      case 'style3':
        $template = 'view-3';
        break;
      case 'style2':
        $template = 'view-2';
        break;
      default:
        $template = 'view-1';
        break;
    }
    return $this->rt_template( $template, $data );
  }
}
