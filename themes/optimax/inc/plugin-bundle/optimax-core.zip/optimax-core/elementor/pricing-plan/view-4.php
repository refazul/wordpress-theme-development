<?php
namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );

$cent = '';
$price_exploded = explode(".", $price);
if ( isset( $price_exploded[1] ) ) {
  $cent = $price_exploded[1];
}
$price_without_decimal = $price_exploded[0];
$anchor = Helper::generate_elementor_anchor(
  $button_url,
  esc_html( $button_text ) . '',
  'ghost-btn-2 text-accent mg-t-20 pricing-btn'
);

?>
<div class="rtel-pricing-plan-4 ul-zero">
  <div class="rtin-pricing-plan">
    <h3 class="rtin-title"><?php echo esc_html( $package_name ); ?></h3>
    <div class="rtin-price-box">
		<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" width="250" height="110" viewBox="0 0 250 110">
		  <defs>
			<style>
			  .cls-1 {
				fill: #4a3bca;
				fill-rule: evenodd;
			  }
			</style>
		  </defs>
		  <path d="M6.000,-0.000 L244.000,-0.000 C247.314,-0.000 250.000,2.686 250.000,6.000 L237.000,104.000 C237.000,107.314 234.314,110.000 231.000,110.000 L21.000,110.000 C17.686,110.000 15.000,107.314 15.000,104.000 L-0.000,6.000 C-0.000,2.686 2.686,-0.000 6.000,-0.000 Z" class="cls-1"/>
		</svg>
		<div class="rtin-price-info">
			<span class="currency"><?php echo esc_html( $currency_icon ); ?></span>
			<span class="price"><?php echo esc_html( $price_without_decimal ); ?></span>
			<?php if ( $cent ): ?>
			<span class="cent">.<?php echo esc_html( $cent ); ?> </span>
			<?php endif ?>
			<span class="duration">/<?php echo esc_html( $duration ); ?></span>
		</div>
    </div>
    <ul class="rtin-features">
      <?php foreach ($features as $feature): ?>
        <li>
          <?php
          extract( $feature );
          $final_icon_class  = " fas fa-check";
          $final_icon_image_url = '';
          if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
            $final_icon_class = $dynamic_icon_class;
          }
          if ( is_array( $icon_class['value'] ) ) {
            $final_icon_image_url = $icon_class['value']['url'];
          }
          ?>
          <?php if ( $has_icon ): ?>
            <?php if ( $final_icon_image_url ): ?>
              <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
            <?php else: ?>
              <i style="color: <?php echo esc_attr( $icon_color ); ?>" class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
            <?php endif ?>
          <?php endif ?>

          <span class="rtin-features-text">
            <?php echo esc_html( $feature['text'] ); ?>
          </span>
        </li>
      <?php endforeach ?>
    </ul>
    <?php echo wp_kses_post( $anchor ); ?>
  </div>
</div>
