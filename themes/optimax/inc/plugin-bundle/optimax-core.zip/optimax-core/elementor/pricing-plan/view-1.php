<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract( $data );
$anchor = Helper::generate_elementor_anchor(
  $button_url,
  esc_html( $button_text ) . '',
  'btn-fill-accent-3 pricing-btn'
);
?>

<div class="rtel-pricing-plan-1 ul-zero">
  <div class="rtin-pricing-plan">
    <div class="rtin-heading">
      <h3 class="rtin-title"><?php echo esc_html( $package_name ); ?></h3>
      <div class="rtin-price"><?php echo esc_html( $currency_icon ); ?><?php echo esc_html( $price ); ?></div>
      <div class="rtin-duration">/ <?php echo esc_html( $duration ); ?></div>
    </div>
    <ul class="rtin-features">
      <?php foreach ($features as $feature): ?>
        <li>
          <?php
          extract($feature);
          $final_icon_class  = "fas fa-check";
          $final_icon_image_url = '';
          if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
            $final_icon_class = $dynamic_icon_class;
          }
          if ( is_array( $icon_class['value'] ) ) {
            $final_icon_image_url = $icon_class['value']['url'];
          }
          ?>
          <?php if ($has_icon == 'yes'): ?>
            <?php if ( $final_icon_image_url ): ?>
              <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
            <?php else: ?>
              <i style="color: <?php echo esc_attr( $icon_color ); ?>"  class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
            <?php endif ?>
          <?php endif ?>

          <span class="rtin-features-text">
            <?php echo esc_html( $feature['text'] ); ?>
          </span>
        </li>
      <?php endforeach ?>
    </ul>
    <?php echo wp_kses_post( $anchor ); ?>
    <div class="rtin-curved">
    <?php 
      $random_id_gradient = 'gradient_id_' . Helper::generate_random_string();
    ?>

      <svg width="100%" height="258px" viewBox="0 0 361.000000 228.000000" preserveAspectRatio="none" class="svg-shape">
        <defs>
          <linearGradient id="<?php echo esc_attr( $random_id_gradient ); ?>" x1="0%" x2="62.932%" y1="77.715%" y2="0%">
             <stop offset="0%" stop-color="var(--gradient_2_light )" stop-opacity="1" />
             <stop offset="100%" stop-color="var(--gradient_2_dark )" stop-opacity="1" />
          </linearGradient>
        </defs>

        <g transform="translate(0.000000,228.000000) scale(0.100000,-0.100000)" stroke="none" class="svg-color">
          <path
          fill="url(#<?php echo esc_attr( $random_id_gradient ); ?>)"
          d="M0 1162 l0 -1119 114 58 c212 109 419 179 652 220 112 21 162 24 389
          24 361 0 542 -26 1165 -170 598 -138 841 -175 1148 -175 l142 0 0 1140 0 1140
          -1805 0 -1805 0 0 -1118z"></path>
        </g>
      </svg>
    </div>
  </div>
</div>