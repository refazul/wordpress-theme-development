<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Section_Title_Subtitle extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Section Title Subtitle', 'optimax-core' );
    $this->rt_base = 'rt-section-title-subtitle';
    parent::__construct( $data, $args );
  }

  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
	  
	  [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),

        ],
        'default' => 'style1',
      ],

      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'default' => 'Lorem Ipsum',
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'subtitle',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'default' => 'Lorem Ipsum',
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'content',
        'label'   => esc_html__( 'Content', 'optimax-core' ),
        'default' => esc_html__( 'Sorem ipsum dolor sit ametet fermentum vestibulum etiam check box luctus etmi ornare aptent neque volutpat.', 'optimax-core' ),
		'condition'   => [ 'style' => [ 'style2' ] ],
      ],
      
      [
        'id'         => 'width',
        'mode'       => 'responsive',
        'label'      => __( 'Subtitle Width (%)', 'optimax-core' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => [ '%' ],
        'range' => [
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default' => [
          'unit' => '%',
          'size' => 70,
        ],
        'selectors'  => [
          '{{WRAPPER}} .rtin-subtitle > p' => 'width: {{SIZE}}%;',
          '{{WRAPPER}} .rtin-content > p' => 'width: {{SIZE}}%;',
        ],
      ],
      [
        'type'    => Controls_Manager::CHOOSE,
		'mode'    => 'responsive',
        'options' => [
          'left' => [
            'title' => esc_html__( 'Left', 'optimax-core' ),
            'icon' => 'fas fa-align-left',
          ],
          'center' => [
            'title' => esc_html__( 'Center', 'optimax-core' ),
            'icon' => 'fas fa-align-center',
          ],
          'right' => [
            'title' => esc_html__( 'Right', 'optimax-core' ),
            'icon' => 'fas fa-align-right',
          ],
          'justify' => [
            'title' => esc_html__( 'Justified', 'optimax-core' ),
            'icon' => 'fas fa-align-justify',
          ],
        ],
        'id'      => 'text_align',
        'label'   => esc_html__( 'Text Align', 'optimax-core' ),
        'default' => 'center',
        'selectors' => [
          '{{WRAPPER}}' => 'text-align: {{VALUE}}',
          '{{WRAPPER}} .rtin-subtitle' => 'text-align: {{VALUE}}',
        ],
      ],
      [
        'type'        => Controls_Manager::URL,
        'id'          => 'title_url',
        'label'       => esc_html__( 'Title Url', 'optimax-core' ),
      ],
      
      [
        'mode' => 'section_end',
      ],
      // style section
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title Color', 'optimax-core' ),
        'selectors' => ['{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}'],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_link_hover_color',
        'label'   => esc_html__( 'Title Link Hover Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .rtin-title a:hover' => 'color: {{VALUE}}' ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-title',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_margin',
        'label'      => __( 'Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator' => 'before',
      ],

      
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_subtitle',
        'label'   => esc_html__( 'Subtitle', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'subtitle_color',
        'label'   => esc_html__( 'Subtitle Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtin-subtitle' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtin-subtext' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtin-subtitle > p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .style2 .rtin-subtext p' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle_typo',
        'label'          => esc_html__( 'Subtitle Typography', 'optimax-core' ),
		'selector'       => '{{WRAPPER}}  .rtin-subtitle > p',
		'condition'   => [ 'style' => [ 'style1' ] ],
		
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'subtitle2_typo',
        'label'          => esc_html__( 'Subtitle Typography', 'optimax-core' ),
		'selector'       => '{{WRAPPER}}  .rtin-subtext > p',
		'condition'   => [ 'style' => [ 'style2' ] ],
		
      ],
       [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'subtitle_margin',
        'label'      => __( 'Subtitle Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtin-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
          '{{WRAPPER}} .rtin-subtext' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator' => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],
	  
	  [
        'mode'    => 'section_start',
        'id'      => 'sec_style_content',
        'label'   => esc_html__( 'Content', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
		'condition'   => [ 'style' => [ 'style2' ] ],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'content_color',
        'label'   => esc_html__( 'Content Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtin-content' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'content_typo',
        'label'          => esc_html__( 'Content Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-content > p',
      ],
       [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'content_margin',
        'label'      => __( 'Content Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtin-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
        ],
        'separator' => 'before',
      ],
      
      [
        'mode' => 'section_end',
      ],
      
    ];
    return $fields;
  }

  protected function render() {
    $data = $this->get_settings();

    $template = 'view';
	
	switch ( $data['style'] ) {
      case 'style2':
	  $template = 'view-2';
        break;
      case 'style2':
        $template = 'view-1';
        break;
      default:
        $template = 'view-1';
        break;
    }    

    return $this->rt_template( $template, $data );
  }
}
