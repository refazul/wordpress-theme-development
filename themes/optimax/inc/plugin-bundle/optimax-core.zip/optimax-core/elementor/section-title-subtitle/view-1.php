<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$subtitle_style = "";
$title_class = $subtitle ? 'rtin-title has-subtitle' : 'rtin-title';
?>
<div class="rtel-section-title-subtitle <?php echo esc_html( $style ); ?>">
    <h2 class="<?php echo esc_attr( $title_class ); ?>"><?php if ( $title_url['url'] ): ?><?php $all_attributes = Helper::generate_elementor_anchor_attributes( $title_url  );?><a <?php echo wp_kses_post( $all_attributes ); ?> ><?php echo esc_html( $title ); ?></a><?php else: ?><?php echo wp_kses_post( $title ); ?><?php endif ?></h2>
    <?php if ( !empty( $subtitle ) && ( $subtitle != '' ) ){ ?>
      <div class="rtin-subtitle"><p><?php echo wp_kses_post( $subtitle ); ?></p></div>
    <?php } ?>
</div>