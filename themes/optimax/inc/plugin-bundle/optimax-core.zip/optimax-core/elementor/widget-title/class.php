<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Widget_Title extends Custom_Widget_Base {

  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Widget Title', 'optimax-core' );
    $this->rt_base = 'rt-widget-title';
    parent::__construct( $data, $args );
  }

  public function rt_fields() {
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'header_tag',
        'label'   => esc_html__( 'HTML Tag', 'optimax-core' ),
        'options' => [
          'h1' => 'H1',
          'h2' => 'H2',
          'h3' => 'H3',
          'h4' => 'H4',
          'h5' => 'H5',
          'h6' => 'H6',
        ],
        'default' => 'h2',
      ],
      [
        'type'    => Controls_Manager::TEXTAREA,
        'id'      => 'title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'default' => 'Lorem Ipsum',
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'has_border',
        'label_on' => esc_html__( 'Show', 'optimax-core' ),
        'label_off' => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Has Bottom Border', 'optimax-core' ),
        'default'     => "yes",
      ],
      [
        'type' => Controls_Manager::SLIDER,
        'mode' => 'responsive',
        'id'      => 'border_height',
        'label'   => __( 'Border height', 'optimax-core' ),
        'condition'   => [ 'has_border' => 'yes' ],
        'size_units' => ['px'],
        'range' => [
          'px' => [
            'min' => 1,
            'max' => 60,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => 4,
        ],
        'selectors' => [
          '{{WRAPPER}} .rtin-title.has-border:before' => 'padding-bottom: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type' => Controls_Manager::SLIDER,
        'mode' => 'responsive',
        'id'      => 'border_space',
        'label'   => __( 'Border Top Space', 'optimax-core' ),
        'condition'   => [ 'has_border' => 'yes' ],
        'size_units' => ['px', '%'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 120,
          ],
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => 22,
        ],
        'selectors' => [
          '{{WRAPPER}} .rtin-title.has-border' => 'padding-bottom: {{SIZE}}{{UNIT}};',
        ]
      ],
      [
        'type' => Controls_Manager::SLIDER,
        'mode' => 'responsive',
        'id'      => 'border_size',
        'label'   => __( 'Border Size', 'optimax-core' ),
        'condition'   => [ 'has_border' => 'yes' ],
        'size_units' => ['px', '%'],
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 1000,
          ],
          '%' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default' => [
          'unit' => 'px',
          'size' => 50,
        ],
        'selectors' => [
          '{{WRAPPER}} .rtin-title.has-border:before' => 'width: {{SIZE}}{{UNIT}};',
        ]
      ],
          
      [
        'type'    => Controls_Manager::CHOOSE,
        'options' => [
          'left' => [
            'title' => esc_html__( 'Left', 'optimax-core' ),
            'icon' => 'fas fa-align-left',
          ],
          'center' => [
            'title' => esc_html__( 'Center', 'optimax-core' ),
            'icon' => 'fas fa-align-center',
          ],
          'right' => [
            'title' => esc_html__( 'Right', 'optimax-core' ),
            'icon' => 'fas fa-align-right',
          ],
          'justify' => [
            'title' => esc_html__( 'Justified', 'optimax-core' ),
            'icon' => 'fas fa-align-justify',
          ],
        ],
        'id'      => 'title_text_align',
        'label'   => esc_html__( 'Title Text Align', 'optimax-core' ),
        'default' => 'left',
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'    => 'section_start',
        'id'      => 'sec_style_title',
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'title_color',
        'label'   => esc_html__( 'Title Color', 'optimax-core' ),
        'selectors' => ['{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}'],
      ],
      [
        'type'    => Controls_Manager::COLOR,
        'id'      => 'border_background_color',
        'label'   => esc_html__( 'Bottom Border Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-widget-title-1 .rtin-title.has-border:before' => 'background-color: {{VALUE}}'
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .rtin-title',
      ],
      [
        'mode' => 'section_end',
      ],
      
    ];
    return $fields;
  
  }

  protected function render() {
    $data = $this->get_settings();
    $template = 'view-1';
    return $this->rt_template( $template, $data );
  }
}
