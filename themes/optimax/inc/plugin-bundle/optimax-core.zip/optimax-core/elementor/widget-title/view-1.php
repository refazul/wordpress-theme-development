<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
extract($data);
$border_center    = $title_text_align == 'center' ? 'before-border-center' : '';
$border_right     = $title_text_align == 'right' ?  'before-border-right' : '';
$text_align_class = 'text-' . $title_text_align;
$has_border       = $has_border == 'yes' ? 'has-border' : '';
$class_string     = "rtin-title {$border_center} {$border_right} {$has_border}";
$class_attribute  = "class='{$class_string}'";


$title_html       = sprintf( '<%1$s %2$s>%3$s</%1$s>', $header_tag, $class_attribute, $title );
?>
<div class="rtel-widget-title-1 <?php echo esc_attr( $text_align_class ); ?>">
  <?php echo wp_kses_post( $title_html ) ?>
</div>

