<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}
$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size2";

$args = [
  'post_type'        => "{$prefix}_case",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$set_category_bool = is_array($multiple_category);
$set_category_bool = $set_category_bool && count( $multiple_category ) ;
if ($set_category_bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_case_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";
?>

<div class="rtel-case-study-1">
  <div class="rtin-case-study">
    <div class="row">
      <?php
       while( $query->have_posts() ): $query->the_post();
        $post         = get_post();
        $title        = $post->post_title;
        $excerpt      = Helper::generate_excerpt( $post, $no_of_excerpt_words );
        $permalink    = get_the_permalink($post);
        $thumb        = Helper::generate_thumbnail_image( $post, $thumb_size );
        ?>
        <div class="<?php echo esc_attr( $col_class ); ?>">
          <div class="rtin-case-study-box-layout1">
            <div class="rtin-case-study-box-layout1-inner">
              <?php if ( $thumb ): ?>
                <div class="rtin-img">
                  <?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail( $thumb_size ); ?><?php } ?>
                </div>
              <?php endif ?>
              <div class="rtin-content">
                <?php 
                $first_term = Helper::taxonomy_first_term( get_the_ID(), $prefix . "_case_category");

                ?>
                <div class="rtin-category"><?php echo wp_kses_post( $first_term ); ?></div>
                <h3 class="rtin-title"> <a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h3>
                <p><?php echo wp_kses_post($excerpt); ?></p>
                <?php if ( $show_readmore == 'yes' ): ?>
                  <a href="<?php echo esc_url( $permalink ); ?>" class="rtin-btn"><?php echo esc_html( $read_more_text ); ?><i class="fas fa-long-arrow-alt-right"></i></a>
                <?php endif ?>
              </div>
          
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>
