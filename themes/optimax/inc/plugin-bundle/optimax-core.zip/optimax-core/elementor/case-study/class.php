<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use radiustheme\Optimax\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Case_Study extends Custom_Widget_Base {
  public function __construct( $data = [], $args = null ){
    $this->rt_name = esc_html__( 'Case Study', 'optimax-core' );
    $this->rt_base = 'rt-case-study';
    $this->rt_translate = [
      'cols'  => [
        '12' => esc_html__( '1 Col', 'optimax-core' ),
        '6'  => esc_html__( '2 Col', 'optimax-core' ),
        '4'  => esc_html__( '3 Col', 'optimax-core' ),
        '3'  => esc_html__( '4 Col', 'optimax-core' ),
        '2'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
	  'cols_slider'  => [
        '1'  => esc_html__( '1 Col', 'optimax-core' ),
        '2'  => esc_html__( '2 Col', 'optimax-core' ),
        '3'  => esc_html__( '3 Col', 'optimax-core' ),
        '4'  => esc_html__( '4 Col', 'optimax-core' ),
        '5'  => esc_html__( '5 Col', 'optimax-core' ),
        '6'  => esc_html__( '6 Col', 'optimax-core' ),
      ],
    ];
    parent::__construct( $data, $args );
  }

  private function rt_cat_dropdown() {
    $prefix = Constants::$theme_prefix;

    $terms = get_terms( [
      'taxonomy' => "{$prefix}_case_category",
      'hide_empty' => true,
    ]);

    $category_dropdown = [];
    foreach ( $terms as $category ) {
      $category_dropdown[$category->term_id] = $category->name;
    }

    return $category_dropdown;
  }
  public function rt_fields(){
    $fields = [
      [
        'mode'    => 'section_start',
        'id'      => 'sec_general',
        'label'   => esc_html__( 'General', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'style',
        'label'   => esc_html__( 'Layout Style', 'optimax-core' ),
        'options' => [
          'style1' => esc_html__( 'style 1', 'optimax-core' ),
          'style2' => esc_html__( 'style 2', 'optimax-core' ),
          'style3' => esc_html__( 'style 3', 'optimax-core' ),
          'style4' => esc_html__( 'style 4', 'optimax-core' ),
          'style5' => esc_html__( 'style 5', 'optimax-core' ),
          'style6' => esc_html__( 'style 6', 'optimax-core' ),
          'style7' => esc_html__( 'style 7', 'optimax-core' ),
          'style8' => esc_html__( 'style 8', 'optimax-core' ),
          'style9' => esc_html__( 'Slider 1', 'optimax-core' ),
        ],
        'default' => 'style1',
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'pagination_display',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Pagination', 'optimax-core' ),
        'default'     => "no",
      ],
      [
        'type'        => Controls_Manager::SELECT2,
        'id'          => 'multiple_category',
        'label'       => __( 'Categories', 'optimax-core' ),
        'options'     => $this->rt_cat_dropdown(),
        'multiple'    => true,
        'description' => esc_html__( 'All categories is selected by default', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'posts_per_page',
        'label'       => esc_html__( 'Posts Per Page', 'optimax-core' ),
        'default'     => 3,
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'orderby',
        'label'   => esc_html__( 'Order By', 'optimax-core' ),
        'options' => [
          'date'        => esc_html__( 'Date (Recents comes first)', 'optimax-core' ),
          'title'       => esc_html__( 'Title', 'optimax-core' ),
          'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'optimax-core' ),
        ],
        'default' => 'date',
      ],
      [
        'type'        => Controls_Manager::NUMBER,
        'id'          => 'no_of_excerpt_words',
        'label'       => esc_html__( 'Number Of words for excerpt', 'optimax-core' ),
        'default'     => '25',
        'condition'   => ['style' => ['style1','style2' ]],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'show_readmore',
        'label_on'    => esc_html__( 'Show', 'optimax-core' ),
        'label_off'   => esc_html__( 'Hide', 'optimax-core' ),
        'label'       => esc_html__( 'Show Readmore', 'optimax-core' ),
        'default'     => "yes",
        'condition'   => [ 'style' => [ 'style1' ] ],
      ],

      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'read_more_text',
        'label'       => esc_html__( 'Read More Text', 'optimax-core' ),
        'default'     => "Read More",
        'condition'   => [ 'style' => [ 'style1',  ] ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'has_button',
        'label'       => __( 'All Case Link', 'optimax-core' ),
        'label_on'    => __( 'On', 'optimax-core' ),
        'label_off'   => __( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'condition'   => [ 'style' => [ 'style3', ] ],
      ],
      [
        'type'        => Controls_Manager::TEXT,
        'id'          => 'button_text',
        'label'       => esc_html__( 'Button Text', 'optimax-core' ),
        'default'     => "VIEW ALL CASES",
        'condition'   => [ 'has_button' => 'yes' ],
      ],
      [
        'mode' => 'section_end',
      ],

      // Responsive Columns for general
      // it will generate bootstrap column
      [
        'mode'    => 'section_start',
        'id'      => 'sec_responsive',
        'label'   => esc_html__( 'Number of Responsive Columns', 'optimax-core' ),
		'condition'   => ['style' => [ 'style1', 'style2', 'style3', 'style4', 'style5', 'style6', 'style7', 'style8']],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xl',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '6',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm',
        'label'   => esc_html__( 'Phones: > 576px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '12',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col',
        'label'   => esc_html__( 'Phones: < 576px', 'optimax-core' ),
        'options' => $this->rt_translate['cols'],
        'default' => '12',
      ],
      [
        'mode' => 'section_end',
      ],
	  
	  // Responsive Columns for slider
      [
        'mode'    => 'section_start',
        'id'      => 'sec_responsive_slider',
        'condition' => [ 'style' => [ 'style9' ] ],
        'label'   => esc_html__( 'Number of Responsive Columns for slider', 'optimax-core' ),
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_lg_slider',
        'label'   => esc_html__( 'Desktops: > 1199px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '4',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_md_slider',
        'label'   => esc_html__( 'Desktops: > 991px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '3',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_sm_slider',
        'label'   => esc_html__( 'Tablets: > 767px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '2',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_xs_slider',
        'label'   => esc_html__( 'Phones: < 768px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'col_mobile_slider',
        'label'   => esc_html__( 'Small Phones: < 480px', 'optimax-core' ),
        'options' => $this->rt_translate['cols_slider'],
        'default' => '1',
      ],
      [
        'mode' => 'section_end',
      ],
	  // Slider options
      [
        'mode'        => 'section_start',
        'id'          => 'sec_slider',
        'label'       => esc_html__( 'Slider Options', 'optimax-core' ),
        'condition' => [ 'style' => [ 'style9' ] ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_autoplay',
        'label'       => esc_html__( 'Autoplay', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'optimax-core' ),
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_stop_on_hover',
        'label'       => esc_html__( 'Stop on Hover', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Stop autoplay on mouse hover. Default: On', 'optimax-core' ),
        'condition'   => [ 'slider_autoplay' => 'yes' ],
      ],
      [
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'slider_interval',
        'label'   => esc_html__( 'Autoplay Interval', 'optimax-core' ),
        'options' => [
          '5000' => esc_html__( '5 Seconds', 'optimax-core' ),
          '4000' => esc_html__( '4 Seconds', 'optimax-core' ),
          '3000' => esc_html__( '3 Seconds', 'optimax-core' ),
          '2000' => esc_html__( '2 Seconds', 'optimax-core' ),
          '1000' => esc_html__( '1 Second',  'optimax-core' ),
        ],
        'default' => '5000',
        'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'optimax-core' ),
        'condition'   => [ 'slider_autoplay' => 'yes' ],
      ],
      [
        'type'    => Controls_Manager::NUMBER,
        'id'      => 'slider_autoplay_speed',
        'label'   => esc_html__( 'Autoplay Slide Speed', 'optimax-core' ),
        'default' => 200,
        'description' => esc_html__( 'Slide speed in milliseconds. Default: 200', 'optimax-core' ),
        'condition'   => [ 'slider_autoplay' => 'yes' ],
      ],
      [
        'type'        => Controls_Manager::SWITCHER,
        'id'          => 'slider_loop',
        'label'       => esc_html__( 'Loop', 'optimax-core' ),
        'label_on'    => esc_html__( 'On', 'optimax-core' ),
        'label_off'   => esc_html__( 'Off', 'optimax-core' ),
        'default'     => 'yes',
        'description' => esc_html__( 'Loop to first item. Default: On', 'optimax-core' ),
      ],
      [
        'mode' => 'section_end',
      ],

      // Starting Style Section 
      [
        'mode'    => 'section_start',
        'id'      => 'title_style_section',
        'label'   => esc_html__( 'Title Style', 'optimax-core' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_color',
        'label'     => esc_html__( 'Title Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2 .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-hover-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-8 .effect-goliath figcaption .rtin-title a' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_hover_color',
        'label'     => esc_html__( 'Title Hover Color', 'optimax-core' ),
        // selector hover is bit tricky
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1:hover .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2:hover .rtin-content .rtin-title a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-hover-content .rtin-title a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-8 .case-study-box .effect-goliath figcaption .rtin-title a:hover' => 'color: {{VALUE}}',
        ],
      ],
      
	  [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'item_title_typo',
        'label'          => esc_html__( 'Title Typography', 'optimax-core' ),
        // Its Not An ARRAY
        'selector'       => '
          {{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1-inner .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2 .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-hover-content .rtin-title ,
          {{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-title,
          {{WRAPPER}} .rtel-case-study-8 .case-study-box .effect-goliath figcaption .rtin-title,
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'title_margin',
        'condition' => [ 'style' => [ 'style1', 'style2',  'style3',  'style4',  'style5',  ] ],
        'label'      => __( 'Title Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2 .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-case-study-8 .case-study-box .effect-goliath figcaption .rtin-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
        'separator'  => 'before',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'title_icon_color',
        'label'     => esc_html__( 'Title Icon Color', 'optimax-core' ),
        'condition' => [ 'style' => [ 'style6', ] ],
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-hover-content a.rtin-icon' => 'color: {{VALUE}}; border-color: {{VALUE}}',
        ],
      ],
      [
        'mode'            => 'group',
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'title_background',
        'types'           => [ 'classic', 'gradient', ],
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Title Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-hover-content,
          {{WRAPPER}} noselector,
          {{WRAPPER}} noselector
        ',
        'condition' => [ 'style' => [ 'style6', ] ],
      ],
      [
        'mode' => 'section_end',
      ],
      [
        'mode'      => 'section_start',
        'id'        => 'content_style_section',
        'label'     => esc_html__( 'Content Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style1', 'style2', ] ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'content_color',
        'label'     => esc_html__( 'Content Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2 .rtin-content p' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'content_hover_color',
        'label'     => esc_html__( 'Content Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1:hover .rtin-content p' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2:hover .rtin-content p' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'content_typo',
        'label'          => esc_html__( 'Content Typography', 'optimax-core' ),
        // Not Array
        'selector'       => '
          {{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content  p,
          {{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2 .rtin-content p
        ',
      ],
      [
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'id'         => 'content_margin',
        'label'      => __( 'Content Margin', 'optimax-core' ),                 
        'selectors'  => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
          '{{WRAPPER}} .rtel-case-study-2 .rtin-case-study-box-layout2 .rtin-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;'
        ],
        'separator'  => 'before',
      ],
      [
        'mode' => 'section_end',
      ],
       // read more color and typo
      [
        'mode'      => 'section_start',
        'id'        => 'readmore_style',
        'label'     => esc_html__( 'Readmore', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style1', ] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'readmore_typo',
        'label'          => esc_html__( 'Readmore Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}}  .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content .rtin-btn
        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_color',
        'label'     => esc_html__( 'Readmore Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content .rtin-btn' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_color_hover',
        'label'     => esc_html__( 'Readmore Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1:hover .rtin-case-study-box-layout1 .rtin-content .rtin-btn' => 'color: {{VALUE}}',
        ],
      ],

      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_icon_color',
        'label'     => esc_html__( 'Readmore Icon Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1 .rtin-case-study-box-layout1 .rtin-content .rtin-btn i' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'readmore_icon_hover_color',
        'label'     => esc_html__( 'Readmore Icon Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-1:hover .rtin-case-study-box-layout1 .rtin-content .rtin-btn i' => 'color: {{VALUE}}',
        ],
      ],
      
      
      [
        'mode' => 'section_end',
      ],

      // Other Style  
      [
        'mode'      => 'section_start',
        'id'        => 'other_style_section',
        'label'     => esc_html__( 'Others Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style3', 'style4', 'style5', 'style6', ] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'meta_text_typo',
        'label'          => esc_html__( 'Meta Typography', 'optimax-core' ),
        'selector'       => '
          {{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-subtitle,
          {{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-subtitle, 
          {{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-category a, 
          {{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-subtitle

        ',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_link_color',
        'label'     => esc_html__( 'Meta Link Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-subtitle a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-subtitle a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-category a' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-subtitle a' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_link_hover_color',
        'label'     => esc_html__( 'Meta Link Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-subtitle a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-4 .rtin-case-study-box .rtin-content .rtin-subtitle a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-5 .rtin-case-study-box .rtin-content .rtin-subtitle a:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-category a:hover' => 'color: {{VALUE}}',
        ],
      ],
      [
        'mode'            => 'group',
        'condition' => [ 'style' => [ 'style6', ] ],
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'metalink_background',
        'types'           => [ 'classic', 'gradient', ],
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Meta Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-category a,
          {{WRAPPER}} noselector
        ',
      ],
      [
        'mode'            => 'group',
        'condition' => [ 'style' => [ 'style6', ] ],
        'separator'       => 'before',
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'metalink_hover_background',
        'types'           => [ 'classic', 'gradient', ],
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Meta Hover Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 .rtin-img .rtin-category a:hover,
          {{WRAPPER}} noselector
        ',
      ],
      [
        'mode'            => 'group',
        'separator'       => 'before',
        'condition' => [ 'style' => [ 'style6', ] ],
        'label_block'     => true,
        'type'            => Group_Control_Background::get_type(),
        'name'            => 'content_main_background',
        'types'           => [ 'classic', 'gradient', ],
        'fields_options'  => [
          'background' => [
            'label' => esc_html__( 'Each Case Study Background', 'optimax-core' ),
          ],
        ],
        'selector'        => '
          {{WRAPPER}} .rtel-case-study-6 .rtin-case-study-box-layout6 ,
          {{WRAPPER}} noselector
        ',
      ],
      [
        'mode' => 'section_end',
      ],
      // meta border style
      [
        'mode'      => 'section_start',
        'id'        => 'title_border_style',
        'label'     => esc_html__( 'Title Border', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style3', ] ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_border_color',
        'label'     => esc_html__( 'Meta border color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-title:after' => 'background-color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'meta_hover_border_color',
        'label'     => esc_html__( 'Meta Hover border color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}} .rtel-case-study-3 .case-study-box-layout3 .rtin-content .rtin-title:before' => 'background-color: {{VALUE}}',
        ],
      ],
      
      [
        'mode' => 'section_end',
      ],
      // isotope navigation 
      [
        'mode'      => 'section_start',
        'id'        => 'isotope_section_style',
        'label'     => esc_html__( 'Isotope Navigation Style', 'optimax-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [ 'style' => [ 'style5', ] ],
      ],
      [
        'mode'           => 'group',
        'type'           => Group_Control_Typography::get_type(),
        'name'           => 'isotope_navigation_typo',
        'label'          => esc_html__( 'Navigation Title Typography', 'optimax-core' ),
        'selector'       => '{{WRAPPER}}  .isotop-btn-2 .nav-item',
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'isotope_navigation_color',
        'label'     => esc_html__( 'Isotope Navigation Color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}}  .isotop-btn-2 .nav-item' => 'color: {{VALUE}}' ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'isotope_navigation_hover_color',
        'label'     => esc_html__( 'Isotope Navigation Hover Color', 'optimax-core' ),
        'selectors' => [
          '{{WRAPPER}}  .isotop-btn-2 .nav-item:hover' => 'color: {{VALUE}}',
          '{{WRAPPER}}  .isotop-btn-2 .nav-item.current' => 'color: {{VALUE}}',
        ],
      ],
      [
        'type'      => Controls_Manager::COLOR,
        'id'        => 'isotope_navigation_border_color',
        'label'     => esc_html__( 'Isotope Title Border color', 'optimax-core' ),
        'selectors' => [ '{{WRAPPER}} .isotop-btn-2 .nav-item:after' => 'background-color: {{VALUE}}' ],
      ],
      [
        'mode' => 'section_end',
      ],


    ];
    return $fields;
  }
  
	private function rt_owl_load_scripts(){
		wp_enqueue_style( 'owl-carousel' );
		wp_enqueue_script( 'owl-carousel' );
	}
	public function generate_owl_settings($data) {

		$owl_data = [
		  'nav'                => false,
		  'navText'            => ['<i class="fas fa-angle-left" aria-hidden="true"></i>', '<i class="fas fa-angle-right" aria-hidden="true"></i>'],
		  'dots'               => true,
		  'autoplay'           => $data['slider_autoplay'] == 'yes' ? true : false,
		  'autoplayTimeout'    => $data['slider_interval'],
		  'autoplaySpeed'      => $data['slider_autoplay_speed'],
		  'autoplayHoverPause' => $data['slider_stop_on_hover'] == 'yes' ? true : false,
		  'loop'               => $data['slider_loop'] == 'yes' ? true : false,
		  'margin'             => 30,
		  'smartSpeed'         => 1200,
		  'items'              => 1,
		];

		  $owl_data['responsive'] = [
			'0'    => [
			  'items' => $data['col_mobile_slider'],
			  'nav'   => false,
			  'dots'  => true,
			],
			'480'  => [
			  'items' => $data['col_xs_slider'],
			  'nav'   => false,
			  'dots'  => true,
			],
			'768'  => [
			  'items' => $data['col_sm_slider'],
			  'nav'   => false,
			  'dots'  => true,
			],
			'992'  => [
			  'items' => $data['col_md_slider'],
			  'nav'   => false,
			  'dots'  => true,
			],
			'1200' => [
			  'items' => $data['col_lg_slider'],
			  'nav'   => false,
			  'dots'  => true,
			],
		  ];

    
		if ( is_rtl () ) {
		  $owl_data['rtl'] = true;
		}
		return $owl_data;
	}
  
	private function rt_load_scripts() {
		wp_enqueue_style( 'isotope-pkgd' );
		wp_enqueue_script( 'imagesloaded' );
	}
	
	
	protected function render() {		
    $data = $this->get_settings();
	
    if ( ($data['style']  == 'style5') || ($data['style']  == 'style8') ) {
      $this->rt_load_scripts();
    }
	
    $owl_data = $this->generate_owl_settings( $data );
    $data['owl_data'] = json_encode( $owl_data );
	if ( ($data['style']  == 'style9') ) {
      $this->rt_owl_load_scripts();
    }
	
    switch ( $data['style'] ) {
      case 'style2':
      $template = 'view-2';
      break;
      case 'style3':
      $template = 'view-3';
      break;
      case 'style4':
      $template = 'view-4';
      break;
      case 'style5':
      $template = 'view-5';
      break;
      case 'style7':
      $template = 'view-7';
      break;
      case 'style8':
      $template = 'view-8';
      break;
      case 'style9':
      $template = 'view-9';
      break;
      case 'style6':
      $template = 'view-6';
      break;
      default:
      $template = 'view-1';
      break;
    }
	
    return $this->rt_template( $template, $data );
  }
}
