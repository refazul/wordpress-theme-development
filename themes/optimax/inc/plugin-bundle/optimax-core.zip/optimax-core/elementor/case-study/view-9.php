<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;
use radiustheme\Optimax\Helper;
extract($data);
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}
$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size2";
$args = [
  'post_type'        => "{$prefix}_case",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$set_category_bool = is_array($multiple_category);
$set_category_bool = $set_category_bool && count( $multiple_category ) ;
if ($set_category_bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_case_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="rtel-case-study-9">
  <div class="rtin-case-study">
    <div class="owl-theme owl-carousel rt-owl-carousel nav-control-layout4" data-carousel-options="<?php echo esc_attr( $owl_data );?>">
	<?php if ( $query->have_posts() ) :?>
      <?php
       while( $query->have_posts() ): $query->the_post();
        $post         = get_post();
        $title        = $post->post_title;
        $excerpt      = Helper::generate_excerpt( $post, $no_of_excerpt_words );
        $permalink    = get_the_permalink($post);
        $thumb        = Helper::generate_thumbnail_image( $post, $thumb_size );
        ?>
        <div class="rtin-item">
          <div class="rtin-box">
            <div class="rtin-box-inner">
                <div class="rtin-img">
                  <a href="<?php echo esc_url( $permalink ); ?>"><?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail( $thumb_size ); ?><?php } ?></a>
                  <div class="rtin-hover-content">
					<div class="rtin-left">
					<?php $first_term = Helper::taxonomy_first_term( get_the_ID(), $prefix . "_case_category"); ?>
					<span class="rtin-category"><?php echo wp_kses_post( $first_term ); ?></span>
                    <h3 class="rtin-title"> <a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h3>
					</div>
                    <a href="<?php echo esc_url( $permalink ); ?>" class="rtin-icon"><i class="fas fa-long-arrow-alt-right"></i></a>
                  </div>
                </div>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
	  <?php endif; ?>
    </div>
  </div>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>
