<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use radiustheme\Optimax\Helper;
extract($data);
$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$prefix      = Constants::$theme_prefix;
$thumb_size  = "{$prefix}-size3";

$args = [
  'post_type'        => "{$prefix}_case",
  'posts_per_page'   => $posts_per_page,
  'suppress_filters' => false,
  'orderby'          => $orderby,
  'paged'            => $paged,
];

switch ( $orderby ) {
  case 'title':
  case 'menu_order':
  $args['order'] = 'ASC';
  break;
}

$set_category_bool = is_array($multiple_category);
$set_category_bool = $set_category_bool && count( $multiple_category ) ;
if ($set_category_bool) {
  $args['tax_query'] = [
    [
      'taxonomy' => "{$prefix}_case_category",
      'terms' => $multiple_category, // Where term_id of Term 1 is "1".
      'include_children' => false
    ]
  ];
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
$col_class = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col}";
$uniqueid = time() . rand( 1, 99 );

$gallery = [];
$cats    = [];

while( $query->have_posts() ) {
  $query->the_post(); 
  $post          = get_post();
  $cats_comma    = [];
  $img           = Helper::generate_thumbnail_image( $post, $thumb_size );
  $terms         = get_the_terms( $post, "{$prefix}_case_category" );
  $terms         = $terms ? $terms : [];
  $terms_html    = '';
  if ( !$terms ) {
    continue;
  }
  foreach ( $terms as $term ) {
    $terms_html  .= " {$uniqueid}-{$term->slug}";
    $cats_comma[] = $term->name;
    if ( !isset( $cats[$term->slug] ) ) {
      $cats[$term->slug] = $term->name;
    }
  }
  $gallery[] = [
    'img'        => $img,
    'title'      => $post->post_title,
    'url'        => get_the_permalink( $post ),
    'cats'       => $terms_html,
    'cats_comma' => implode(", ", $cats_comma ),
    'post'       => $post,
	'id'       => get_the_id(),
  ];
}
// cats overwritten
if ($set_category_bool) {
  $terms = get_terms( [
    'taxonomy' => "{$prefix}_case_category",
    'hide_empty' => false,
    'term_taxonomy_id' => $multiple_category, // Where term_id of Term 1 is "1".
  ]);
  $cats = [];
  foreach ($terms as $term) {
    $cats[$term->slug] = $term->name;
  }
}
?>
<div class="rtel-case-study-8">
  <div class="isotope-wrap">
    <div class="text-center">
      <div class="isotope-classes-tab isotop-btn-2">
        <a href="#" class="current nav-item" data-filter="*"><?php esc_html_e( 'All', 'optimax-core' );?></a>
        <?php foreach ( $cats as $key => $value): ?>
        <?php $cat_filter = "{$uniqueid}-{$key}";?>
          <a href="#" class="nav-item" data-filter=".<?php echo esc_attr( $cat_filter );?>">
            <?php echo esc_html( $value );?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="row featuredContainer">
      <?php foreach ($gallery as $single){ ?>
        <div class="<?php echo esc_attr( $col_class . $single['cats'] );?>">
			<div class="case-study-box">
				<figure class="effect-goliath">
					<div class="rtin-img">
					<a href="<?php echo esc_url( $single['url'] ); ?>">
						<?php echo get_the_post_thumbnail( $single['id'], $thumb_size ); ?>
					</a>
					</div>
					<figcaption>						
						<p class="rtin-subtitle">
							<?php
								$post = $single['post'];
								$terms_array  = get_the_terms( $post->ID, $prefix . '_case_category' );
								$terms_length = count( $terms_array );
							?>
								<?php if ($terms_array){ ?>
									<?php foreach ($terms_array as $index => $term){ ?>
										<a href="<?php echo esc_url( get_term_link($term, $prefix . '_case_category') ); ?>"><?php echo esc_html( $term->name ); ?></a>
										<?php echo esc_html( Helper::generate_array_iterator_postfix($terms_array, $index) ); ?>
									<?php } ?>
							<?php } ?>
						</p>
						<h3 class="rtin-title"><a href="<?php echo esc_url( $single['url'] ); ?>"><?php echo esc_html( $single['title'] ); ?></a></h3>
					</figcaption>
				</figure>
			</div>
        </div>
      <?php } ?>
    </div>
  </div>
  <?php if ( $pagination_display == 'yes' ): ?>
    <div class="pagination-layout1">
      <?php get_template_part( 'template-parts/pagination' ) ?>
    </div>
  <?php endif ?>
  <?php Helper::wp_reset_temp_query( $temp ); ?>
</div>