<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Optimax_Core;

use \RT_Widget_Fields;
use \WP_Widget;
use radiustheme\Optimax\Helper;
use radiustheme\Optimax\RDTheme;

class Contact_Info extends WP_Widget {
  public function __construct() {
    $id = Constants::$theme_prefix . '_contact_info';
    parent::__construct(
            $id, // Base ID
            __( 'Optimax: Contact Info', 'optimax-core' ), // Name
            ['description' => __( 'Optimax: Contact Info', 'optimax-core' )
            ]);
  }

  /**
   * for front end view
   */
  public function widget( $args, $instance ){
    echo wp_kses_post( $args['before_widget'] );

    if ( !empty( $instance['title'] ) ) {
      $html = apply_filters( 'widget_title', $instance['title'] );
      $html = $args['before_title'] . $html .$args['after_title'];
    }
    else {
      $html = '';
    }
    echo wp_kses_post( $html );
    // first it will check redux value
    $phone           = RDTheme::$options['phone'] ? RDTheme::$options['phone'] : '';
    $email           = RDTheme::$options['email'] ? RDTheme::$options['email'] : '';
    $phone           = $instance['phone'] ? $instance['phone'] : $phone;
    $email           = $instance['email'] ? $instance['email'] : $email;
    $sub_description = $instance['sub_description'];


    ?>
    <p><?php echo esc_html( $sub_description ); ?></p>
    <ul class="contact-item">
        <?php if(!empty($phone)): ?>
          <li><i class="flaticon-phone-call"></i>
            <?php echo esc_html($phone) ?>
          </li>
        <?php endif; ?>
        <?php if(!empty($email)): ?>
          <li><i class="flaticon-message"></i>
            <?php echo esc_html($email) ?>
          </li>
        <?php endif; ?>
    </ul>

    <?php
    echo wp_kses_post( $args['after_widget'] );
  }

  public function update( $new_instance, $old_instance ){
    $instance                      = [];
    $instance['title']             = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
    $instance['phone']             = ( ! empty( $new_instance['phone'] ) ) ? wp_kses_post( $new_instance['phone'] ) : '';
    $instance['email']             = ( ! empty( $new_instance['email'] ) ) ? wp_kses_post( $new_instance['email'] ) : '';
    $instance['sub_description']   = ( ! empty( $new_instance['sub_description'] ) ) ? wp_kses_post( $new_instance['sub_description'] ) : '';
    return $instance;
  }
  public function form( $instance ){
    $defaults = [
      'title'       => 'Contact Info',
      'phone'       => '',
      'email'       => '',
      'sub_description' => 'Please feel free to contact us'
    ];
    $instance = wp_parse_args( (array) $instance, $defaults );

    $fields = [
      'title'  => [
        'label'   => __( 'Title', 'optimax-core' ),
        'type'    => 'text',
      ],
      'phone' => [
        'label'   => __( 'Phone Number', 'optimax-core' ),
        'type'    => 'text',
      ],
      'email' => [
        'label'   => __( 'Email', 'optimax-core' ),
        'type'    => 'text',
      ],
      'sub_description' => [
        'label'   => __( 'Sub-description', 'optimax-core' ),
        'type'    => 'text',
      ],
    ];

    RT_Widget_Fields::display( $fields, $instance, $this );
  }



}
