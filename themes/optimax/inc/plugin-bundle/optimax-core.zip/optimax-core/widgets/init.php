<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Optimax_Core;
class Optimax_Widget_Init {
  public $widgets;
  protected static $instance = null;
  public $rt_dir;

  public function __construct() {

    $this->rt_dir = dirname( ( new \ReflectionClass( $this ) )->getFileName() );

    // Widgets -- filename=>classname /@dev
    $this->widgets =  [
      'contact-info'               => 'Contact_Info',
      'service-navigation-sidebar' => 'Service_Navigation_Sidebar',
      'about-widget' => 'About_Widget',
      'rt-recent-post-widget' => 'OptimaxTheme_Recent_Post_With_Image_Widget',
      'rt-recent-case-widget' => 'OptimaxTheme_Recent_Case_With_Image_Widget'
    ];
    add_action( 'widgets_init', [$this, 'custom_widgets']);
  }
  public static function instance() {
    if ( null == self::$instance ) {
      self::$instance = new self;
    }
    return self::$instance;
  }
  public function custom_widgets() {
    if ( !class_exists( 'RT_Widget_Fields' ) ) return;
    foreach ( $this->widgets as $filename => $classname ) {
       $file  = $this->rt_dir . DIRECTORY_SEPARATOR . $filename . '.php';
       $class = __NAMESPACE__ . '\\' . $classname;
      require_once $file;
      register_widget( $class );
    }
  }
}
Optimax_Widget_Init::instance();
