<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Optimax_Core;

use \WP_Widget;
use \RT_Widget_Fields;

class About_Widget extends WP_Widget {
  public function __construct() {
    $id = 'optimax_about';
    parent::__construct(
            $id, // Base ID
            esc_html__( 'optimax: About', 'optimax-core' ), // Name
            ['description' => esc_html__( 'optimax: About Widget', 'optimax-core' ) ]
          );
  }


  /**
   * for front end view
   */
  public function widget( $args, $instance ){
    echo wp_kses_post( $args['before_widget'] );

    if ( !empty( $instance['logo'] ) ) {
      $html = '<div class="footer-logo"><a href="'. esc_url( home_url( '/' ) ) . '">'. wp_get_attachment_image( $instance['logo'], 'full' ) .'</a></div>';
    }
    elseif ( !empty( $instance['title'] ) ) {
      $html = apply_filters( 'widget_title', $instance['title'] );
      $html = $args['before_title'] . $html .$args['after_title'];
    }
    else {
      $html = '';
    }

    echo wp_kses_post( $html );

    $title = $instance['title'];
    $logo = $instance['logo'];
    $description = $instance['description'];
    $address = $instance['address'];
    $phone = $instance['phone'];
    $phone2 = $instance['phone2'];
    $email = $instance['email'];
    $socials = [
      [
        'url'  => $instance['facebook'],
        'icon' => 'fab fa-facebook-f',
      ],
      [
        'url'  => $instance['twitter'],
        'icon' => 'fab fa-twitter',
      ],
      [
        'url'  => $instance['linkedin'],
        'icon' => 'fa fa-linkedin',
      ],
      [
        'url'  => $instance['pinterest'],
        'icon' => 'fa fa-pinterest',
      ],
      [
        'url'  => $instance['rss'],
        'icon' => 'fab fa-rss',
      ],
      [
        'url'  => $instance['instagram'],
        'icon' => 'fab fa-instagram',
      ],
    ];

    $socials =  array_filter( $socials, function ($arg) {
      return ! empty( $arg['url'] ) ;
    });


    ?>

      <p>
        <?php if ( !empty( $description ) ) :?>
          <?php echo wp_kses_post( $description ); ?>
        <?php endif; ?>
        <?php if ( !empty( $address ) ): ?>
          <br>
          <strong>Address: </strong>
          <?php echo nl2br( $address ); ?>
        <?php endif ?>

        <?php if (  !empty( $phone ) ): ?>
          <br>
            <strong>Phone:</strong> <?php echo esc_html( $phone ); ?>
            <?php if ($phone2): ?>
              , <?php echo esc_html( $phone2 ); ?>
            <?php endif ?>
        <?php endif ?>

        <?php if ( !empty( $email ) ): ?>
            <br>
            <strong>Email: </strong>
            <?php echo esc_html( $email ); ?>
        <?php endif ?>
      </p>

      <ul class="footer-social">
        <?php if ( count( $socials ) ): ?>
          <?php foreach ($socials as $social): ?>
            <li><a href="<?php echo esc_url( $social['url'] ); ?>"><i class="<?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
          <?php endforeach ?>
        <?php endif ?>
      </ul>

    <?php
    echo wp_kses_post( $args['after_widget'] );
  }


  public function update( $new_instance, $old_instance ) {
    $instance                  = [];
    $instance['title']         = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
    $instance['logo']          = ( ! empty( $new_instance['logo'] ) ) ? sanitize_text_field( $new_instance['logo'] ) : '';
    $instance['description']   = ( ! empty( $new_instance['description'] ) ) ? wp_kses_post( $new_instance['description'] ) : '';
    $instance['address']   = ( ! empty( $new_instance['address'] ) ) ? wp_kses_post( $new_instance['address'] ) : '';
    $instance['phone']     = ( ! empty( $new_instance['phone'] ) ) ? sanitize_text_field( $new_instance['phone'] ) : '';
    $instance['phone2']    = ( ! empty( $new_instance['phone2'] ) ) ? sanitize_text_field( $new_instance['phone2'] ) : '';
    $instance['email']     = ( ! empty( $new_instance['email'] ) ) ? sanitize_email( $new_instance['email'] ) : '';
    $instance['facebook']      = ( ! empty( $new_instance['facebook'] ) ) ? sanitize_text_field( $new_instance['facebook'] ) : '';
    $instance['twitter']       = ( ! empty( $new_instance['twitter'] ) ) ? sanitize_text_field( $new_instance['twitter'] ) : '';
    $instance['linkedin']      = ( ! empty( $new_instance['linkedin'] ) ) ? sanitize_text_field( $new_instance['linkedin'] ) : '';
    $instance['pinterest']     = ( ! empty( $new_instance['pinterest'] ) ) ? sanitize_text_field( $new_instance['pinterest'] ) : '';
    $instance['rss']           = ( ! empty( $new_instance['rss'] ) ) ? sanitize_text_field( $new_instance['rss'] ) : '';
    $instance['instagram']     = ( ! empty( $new_instance['instagram'] ) ) ? sanitize_text_field( $new_instance['instagram'] ) : '';
    return $instance;
  }

  public function form( $instance ) {
    $defaults = [
      'title'         => '',
      'logo'          => '',
      'description'   => '',
      'address'     => '',
      'phone'       => '',
      'phone2'      => '',
      'email'       => '',
      'facebook'      => '',
      'twitter'       => '',
      'linkedin'      => '',
      'pinterest'     => '',
      'rss'           => '', 
      'instagram'     => ''
    ];
    $instance = wp_parse_args( (array) $instance, $defaults );

    $fields = [
      'title'       => [
        'label'   => esc_html__( 'Title', 'optimax-core' ),
        'type'    => 'text',
      ],
      'logo'        => [
        'label'   => esc_html__( 'Logo', 'optimax-core' ),
        'type'    => 'image',
      ],
      'description' => [
        'label'   => esc_html__( 'Description', 'optimax-core' ),
        'type'    => 'textarea',
      ],
      'address'   => [
        'label' => esc_html__( 'Address', 'optimax-core' ),
        'type'  => 'textarea',
      ],
      'phone'     => [
        'label' => esc_html__( 'Phone 1', 'optimax-core' ),
        'type'  => 'text',
      ],
      'phone2'    => [
        'label' => esc_html__( 'Phone 2', 'optimax-core' ),
        'type'  => 'text',
      ],
      'email'     => [
        'label' => esc_html__( 'Email', 'optimax-core' ),
        'type'  => 'text',
      ],
      'facebook'    => [
        'label'   => esc_html__( 'Facebook URL', 'optimax-core' ),
        'type'    => 'url',
      ],
      'twitter'     => [
        'label'   => esc_html__( 'Twitter URL', 'optimax-core' ),
        'type'    => 'url',
      ],
      'linkedin'    => [
        'label'   => esc_html__( 'Linkedin URL', 'optimax-core' ),
        'type'    => 'url',
      ],
      'pinterest'   => [
        'label'   => esc_html__( 'Pinterest URL', 'optimax-core' ),
        'type'    => 'url',
      ],
      'rss'         => [
        'label'   => esc_html__( 'Rss Feed URL', 'optimax-core' ),
        'type'    => 'url',
      ],
      'instagram'   => [
        'label'   => esc_html__( 'Instagram URL', 'optimax-core' ),
        'type'    => 'url',
      ],
    ];

    RT_Widget_Fields::display( $fields, $instance, $this );
  }
}