<?php 
/**
* Widget API: Recent Case Study Widget class
* By : Radius Theme
*/
namespace radiustheme\Optimax_Core;

use \RT_Widget_Fields;
use \WP_Widget;
use \WP_Query;
use radiustheme\Optimax\Helper;
use radiustheme\Optimax\RDTheme;

Class OptimaxTheme_Recent_Post_With_Image_Widget extends WP_Widget {
	public function __construct() {
		$widget_ops = array(
			'classname' => 'rt_widget_post_study_with_image',
			'description' => esc_html__( 'Your site&#8217;s most recent Post with Image.' , 'optimax-core' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'rt-recent-recipe', esc_html__( 'Optimax : Latest Post with Image' , 'optimax-core' ), $widget_ops );
		$this->alt_option_name = 'rt_widget_recent_post';
	}
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}
		
		$title = ( !empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Recent Case' , 'optimax-core' );	
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
		$number = ( !empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number ){ $number = 6; }
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;
		$show_author = isset( $instance['show_author'] ) ? $instance['show_author'] : false;
		
		$title_char_number = ( !empty( $instance['title_char_number'] ) ) ? absint( $instance['title_char_number'] ) : 5;
		
		if ( empty( $title_char_number ) ){ $title_char_number = 4; }
		
		$result_query = new WP_Query( apply_filters( 'widget_posts_args', array(			
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true
		) ) );
		$i = 1;
		if ($result_query->have_posts()) :
		?>
		<?php echo wp_kses_post($args['before_widget']); ?>
		<?php if ( $title ) {
			echo wp_kses_post($args['before_title']) . $title . wp_kses_post($args['after_title']);
		} ?>		
		<div class="widget-latest widget-related-case">
		<?php while ( $result_query->have_posts() ) { $result_query->the_post(); ?>
			<div class="media media-none--xs">
				<div class="item-img">					
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="rt-wid-post-img">
						<?php
							if ( has_post_thumbnail() ){
								the_post_thumbnail( 'thumbnail', ['class' => 'media-object'] );
							} else {
						?>
							<img class="rt-lazy" src="<?php echo esc_url( Helper::get_img( 'noimage/noimage_320x320' ) ); ?>" alt="<?php the_title_attribute(); ?>">
						<?php }	?>
					</a>
				</div>
				<div class="media-body space-md">
					<?php if ( $show_date ) { ?>
						<div class="case-date posted-date"><?php echo get_the_time( get_option( 'date_format' ) ); ?></div>
					<?php } ?>
					<h5 class="item-title"><a href="<?php the_permalink(); ?>"><?php $title = wp_trim_words( get_the_title(), $title_char_number, '' ); echo esc_html( $title ); ?></a></h5>					
					<?php if ( $show_author ) { ?>
						<div class="item-post-by"><i class="fa fa-user"></i> <?php esc_html_e( 'by ', 'optimax-core'); ?> <span><?php the_author_posts_link();?></span></div>
					<?php } ?>
				</div>
			</div>		
		<?php $i++; } ?>		
		</div>		
		
		<?php echo wp_kses_post($args['after_widget']); ?>
		<?php
		wp_reset_postdata();
		endif;
	}
	
	public function update( $new_instance, $old_instance ) {
		$instance 				= $old_instance;
		$instance['title'] 		= sanitize_text_field( $new_instance['title'] );
		$instance['number'] 	= (int) $new_instance['number'];
		$instance['show_author'] = isset( $new_instance['show_author'] ) ? (bool) $new_instance['show_author'] : false;
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$instance['title_char_number'] = isset( $new_instance['title_char_number'] ) ? $new_instance['title_char_number'] : 6;
		
		return $instance;
	}
	
	public function form( $instance ) {
	$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
	$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 6;
	$show_author = isset( $instance['show_author'] ) ? (bool) $instance['show_author'] : false;
	$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
	$title_char_number = isset( $instance['title_char_number'] ) ? absint( $instance['title_char_number'] ) : 4;
	?>
	<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' )); ?>"><?php echo esc_html__( 'Title:' , 'optimax-core' ); ?></label>
	<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></p>

	<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' )); ?>"><?php esc_html_e( 'Number of posts to show:', 'optimax-core' ); ?></label>
	<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' )); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' )); ?>" type="number" step="1" min="1" value="<?php echo esc_attr( $number ); ?>" size="3" /></p>

	<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' )); ?>"><?php esc_html_e( 'Number of Title Length:', 'optimax-core' ); ?></label>
	<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'title_char_number' )); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title_char_number' )); ?>" type="number" step="1" min="1" value="<?php echo esc_attr( $title_char_number ); ?>" size="3" /></p>
	
	<p><input class="checkbox" type="checkbox"<?php checked( $show_author ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_author' )); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_author' ) ); ?>" />
	<label for="<?php echo esc_attr( $this->get_field_id( 'show_author' )); ?>"><?php esc_html_e( 'Display post Author?', 'optimax-core' ); ?></label></p>
	
	<p><input class="checkbox" type="checkbox"<?php checked( $show_date ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_date' )); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_date' )); ?>" />
	<label for="<?php echo esc_attr( $this->get_field_id( 'show_date' )); ?>"><?php esc_html_e( 'Display post date?', 'optimax-core' ); ?></label></p>
	<?php
	}	
}