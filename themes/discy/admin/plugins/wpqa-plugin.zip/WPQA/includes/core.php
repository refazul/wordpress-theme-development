<?php

/* @author    2codeThemes
*  @package   WPQA/includes
*  @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/* Dark skin */
function wpqa_dark_skin() {
	$all_skin_l    = wpqa_options("site_skin_l");
	$tax_archive   = apply_filters(wpqa_prefix_theme.'_tax_archive',false);
	$tax_filter    = apply_filters(wpqa_prefix_theme."_before_question_category",false);
	$tax_question  = apply_filters(wpqa_prefix_theme."_question_category",wpqa_question_categories);
	$search_type   = (wpqa_is_search()?wpqa_search_type():"");
	$wpqa_group_id = (wpqa_group_id() > 0?wpqa_group_id():"");

	if (is_author() || wpqa_is_user_profile()) {
		$skin_l = wpqa_options("author_skin_l");
	}else if (is_category() || is_tax(wpqa_question_categories) || $tax_filter == true) {
		if (is_tax(wpqa_question_categories) || $tax_filter == true) {
			$category_id = (int)get_query_var('wpqa_term_id');
		}else {
			$category_id = esc_html(get_query_var('cat'));
		}
		$cat_skin_l = get_term_meta($category_id,prefix_terms."cat_skin_l",true);
		$cat_skin_l = ($cat_skin_l != ""?$cat_skin_l:"default");
		if (is_category() && ($cat_skin_l == "" || $cat_skin_l == "default")) {
			$cat_skin_l = wpqa_options("post_skin_l");
		}
		if ((is_tax(wpqa_question_categories) || $tax_filter == true) && ($cat_skin_l == "" || $cat_skin_l == "default")) {
			$cat_skin_l = wpqa_options("question_skin_l");
		}
		if (isset($cat_skin_l)) {
			$skin_l = $cat_skin_l;
		}
	}else if (is_tag() || (is_archive() && !is_post_type_archive("question") && !is_post_type_archive("group") && $tax_archive != true && !is_tax(wpqa_question_tags))) {
		$skin_l = wpqa_options("post_skin_l");
	}else if (is_tax(wpqa_question_tags) || is_post_type_archive("question")) {
		$skin_l = wpqa_options("question_skin_l");
	}else if ($search_type == "groups" || is_post_type_archive("group") || $wpqa_group_id > 0) {
		$skin_l = wpqa_options("group_skin_l");
	}else if (is_single() || $search_type == "posts" || $wpqa_group_id > 0 || is_page()) {
		global $post;
		$post_skin_l = get_post_meta($post->ID,prefix_meta."post_skin_l",true);
		if ($post_skin_l == "" || $post_skin_l == "default") {
			if (is_singular("post") || $search_type == "posts") {
				$post_skin_l = wpqa_options("post_skin_l");
			}
			if (is_singular("question") || is_singular("asked-question")) {
				$post_skin_l = wpqa_options("question_skin_l");
			}
			if ($wpqa_group_id > 0) {
				$post_skin_l = wpqa_options("group_skin_l");
			}
			if ((is_singular("post") || $search_type == "posts") && $post_skin_l != "default" && $post_skin_l != "") {
				$skin_l = $post_skin_l;
			}else if ((is_singular("question") || is_singular("asked-question")) && $post_skin_l != "default" && $post_skin_l != "") {
				$skin_l = $post_skin_l;
			}else if ($wpqa_group_id > 0 && $post_skin_l != "default" && $post_skin_l != "") {
				$skin_l = $post_skin_l;
			}else {
				$skin_l = $all_skin_l;
			}
		}else {
			$skin_l = $post_skin_l;
		}
		if ((is_singular("post") || $search_type == "posts") || is_singular("question") || is_singular("asked-question")) {
			global $post;
			$get_category = wp_get_post_terms($post->ID,(is_singular("question")?wpqa_question_categories:'category'),array("fields" => "ids"));
			if (isset($get_category[0])) {
				$category_single_id = $get_category[0];
			}
			if (isset($category_single_id)) {
				$setting_single = get_term_meta($category_single_id,prefix_terms."setting_single",true);
				if ($setting_single == "on") {
					$skin_l = get_term_meta($category_single_id,prefix_terms."cat_skin_l",true);
					$skin_l = ($skin_l != ""?$skin_l:"default");
				}
			}
		}
	}else {
		$skin_l = $all_skin_l;
	}
	$class = (isset($skin_l) && $skin_l == "default"?$all_skin_l:$skin_l);
	$class = ($class == "dark"?"dark":"light");
	$skin_switcher = wpqa_options("skin_switcher");
	if ($skin_switcher == "on") {
		if (is_user_logged_in()) {
			$user_id = get_current_user_id();
			$get_dark = get_user_meta($user_id,'wpqa_get_dark',true);
		}else {
			$uniqid_cookie = wpqa_options('uniqid_cookie');
			$get_dark = (isset($_COOKIE[$uniqid_cookie.'wpqa_get_dark'])?$_COOKIE[$uniqid_cookie.'wpqa_get_dark']:'');
		}
		$class = ($get_dark != ''?($get_dark == 'dark'?'dark':'light'):$class);
	}
	$class = (isset($_GET['skin']) && $_GET['skin'] != ""?($_GET['skin'] == 'dark'?'dark':'light'):$class);
	return $class;
}
/* Sidebars */
function wpqa_sidebar_layout($sidebar = '') {
	$tax_filter    = apply_filters(wpqa_prefix_theme."_before_question_category",false);
	$tax_question  = apply_filters(wpqa_prefix_theme."_question_category",wpqa_question_categories);
	$search_type   = (wpqa_is_search()?wpqa_search_type():"");
	$wpqa_group_id = (wpqa_group_id() > 0?wpqa_group_id():"");

	if (is_author() || wpqa_is_user_profile()) {
		$sidebar_style = wpqa_options("author_sidebar".$sidebar);
	}

	$group_sidebar = wpqa_options("group_sidebar".$sidebar);
	$question_sidebar = wpqa_options("question_sidebar".$sidebar);
	$post_sidebar  = wpqa_options("post_sidebar".$sidebar);
	$home_page_sidebar = wpqa_options("sidebar_home".$sidebar);
	if ($home_page_sidebar == "default" || $home_page_sidebar == "" || !is_active_sidebar($home_page_sidebar)) {
		$home_page_sidebar = 'sidebar_default'.$sidebar;
	}

	if (is_category() || is_tax(wpqa_question_categories) || $tax_filter == true) {
		if (is_tax(wpqa_question_categories) || $tax_filter == true) {
			$category_id = (int)get_query_var('wpqa_term_id');
		}else {
			$category_id = esc_html(get_query_var('cat'));
		}
		$sidebar_style = get_term_meta($category_id,prefix_terms."cat_sidebar".$sidebar,true);
		$sidebar_style = ($sidebar_style != ""?$sidebar_style:"default");
		if (is_category()) {
			if ($sidebar_style == "" || $sidebar_style == "default") {
				$sidebar_style = $post_sidebar;
			}
		}
		if (is_tax(wpqa_question_categories) || $tax_filter == true) {
			if ($sidebar_style == "" || $sidebar_style == "default") {
				$sidebar_style = $question_sidebar;
			}
		}
	   }

	if (is_single() || $search_type == "posts" || $wpqa_group_id > 0 || is_page()) {
		global $post;
		$what_sidebar = get_post_meta($post->ID,prefix_meta."what_sidebar".$sidebar,true);
		if (is_singular("post") || $search_type == "posts") {
			if ($what_sidebar == "default" || $what_sidebar == "") {
				$what_sidebar = $post_sidebar;
			}
		}
		if ($wpqa_group_id > 0) {
			if ($what_sidebar == "default" || $what_sidebar == "") {
				$what_sidebar = $group_sidebar;
			}
		}
		if (is_singular("question") || is_singular("asked-question")) {
			if ($what_sidebar == "default" || $what_sidebar == "") {
				$what_sidebar = $question_sidebar;
			}
		}
		if (is_singular("post") || $search_type == "posts" || is_singular("question")) {
			global $post;
			$get_category = wp_get_post_terms($post->ID,(is_singular("question")?wpqa_question_categories:'category'),array("fields" => "ids"));
			if (isset($get_category[0])) {
				$category_single_id = $get_category[0];
			}
		    if (isset($category_single_id)) {
		    	$setting_single = get_term_meta($category_single_id,prefix_terms."setting_single",true);
		    	if ($setting_single == "on") {
		    		$what_sidebar = get_term_meta($category_single_id,prefix_terms."cat_sidebar".$sidebar,true);
		    		$what_sidebar = ($what_sidebar != ""?$what_sidebar:"default");
		    	}
		    }
		}
	}

	if ((is_author() || wpqa_is_user_profile()) && $sidebar_style != "default" && $sidebar_style != "") {
		if ($sidebar_style != "" && is_active_sidebar($sidebar_style)) {
		    $dynamic_sidebar = $sidebar_style;
		}else {
		    $dynamic_sidebar = $home_page_sidebar;
		}
	}else if ((is_category() || is_tax(wpqa_question_categories) || $tax_filter == true) && $sidebar_style != "default" && $sidebar_style != "") {
		if (is_active_sidebar($sidebar_style)) {
		    $dynamic_sidebar = $sidebar_style;
		}else {
		    $dynamic_sidebar = $home_page_sidebar;
		}
	}else if ((is_tag() || (is_archive() && !is_post_type_archive("question") && !is_post_type_archive("group") && !is_tax(wpqa_question_tags))) && $post_sidebar != "default" && $post_sidebar != "") {
		if (is_active_sidebar($post_sidebar)) {
		    $dynamic_sidebar = $post_sidebar;
		}else {
		    $dynamic_sidebar = $home_page_sidebar;
		}
	}else if (is_post_type_archive("group") && $group_sidebar != "default" && $group_sidebar != "") {
		if (is_active_sidebar($group_sidebar)) {
		    $dynamic_sidebar = $group_sidebar;
		}else {
		    $dynamic_sidebar = $home_page_sidebar;
		}
	}else if ((is_tax(wpqa_question_tags) || is_post_type_archive("question")) && $question_sidebar != "default" && $question_sidebar != "") {
		if (is_active_sidebar($question_sidebar)) {
		    $dynamic_sidebar = $question_sidebar;
		}else {
		    $dynamic_sidebar = $home_page_sidebar;
	   	}
	}else if ((is_single() || $search_type == "posts" || $wpqa_group_id > 0 || is_page()) && $what_sidebar != "default" && $what_sidebar != "") {
		if (is_active_sidebar($what_sidebar)) {
		    $dynamic_sidebar = $what_sidebar;
		}else {
		    $dynamic_sidebar = $home_page_sidebar;
		}
	}else  {
	    $dynamic_sidebar = $home_page_sidebar;
	}

	$return = (isset($dynamic_sidebar)?$dynamic_sidebar:"");
	
	return $return;
}
function wpqa_sidebars($return = 'sidebar_dir') {
	$search_type     = (wpqa_is_search()?wpqa_search_type():"");
	$tax_archive     = apply_filters(wpqa_prefix_theme.'_tax_archive',false);
	$tax_filter      = apply_filters(wpqa_prefix_theme."_before_question_category",false);
	$tax_question    = apply_filters(wpqa_prefix_theme."_question_category",wpqa_question_categories);
	$wpqa_group_id   = (wpqa_group_id() > 0?wpqa_group_id():"");
	$sidebar_layout  = "";
	
	$menu_sidebar    = "menu_sidebar".(has_himer() || has_knowly()?" col-boot-lg-7":"");
	$page_right      = "main_sidebar main_right".(has_himer() || has_knowly()?" col-boot-lg-8":"");
	$page_left       = "main_sidebar main_left".(has_himer() || has_knowly()?" col-boot-lg-8":"");
	$page_full_width = "main_full".(has_himer() || has_knowly()?" col-boot-lg-12":"");
	$page_centered   = "main_full main_center".(has_himer() || has_knowly()?" col-boot-lg-8":"");
	$menu_left       = "menu_left".(has_himer() || has_knowly()?" col-boot-lg-10":"");
	
	if (is_author() || wpqa_is_user_profile()) {
		$author_sidebar_layout = wpqa_options('author_sidebar_layout');
	}else if (is_category() || is_tax(wpqa_question_categories) || $tax_filter == true) {
		if (is_tax(wpqa_question_categories) || $tax_filter == true) {
			$category_id = (int)get_query_var('wpqa_term_id');
		}else {
			$category_id = esc_html(get_query_var('cat'));
		}
		$cat_sidebar_layout = get_term_meta($category_id,prefix_terms."cat_sidebar_layout",true);
		$cat_sidebar_layout = ($cat_sidebar_layout != ""?$cat_sidebar_layout:"default");
		if (is_category() && ($cat_sidebar_layout == "" || $cat_sidebar_layout == "default")) {
			$cat_sidebar_layout = wpqa_options("post_sidebar_layout");
		}
		if ((is_tax(wpqa_question_categories) || $tax_filter == true) && ($cat_sidebar_layout == "" || $cat_sidebar_layout == "default")) {
			$cat_sidebar_layout = wpqa_options("question_sidebar_layout");
		}
	}else if (is_tag() || (is_archive() && !is_post_type_archive("question") && !is_post_type_archive("group") && $tax_archive != true && !is_tax(wpqa_question_tags))) {
		$cat_sidebar_layout = wpqa_options("post_sidebar_layout");
	}else if (is_tax(wpqa_question_tags) || is_post_type_archive("question")) {
		$cat_sidebar_layout = wpqa_options("question_sidebar_layout");
	}else if ($search_type == "groups" || is_post_type_archive("group") || $wpqa_group_id > 0) {
		$cat_sidebar_layout = wpqa_options("group_sidebar_layout");
	}else if (is_single() || $search_type == "posts" || $wpqa_group_id > 0 || is_page()) {
		global $post;
		$sidebar_post = get_post_meta($post->ID,prefix_meta."sidebar",true);
		if ($sidebar_post == "" || $sidebar_post == "default") {
			if (is_singular("post") || $search_type == "posts") {
				$cat_sidebar_layout = wpqa_options("post_sidebar_layout");
			}
			if (is_singular("question") || is_singular("asked-question")) {
				$cat_sidebar_layout = wpqa_options("question_sidebar_layout");
			}
			if ($wpqa_group_id > 0) {
				$cat_sidebar_layout = wpqa_options("group_sidebar_layout");
			}
			if ((is_singular("post") || $search_type == "posts") && $cat_sidebar_layout != "default" && $cat_sidebar_layout != "") {
				$sidebar_post = $cat_sidebar_layout;
			}else if ((is_singular("question") || is_singular("asked-question")) && $cat_sidebar_layout != "default" && $cat_sidebar_layout != "") {
				$sidebar_post = $cat_sidebar_layout;
			}else if ($wpqa_group_id > 0 && $cat_sidebar_layout != "default" && $cat_sidebar_layout != "") {
				$sidebar_post = $cat_sidebar_layout;
			}else {
				$sidebar_post = wpqa_options("sidebar_layout");
			}
		}
		if ((is_singular("post") || $search_type == "posts") || is_singular("question") || is_singular("asked-question")) {
			$get_category = wp_get_post_terms($post->ID,(is_singular("question")?wpqa_question_categories:'category'),array("fields" => "ids"));
			if (isset($get_category[0])) {
				$category_single_id = $get_category[0];
			}
			if (isset($category_single_id)) {
				$setting_single = get_term_meta($category_single_id,prefix_terms."setting_single",true);
				if ($setting_single == "on") {
					$sidebar_post = get_term_meta($category_single_id,prefix_terms."cat_sidebar_layout",true);
					$sidebar_post = ($sidebar_post != ""?$sidebar_post:"default");
				}
			}
		}
	}else {
		$sidebar_layout = wpqa_options('sidebar_layout');
	}
	
	if (is_author() || wpqa_is_user_profile()) {
		if ($author_sidebar_layout == "" || $author_sidebar_layout == "default") {
			$author_sidebar_layout = wpqa_options("sidebar_layout");
		}
		if ($author_sidebar_layout == 'centered') {
			$sidebar_dir = $page_centered;
		}else if ($author_sidebar_layout == 'menu_sidebar') {
			$sidebar_dir = $menu_sidebar;
		}else if ($author_sidebar_layout == 'menu_left') {
			$sidebar_dir = $menu_left;
		}else if ($author_sidebar_layout == 'left') {
			$sidebar_dir = $page_left;
		}else if ($author_sidebar_layout == 'right') {
			$sidebar_dir = $page_right;
		}else if ($author_sidebar_layout == 'full') {
			$sidebar_dir = $page_full_width;
		}else {
			$sidebar_dir = (has_discy()?$menu_sidebar:$page_right);
		}
	}else if (is_category() || is_tag() || (is_archive() && !is_post_type_archive("question") && !is_post_type_archive("group")) || is_tax(wpqa_question_categories) || $tax_filter == true || $tax_archive == true || is_tax(wpqa_question_tags) || is_post_type_archive("question") || ($wpqa_group_id > 0 || is_post_type_archive("group") || $search_type == "groups")) {
		if (!isset($cat_sidebar_layout) || $cat_sidebar_layout == "" || $cat_sidebar_layout == "default") {
			$cat_sidebar_layout = wpqa_options("sidebar_layout");
		}
		if ($cat_sidebar_layout == 'centered') {
			$sidebar_dir = $page_centered;
		}else if ($cat_sidebar_layout == 'menu_sidebar') {
			$sidebar_dir = $menu_sidebar;
		}else if ($cat_sidebar_layout == 'menu_left') {
			$sidebar_dir = $menu_left;
		}else if ($cat_sidebar_layout == 'left') {
			$sidebar_dir = $page_left;
		}else if ($cat_sidebar_layout == 'right') {
			$sidebar_dir = $page_right;
		}else if ($cat_sidebar_layout == 'full') {
			$sidebar_dir = $page_full_width;
		}else {
			$sidebar_dir = (has_discy()?$menu_sidebar:$page_right);
		}
	}else if (is_single() || $search_type == "posts" || $wpqa_group_id > 0 || is_page()) {
		$sidebar_dir = '';
		if (isset($sidebar_post) && $sidebar_post != "default" && $sidebar_post != "") {
			if ($sidebar_post == 'centered') {
				$sidebar_dir = $page_centered;
			}else if ($sidebar_post == 'menu_sidebar') {
				$sidebar_dir = $menu_sidebar;
			}else if ($sidebar_post == 'menu_left') {
				$sidebar_dir = $menu_left;
			}else if ($sidebar_post == 'left') {
				$sidebar_dir = $page_left;
			}else if ($sidebar_post == 'right') {
				$sidebar_dir = $page_right;
			}else if ($sidebar_post == 'full') {
				$sidebar_dir = $page_full_width;
			}else {
				$sidebar_dir = (has_discy()?$menu_sidebar:$page_right);
			}
		}else {
			$sidebar_dir = (has_discy()?$menu_sidebar:$page_right);
		}
	}else {
		$sidebar_layout = wpqa_options('sidebar_layout');
		if ($sidebar_layout == 'centered') {
			$sidebar_dir = $page_centered;
		}else if ($sidebar_layout == 'menu_sidebar') {
			$sidebar_dir = $menu_sidebar;
		}else if ($sidebar_layout == 'menu_left') {
			$sidebar_dir = $menu_left;
		}else if ($sidebar_layout == 'left') {
			$sidebar_dir = $page_left;
		}else if ($sidebar_layout == 'right') {
			$sidebar_dir = $page_right;
		}else if ($sidebar_layout == 'full') {
			$sidebar_dir = $page_full_width;
		}else {
			$sidebar_dir = (has_discy()?$menu_sidebar:$page_right);
		}
	}
	
	if ($return == "sidebar_where") {
		if (strpos($sidebar_dir,'main_full main_center') !== false) {
			$sidebar_where = 'centered';
		}else if ($sidebar_dir == $menu_sidebar) {
			$sidebar_where = 'menu_sidebar';
		}else if ($sidebar_dir == $menu_left) {
			$sidebar_where = 'menu_left';
		}else if ($sidebar_dir == $page_full_width) {
			$sidebar_where = 'full';
		}else {
			$sidebar_where = 'sidebar';
		}
		return apply_filters(wpqa_prefix_theme."_sidebars_where",$sidebar_where);
	}else {
		return apply_filters(wpqa_prefix_theme."_sidebars_dir",$sidebar_dir);
	}
}?>