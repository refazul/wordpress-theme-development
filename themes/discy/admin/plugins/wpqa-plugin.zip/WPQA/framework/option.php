<?php

/* @author    2codeThemes
*  @package   WPQA/framework
*  @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/* Save default options */
$wpqa_admin_options = new wpqa_admin_options;
$default_options = $wpqa_admin_options->get_default_values();
if (!get_option(wpqa_options)) {
	add_option(wpqa_options,$default_options);
}?>